DebugLayer = class("DebugLayer", function()
	return display.newSprite()
end)

function DebugLayer:ctor()
	self.print_str = ""

	local panel = cc.LayerColor:create(cc.c4b( 0,0,0,100))
		:addTo(self):setContentSize(winSize.width,300)
	
	self.scrollView = cc.ScrollView:create(cc.size(winSize.width,300)) 
    self.scrollView:setPosition(cc.p(0,0))
    self.scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL)   
    self.scrollView:setContentSize( cc.size(winSize.width,600) )   
    self.scrollView:addTo(panel)
    self.scrollView:setBounceable(true)
    self.scrollView:setDelegate()
	
	self.thatLab = utils.label(""):addTo(self.scrollView)
	self.thatLab:setAnchorPoint( cc.p(0,1) )
	self.thatLab:setContentSize(cc.size(winSize.width, 0))
	
	local function close()
		--self:removeFromParent()
		self:updateInfo()
	end
	-- utils.button(create_uipath("zhuang.png"),create_uipath("zhuang.png"),nil,close):addTo(panel) 
 	-- :setPosition(display.cx,panel:getContentSize().height+30)
end

function DebugLayer:updateInfo()
	local str = self:getCachedStr()..self.print_str

	self.thatLab:setString(str)
	local size = self.thatLab:getContentSize()
	if size.height<300 then
		size.height = 300
	end
	
	self.scrollView:setContentSize( cc.size(winSize.width,size.height) )
	self.thatLab:setPosition( cc.p(0,size.height) )
end

function DebugLayer:addLogStr( str )
	self.print_str = self.print_str.."\n"..str
	self:updateInfo()
end

function DebugLayer:getLogStr()
	return self.print_str 
end

function DebugLayer:getCachedStr()
	return cc.Director:getInstance():getTextureCache():getCachedTextureInfo()
end

return DebugLayer