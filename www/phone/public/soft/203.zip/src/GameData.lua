--local GameData={}
module("GameData",package.seeall)

local GameStruct = import(".GameStruct")

-- PC窗口大小
-- PC_WIN_WIDTH  = 1283.0 --1024.0f;
-- PC_WIN_HEIGHT = 753.0

SOUND_BACKGROUND	=0
SOUND_EFFECT		=0

MAX_USERS 			=6
MIN_FIRE_SPACE 		=250

--enum move type
MOVETYPE_THOUGHT 	=0
MOVETYPE_CURVE		=1
MOVETYPE_LINE		=2
MOVETYPE_PARALLEL	=3
MOVETYPE_CIRCLE		=4
MOVETYPE_NONE		=5

--prop
PROPTYPE_NONE		=0
PROPTYPE_STAR		=1
PROPTYPE_KINDKILL	=2

--fishkind
FISHKIND_MIN		=0
FISHKIND_TEN		=10

FISHKIND_WHITESHARK	=15
FISHKIND_GOLDSHARK	=16
FISHKIND_BIGSHARK	=17

FISHKIND_FROG		=18
FISHKIND_CROCODILE	=19
FISHKIND_LI 		=20

FISHKIND_STOP		=21
FISHKIND_AREABOMB	=22
FISHKIND_ALLWINBOMB	=23

FISHKIND_QQ			=24
FISHKIND_ZONGYITANG	=25
FISHKIND_DRAGON		=26
FISHKIND_LI1		=27

--particle
PARTICLE_NONE		=0
PARTICLE_FULLWINDIE	=1
PARTICLE_AREADIE	=2
PARTICLE_VAL30		=3
PARTICLE_STOP		=4

--Position type
Line_Position		=0
Circle_Position		=1
Slant_Position		=2

FIRE_TIME_INTERVAL	= 250;				--发射间隔时间
MAX_BULLET_NUM		= 30;				--最多子弹数量

g_nUserTrueIndexArr = {};
PLAYER_INDEX		= 0;

Cannon_Ready		= 0;		--炮台准备
Cannon_Fire			= 1;		--炮台开火
Cannon_Sleep		= 2;		--炮台沉睡
Cannon_Stop			= 3;		--炮台停止

CANNON_MONEY_0		= 0
CANNON_MONEY_1		= 5000
CANNON_MONEY_2		= 10000

FISH_TAG            = 1001
BULLET_TAG          = 1002
WALL_TAG            = 1003

Fish_Rendy	      	= 0			--鱼准备
Fish_Move			= 1			--鱼移动
Fish_Stop			= 2			--鱼停止
Fish_Stru			= 3			--鱼挣扎
Fish_Die			= 4			--鱼死亡

DELETE_FISH			= 1000
CATCH_FISH			= 1001
CHANGE_CANNON		= 1002
OEVER_CIRCLE		= 1003
REMOVE_FLOOR_GLOD	= 1004

_kindseq={
	FISH_LI1,
	FISH_DRAGON,
	LI_KIND,
	CROCODILE_KIND,
	FROG_KIND,
	BIG_SHARK,
	GOLD_SHARK,
	WHITE_SHARK,
	FULLWINDOWBOMBID,
	FISH_ZONGYITANG,
	AREABOMBID
}

function FISHIDPOS()
	local o = {}
	o.id = 0; --int32_t
	o.curpos = 0; --short
	o.offset = POS.new(); --POS
	return o;
end

function FISH()
	local o = {}
	o.fishkind = FISHKIND_MIN; --char
	o.lMoveType = MOVETYPE_THOUGHT; --char
	o.lPropType = PROPTYPE_NONE; --char
	o.pathtype = 0; --uchar readUByte
	o.pathidx = 0; --uchar
	
	o.start_pos = POS.new();
	o.end_pos = POS.new();

	o.stoppos = 0; --short
	o.val = 0; --short

    o.num = 0; --char
	o.idpos = {}; --FISHIDPOS[1]
	return o;
end

function USERFIRE()
	local o = {}
	o.uid = 0; --uint32_t
	o.idx = 0; --int32_t
	o.fRol = 0; --float//short
	--//short score;
	o.type = 0; --char
	o.energy = 0; --char
	return o;
end

function USERCOLLIDE()
	local o = {}
    o.uid = 0; --uint32_t
    o.fishid = 0; --int32_t
	o.idx = 0; --int32_t
    --//short x,y;
	return o;
end

function FISHDIE()
	local o = {}
    o.uid = 0; --uint32_t
    o.fishid = 0; --int32_t
	o.val = 0; --int32_t
    o.card = 0; --char
    --//short x,y;
    o.score = 0; --int32_t
	return o;
end

ENERGY_FULLTIME		= 10000
ENERGY_ACTIVETIME	= 20000

Energy_Empty		= 0
Energy_Full			= 1
Energy_Active		= 2

function FISHIDVAL()
	local o = {}
    o.id = 0; --int32_t
	o.val = 0; --int32_t
	return o;
end

function BOMB()
	local o = {}
	o.uid = 0; --uint32_t
    o.particle = 0; --char
	o.freez = 0; --char
	o.pos = POS.new(); --POS
	o.len = 0; --char
	o.idval = {} ; --FISHIDVAL[1]
	return o;
end

---------

function GAMESCENE()
	
	local o = {}

	o.mapstate = 0; --int32_t
	o.mapidx = 0;--int32_t
	o.curposition = 0;--char //ÓãÕóÊ±,ÓãÕóË÷Òý
	o.circlerol = 0;--float
	--//char circleleave;
	o.usemoney = 0;--char
	o.scorelen = 0;--int32_t
	o.uids = {}; --uint32_t [MAX_USERS]={0};
	o.score = {}; --int32_t [MAX_USERS]={0};

	return o;
end

function FISHMOVE()
	local o = {}
	o.idlen = 0; --int32_t
	o.ids = {}; --int32_t
	o.stoppos = 0;
	return o;
end

function FISHMAPSTATE()
	local o = {}
	o.state = 0; --int32_t
	o.idx = 0; --int32_t
	o.position = 0; --char
	o.circle = 0; --float
	return o;
end

function ADDSCORE()
	local o = {}
	o.userid = 0; --uint32_t
	o.score = 0; --int32_t
	return o;
end

function BOSSVALCHG()
	local o = {}
	o.id = 0; --int32_t
	o.val = 0; --short
	return o;
end

function GAMELOCK()
	local o = {}
	o.userid = 0; --uint32_t
	o.fishid = 0; --int32_t
	return o;
end

function MONEYDROP()
	local o = {}
	o.uid = 0; --uint32_t
	o.fishid = 0; --int32_t
	o.val = 0; --int32_t
	return o;
end

--»ñÈ¡·½Ïò
function GETDIR(p,d)
	local dir = POS.new();
	dir.x=p.x*math.cos(d)-p.y*math.sin(d);
	dir.y=p.x*math.sin(d)+p.y*math.cos(d);
	p:setpos(dir);
end

--×ª»»µ¥Î»ÏòÁ¿
function GETCOMPANY(p)
	if p.x == 0 then
		if p.y > 0 then
			p.y = 1;
		else
			p.y = -1;
		end
	else
		local k = p.y/p.x;
		if p.x > 0 then
			p.x = math.sqrt(1.0/(1.0+k*k));
			p.y = k*p.x;
		else
			p.x = -math.sqrt(1.0/(1.0+k*k));
			p.y = k*p.x;
		end
	end
end
----read command

function GAMEENTER()
	local o = {}
	o.circlerol = 0; --float
    o.mapstate = 0; --int32_t
	o.mapidx = 0; --int32_t
	o.basescore = 0; --int32_t
	--//int32_t limitmoney;
	o.version = 0; --int32_t
	o.curposition = 0; --char
	return o;
end

function readGameEnter( _data )

	local p = GAMEENTER();

	p.circlerol = _data:readFloat()
    p.mapstate = _data:readInt()
	p.mapidx = _data:readInt()
	p.basescore = _data:readInt()
	--//int32_t limitmoney;
	p.version = _data:readInt()
	p.curposition = _data:readByte()

	return p;
end

function readGameScene( _data )

	local p = GAMESCENE();

	p.mapstate = _data:readFloat()
    p.mapidx = _data:readInt()
	p.curposition = _data:readByte()
	p.circlerol = _data:readFloat()
	--//int32_t limitmoney;
	p.usemoney = _data:readByte()
	--_data:readByte()

	p.scorelen = _data:readInt()
	
	for i=1,p.scorelen do
		p.uids[i] = _data:readUInt();
	end

	for i=1,p.scorelen do
		p.score[i] = _data:readInt();
	end
	--dump(p)
	return p;
end

function readAddFish( _data )

	local p1 = {};

	local n = _data:readInt();

	for i=1,n do

		local p = FISH();

		p.fishkind = _data:readByte(); --char
		p.lMoveType = _data:readByte(); --char
		p.lPropType = _data:readByte(); --char
		p.pathtype = _data:readUByte(); --uchar 
		p.pathidx = _data:readUByte(); --uchar

		_data:readByte()

		local x,y;

		x = _data:readShort();
		y = _data:readShort();

		p.start_pos:set(x,y);

		x = _data:readShort();
		y = _data:readShort();

		p.end_pos:set(x,y);


		p.stoppos = _data:readShort(); --short
		p.val = _data:readShort(); --short
		
		p.num = _data:readByte(); --char
		_data:readByte()
		for j=1,p.num do
			p.idpos[j] = FISHIDPOS(); --FISHIDPOS[1]

			p.idpos[j].id = _data:readInt();
			p.idpos[j].curpos = _data:readShort();

			x = _data:readShort();
			y = _data:readShort();

			p.idpos[j].offset:set(x,y);
		end

		p1[i] = p;

	end
	--dump(p1)
	return p1;
end

function readFishMove( _data )

	local p = FISHMOVE();

	p.idlen = _data:readInt();
	
	for i=1,p.idlen do
		p.ids[i] = _data:readInt();
	end

	p.stoppos = _data:readInt();
	--dump(p)
	return p;
end

function readFishMapState( _data )

	local p = FISHMAPSTATE();

	p.state = _data:readInt();
	p.idx = _data:readInt();
	p.position = _data:readByte();
	p.circle = _data:readFloat();

	return p;
end


FISHCIRCLES			= 5

function readFishLeave( _data )

	local p = {};

	for i=1,FISHCIRCLES do
		p[i] = _data:readInt();
	end

	return p;
end

function readUserFire( _data )

	local p = USERFIRE();

	p.uid = _data:readUInt();
	p.idx = _data:readInt();
	p.fRol = _data:readFloat();
	--//short score;
	p.type = _data:readByte();
	p.energy = _data:readByte();

	return p;
end

function readShowKU( _data )
	local p = {}
	p.statistics = _data:readInt()
	p.curmoney = _data:readInt()
	p.per = _data:readFloat()
	p.per0 = _data:readFloat()
	p.per1 = _data:readFloat()
	p.per2 = _data:readFloat()
	return p
end

function readFishDie( _data )

	local p = FISHDIE();

	p.uid = _data:readUInt();
	p.fishid = _data:readInt();
	p.val = _data:readInt();
	p.card = _data:readByte();
	_data:readByte()
	p.score = _data:readInt();
	return p;
end

function readAddScore( _data )

	local p = ADDSCORE();

	p.userid = _data:readUInt();
	p.score = _data:readInt();

	return p;
end

function readBossValChg( _data )

	local p = BOSSVALCHG();

	p.id = _data:readInt();
	p.val = _data:readShort();

	return p;
end

function readGameTips( _data )
	local p = {}

	p.userid = _data:readUInt()
	p.tipid = _data:readByte()
	_data:readByte()

	return p
end

function readCardDisApear( _data )

	local userid = 0;

	userid = _data:readUInt();

	return userid;
end

function readBomb( _data )

	local p = BOMB();

	p.uid = _data:readUInt();
    p.particle = _data:readByte();
	p.freez = _data:readByte();

	local x,y;

	x = _data:readShort();
	y = _data:readShort();

	p.pos:set(x,y);

	p.len = _data:readByte();
	_data:readByte()--new
	for i=1,p.len do
		p.idval[i] = FISHIDVAL();

		p.idval[i].id = _data:readInt();
		p.idval[i].val = _data:readInt();

	end
	--dump(p)
	return p;
end

function readGameStop( _data )

	local n = 0;

	n = _data:readByte();

	return n;
end

--[PLAYER_INDEX]->m_master=1;
--function readGameMaster( _data )
--end

function readGameLock( _data )

	local p = GAMELOCK();

	p.userid = _data:readUInt();
	p.fishid = _data:readInt();

	return p;
end

function readMoneyDrop( _data )

	local p = MONEYDROP();

	p.userid = _data:readUInt();
	p.fishid = _data:readInt();
	p.val = _data:readInt();
	--dump(p)
	return p;
end

function read_CMD_S_CanEnter( _data )

	local canEnter = GameStruct.CMD_S_CanEnter()

	canEnter.bCanEnter = _data:readInt()

	canEnter.lBringScore = _data:readInt()

	return canEnter
end

function read_CMD_S_TableInfo( _data )

	local tableInfo = GameStruct.CMD_S_TableInfo()

	for i=1,GAME_PLAYER do
		tableInfo.bExits[i]=_data:readBool()
	end

	for i=1,GAME_PLAYER do
		tableInfo.lUserMoney[i]=_data:readInt()
	end

	return tableInfo
end

function read_CMD_S_TableInfo( _data )

	local tableInfo = GameStruct.CMD_S_TableInfo()

	for i=1,GAME_PLAYER do
		tableInfo.bExits[i]=_data:readBool()
	end

	for i=1,GAME_PLAYER do
		tableInfo.lUserMoney[i]=_data:readInt()
	end

	return tableInfo
end

function read_CMD_S_StatusFree( _data )

	local StatusFree = GameStruct.CMD_S_StatusFree()

	StatusFree.lCellScore=_data:readInt()
	StatusFree.lCellMinScore=_data:readInt()
	StatusFree.lCellMaxScore=_data:readInt()
	StatusFree.lTaxScore=_data:readInt()
	StatusFree.lBringScore=_data:readInt()

	StatusFree.nStartTime=_data:readInt()
	StatusFree.nBetTime=_data:readInt()
	StatusFree.nEndTime=_data:readInt()

	return StatusFree
end

function read_CMD_S_GameStart( _data )
	local GameStart = GameStruct.CMD_S_GameStart()

	GameStart.wCurrentUser=_data:readUShort()
	GameStart.wDUser=_data:readUShort()
	GameStart.wMinChipInUser=_data:readUShort()
	GameStart.wMaxChipInUser=_data:readUShort()
	GameStart.lCellScore=_data:readInt()
	GameStart.lTurnMaxScore=_data:readInt()
	GameStart.lTurnLessScore=_data:readInt()
	GameStart.lAddLessScore=_data:readInt()
	for i=1,GAME_PLAYER do
		for j=1,MAX_COUNT do
			GameStart.cbCardData[i][j]=_data:readUByte()
		end
	end						
	
	for i=1,GAME_PLAYER do
		for j=1,MAX_COUNT do
			GameStart.cbAllData[i][j]=_data:readUByte()
		end
	end	
	return GameStart
end

function read_CMD_S_AddScore( _data )
	local AddScore = GameStruct.CMD_S_AddScore()
	AddScore.wCurrentUser=_data:readInt()
	AddScore.lAddScoreCount=_data:readInt()
	-- AddScore.nActionState=_data:readInt()
	-- AddScore.wCurrentUser=_data:readUShort()
	-- AddScore.wAddScoreUser=_data:readUShort()
	-- AddScore.lAddScoreCount=_data:readInt()	
	-- AddScore.lTurnLessScore=_data:readInt()
	-- AddScore.lTurnMaxScore=_data:readInt()
	-- AddScore.lAddLessScore=_data:readInt()

	-- for i=1,GAME_PLAYER do
	-- 	AddScore.cbShowHand[i]=_data:readUByte()
	-- end
	
	-- AddScore.lCell=_data:readInt()
	return AddScore
end

function read_CMD_S_GiveUp( _data )
	local GiveUp = GameStruct.CMD_S_GiveUp()
	GiveUp.wGiveUpUser=_data:readUShort()
	GiveUp.lLost=_data:readInt()
	GiveUp.lCell=_data:readInt()
	return GiveUp
end

function read_CMD_S_CenterPool( _data )
	local CenterPool = GameStruct.CMD_S_CenterPool()
	CenterPool.nCnt=_data:readInt()
	for i=1,GAME_PLAYER do
		CenterPool.lCenterPool[i]=_data:readInt()
	end
	return CenterPool
end

function read_CMD_S_SendCard( _data )
	local SendCard = GameStruct.CMD_S_SendCard()
	SendCard.cbPublic=_data:readUByte()
	_data:readUByte()

	SendCard.wCurrentUser=_data:readUShort()

	SendCard.cbSendCardCount=_data:readUByte()

	for i=1,MAX_CENTERCOUNT do
		SendCard.cbCenterCardData[i]=_data:readUByte()
	end

	return SendCard
end


function read_CMD_S_GameEnd( _data )
	local GameEnd = GameStruct.CMD_S_GameEnd()
	GameEnd.cbTotalEnd=_data:readUByte()
	_data:readUByte()
	_data:readUByte()
	_data:readUByte()

	for i=1,GAME_PLAYER do
		GameEnd.lGameTax[i]=_data:readInt()
	end

	for i=1,GAME_PLAYER do
		GameEnd.lGameScore[i]=_data:readInt()
	end

	for i=1,GAME_PLAYER do
		GameEnd.lWinScore[i]=_data:readInt()
	end


	for i=1,GAME_PLAYER do
		for j=1,MAX_COUNT do
			GameEnd.cbCardData[i][j]=_data:readUByte()
		end
	end

	for i=1,GAME_PLAYER do
		for j=1,MAX_CENTERCOUNT do
			GameEnd.cbLastCenterCardData[i][j]=_data:readUByte()
		end
	end

	for i=1,GAME_PLAYER do
		GameEnd.lUserScore[i]=_data:readInt()
	end

	for i=1,GAME_PLAYER do
		GameEnd.wWinUser[i]=_data:readUShort()
	end


	GameEnd.wWinUserCnt=_data:readUShort()

	for i=1,GAME_PLAYER do
		GameEnd.wPoolOwner[i]=_data:readUShort()
	end

	GameEnd.wPoolCnt=_data:readUShort()


	return GameEnd

end

function write_CMD_C_GameEnter(_nCmdID, _id)
	local _data = ByteArray.new()

	_data:writeInt(_nCmdID)
	_data:writeInt(_id)
	_data:writeUInt(0)

	return _data
end

function write_CMD_C_UserFire(_nCmdID, fire )
	local _data = ByteArray.new()

	_data:writeInt(_nCmdID)
    _data:writeUInt(fire.uid)
    _data:writeInt(fire.idx)
    _data:writeFloat(fire.fRol)
    _data:writeByte(fire.type)
    _data:writeByte(fire.energy)
    _data:writeUInt(0)

	return _data
end

function write_CMD_C_UserCollide(_nCmdID, col )
	local _data = ByteArray.new()

	_data:writeInt(_nCmdID)
    _data:writeUInt(col.uid)
    _data:writeInt(col.fishid)
    _data:writeInt(col.idx)
    _data:writeUInt(0)

    return _data
end

function write_CMD_C_GameBomb(_nCmdID, bomb )
	local _data = ByteArray.new()

	_data:writeInt(_nCmdID)
	_data:writeByte(0)--energybomb
	_data:writeInt(bomb.score)--score

    _data:writeUInt(bomb.uid)
    _data:writeByte(1)--bomb.particle
    _data:writeByte(1)--bomb.freez
    _data:writeShort(bomb.x)
    _data:writeShort(bomb.y)
    _data:writeByte(bomb.len)
    _data:writeByte(0)--new ×Ö½Ú¶ÔÆë
    local idval = bomb.idval
    for i=1,bomb.len do
    	_data:writeInt(idval[i].id)
    	_data:writeInt(idval[i].val)
    end
    _data:writeUInt(0)

    return _data
end

function write_CMD_C_GAME_LOCK(_nCmdID, lock )
	local _data = ByteArray.new()

	_data:writeInt(_nCmdID)
    _data:writeUInt(lock.uid)
    _data:writeInt(lock.fishid)
    _data:writeUInt(0)

    return _data
end

function write_CMD_C_AddScore(_nCmdID, _score ,_id)
	local _data = ByteArray.new()
	
	_data:writeInt(_nCmdID)
	_data:writeInt(_id)
	_data:writeInt(_score)
	_data:writeUInt(0)

	return _data
end

function GetValByFish( kind )
	local val = 0
	if kind == 0 or kind == 1 then
		val = 2
	elseif kind >= 2 and kind<=9 then
		val = kind+1
	elseif kind == 10 then
		val = 12
	elseif kind == 11 then
		val = 15
	elseif kind == 12 then
		val = 18
	elseif kind == 13 then
		val = 20
	elseif kind == 14 then
		val = 25
	elseif kind == 15 then
		val = 30
	elseif kind == 16 then
		val = 35	
	elseif kind == 17 then
		val = 100	
	elseif kind == 18 then
		val = 150	
	else
		val = 200		
	end	
	return val	
end

RES_EXT			= ".png";

MYRES = {};
--name path width, height, frames fps

--MYRES_NAME		= 1;
MYRES_PATH		= 1;
MYRES_WIDTH		= 2;
MYRES_HEIGHT	= 3;
MYRES_FRAMES	= 4;
MYRES_FPS		= 5;

MYRES_BKIMG		= 3;

MYRES["BACKIMG0"] = {"backimg/backimg0.png",1366,768,1,0};
MYRES["BACKIMG1"] = {"backimg/backimg1.png",1366,768,1,0};
MYRES["BACKIMG2"] = {"backimg/backimg2.png",1366,768,1,0};

MYRES_WAVES		= 31
MYRES["WAVE0"] = {"backimg/wave/1.png",512,512,1,0};
MYRES["WAVE1"] = {"backimg/wave/2.png",512,512,1,0};
MYRES["WAVE2"] = {"backimg/wave/3.png",512,512,1,0};
MYRES["WAVE3"] = {"backimg/wave/4.png",512,512,1,0};
MYRES["WAVE4"] = {"backimg/wave/5.png",512,512,1,0};
MYRES["WAVE5"] = {"backimg/wave/6.png",512,512,1,0};
MYRES["WAVE6"] = {"backimg/wave/7.png",512,512,1,0};
MYRES["WAVE7"] = {"backimg/wave/8.png",512,512,1,0};
MYRES["WAVE8"] = {"backimg/wave/9.png",512,512,1,0};
MYRES["WAVE9"] = {"backimg/wave/10.png",512,512,1,0};
MYRES["WAVE10"] = {"backimg/wave/11.png",512,512,1,0};
MYRES["WAVE11"] = {"backimg/wave/12.png",512,512,1,0};
MYRES["WAVE12"] = {"backimg/wave/13.png",512,512,1,0};
MYRES["WAVE13"] = {"backimg/wave/14.png",512,512,1,0};
MYRES["WAVE14"] = {"backimg/wave/15.png",512,512,1,0};
MYRES["WAVE15"] = {"backimg/wave/16.png",512,512,1,0};
MYRES["WAVE16"] = {"backimg/wave/17.png",512,512,1,0};
MYRES["WAVE17"] = {"backimg/wave/18.png",512,512,1,0};
MYRES["WAVE18"] = {"backimg/wave/19.png",512,512,1,0};
MYRES["WAVE19"] = {"backimg/wave/20.png",512,512,1,0};
MYRES["WAVE20"] = {"backimg/wave/21.png",512,512,1,0};
MYRES["WAVE21"] = {"backimg/wave/22.png",512,512,1,0};
MYRES["WAVE22"] = {"backimg/wave/23.png",512,512,1,0};
MYRES["WAVE23"] = {"backimg/wave/24.png",512,512,1,0};
MYRES["WAVE24"] = {"backimg/wave/25.png",512,512,1,0};
MYRES["WAVE25"] = {"backimg/wave/26.png",512,512,1,0};
MYRES["WAVE26"] = {"backimg/wave/27.png",512,512,1,0};
MYRES["WAVE27"] = {"backimg/wave/28.png",512,512,1,0};
MYRES["WAVE28"] = {"backimg/wave/29.png",512,512,1,0};
MYRES["WAVE29"] = {"backimg/wave/30.png",512,512,1,0};
MYRES["WAVE30"] = {"backimg/wave/31.png",512,512,1,0};

-- 2 Ö¡ ÐèÒª¶àÉÙÊ±¼ä 1 / 10 * 2
MYRES["COCKLES"] = {"backimg/cockles.png",552,768,2,10};

function isempty(o)
	return o == nil or o == '' or o == "";
end

MYRES_FISHES    = 24
MYRES["FISH0"] = {"FISH/0%02d.png",70,24,12,10};
MYRES["FISHDIE0"] = {"FISH/die0%02d.png",74,27,5,10};
MYRES["FISH1"] = {"FISH/1%02d.png",54,24,16,10}; --{"FISH/1%02d.png",41,39,6,10}; --
MYRES["FISHDIE1"] = {"FISH/die1%02d.png",54,28,3,10}; --{"FISH/die1%02d.png",51,44,2,10}; --
MYRES["FISH2"] = {"FISH/2%02d.png",78,48,24,10};
MYRES["FISHDIE2"] = {"FISH/die2%02d.png",78,47,3,10};
MYRES["FISH3"] = {"FISH/3%02d.png",100,64,24,10};
MYRES["FISHDIE3"] = {"FISH/die3%02d.png",105,62,10,10};
MYRES["FISH4"] = {"FISH/4%02d.png",124,45,24,10};
MYRES["FISHDIE4"] = {"FISH/die4%02d.png",124,50,3,10};
MYRES["FISH5"] = {"FISH/5%02d.png",105,72,25,10};
MYRES["FISHDIE5"] = {"FISH/die5%02d.png",105,76,6,10};
MYRES["FISH6"] = {"FISH/6%02d.png",120,58,36,10};
MYRES["FISHDIE6"] = {"FISH/die6%02d.png",124,50,3,10};
MYRES["FISH7"] = {"FISH/7%02d.png",132,74,20,10};
MYRES["FISHDIE7"] = {"FISH/die7%02d.png",132,71,6,10};
MYRES["FISH8"] = {"FISH/8%02d.png",198,112,24,10};
MYRES["FISHDIE8"] = {"FISH/die8%02d.png",198,159,4,10};
MYRES["FISH9"] = {"FISH/9%02d.png",135,145,16,10};
MYRES["FISHDIE9"] = {"FISH/die9%02d.png",135,108,7,10};
MYRES["FISH10"] = {"FISH/10%02d.png",190,84,24,10};
MYRES["FISHDIE10"] = {"FISH/die10%02d.png",190,200,4,10};
MYRES["FISH11"] = {"FISH/11%02d.png",158,164,12,10};
MYRES["FISHDIE11"] = {"FISH/die11%02d.png",158,158,4,10};
MYRES["FISH12"] = {"FISH/12%02d.png",220,88,24,10};
MYRES["FISHDIE12"] = {"FISH/die12%02d.png",220,92,4,10};
MYRES["FISH13"] = {"FISH/13%02d.png",285,97,20,10};
MYRES["FISHDIE13"] = {"FISH/die13%02d.png",285,114,3,10};
MYRES["FISH14"] = {"FISH/14%02d.png",210,260,24,10};
MYRES["FISHDIE14"] = {"FISH/die14%02d.png",210,252,6,10};
MYRES["FISH15"] = {"FISH/15%02d.png",300,140,24,10};
MYRES["FISHDIE15"] = {"FISH/die15%02d.png",312,163,14,10};
MYRES["FISH16"] = {"FISH/16%02d.png",300,140,24,10};
MYRES["FISHDIE16"] = {"FISH/die16%02d.png",321,153,12,10};
MYRES["FISH17"] = {"FISH/17%02d.png",512,305,9,10};
MYRES["FISHDIE17"] = {"FISH/die17%02d.png",523,270,6,10};
MYRES["FISH18"] = {"FISH/18%02d.png",203,251,3,3};
--MYRES["FISHDIE18"] = {"",0,0};
MYRES["FISH19"] = {"FISH/19%02d.png",530,185,7,10};
--MYRES["FISHDIE19"] = {"",0,0};
MYRES["FISH20"] = {"FISH/20%2d.png",300,262,15,10};
--MYRES["FISHDIE20"] = {"",0,0};
MYRES["FISH21"] = {"FISH/21%02d.png",170,170,6,10};
--MYRES["FISHDIE21"] = {"",0,0};
MYRES["FISH22"] = {"FISH/22%02d.png",160,160,5,10};
--MYRES["FISHDIE22"] = {"",0,0};
MYRES["FISH23"] = {"FISH/23%02d.png",200,200,5,10};
--MYRES["FISHDIE23"] = {"",0,0};

MYRES["FISH25"] = {"FISH/25%2d.png",200,120,22,10};
MYRES["FISH27"] = {"FISH/27%2d.png",480,360,5,10};
MYRES["FISH26"] = {"FISH/26%02d.png",514,298,15,10};
MYRES["FISHDIE26"] = {"FISH/die26%02d.png",514,298,12,10};

------------

MYRES["qq1"] = {"qq/q1.png",67,83,1,1};
MYRES["qq2"] = {"qq/q2.png",69,88,1,1};
MYRES["qqnum1"] = {"qq/num1.png",23,35,10,10};
MYRES["qqnum2"] = {"qq/num2.png",28,43,10,10};
MYRES["qqpopo"] = {"qq/popo.png",138,140,1,1};

MYRES["PROP0"] = {"prop/prop0.png",120,120,1,1};
MYRES["PROP1"] = {"prop/prop1.png",245,245,1,1};
MYRES["PROP2"] = {"prop/prop2.png",120,120,1,1};

MYRES["BULLET0"] = {"PLAYER/bullet0%d.png",31,35,2,10};
MYRES["BULLET1"] = {"PLAYER/bullet1%d.png",31,35,2,10};
MYRES["BULLET2"] = {"PLAYER/bullet2%d.png",31,35,2,10};
MYRES["BULLET3"] = {"PLAYER/bullet3%d.png",43,57,2,10};
MYRES["BULLET4"] = {"PLAYER/bullet4%d.png",31,35,2,10};
MYRES["BULLET5"] = {"PLAYER/bullet5%d.png",31,35,2,10};
MYRES["BULLET6"] = {"PLAYER/bullet6%d.png",31,35,2,10};
MYRES["BULLET7"] = {"PLAYER/bullet7%d.png",43,57,2,10};

MYRES["cannon"] = {"cannon/cannon.png",78,118,1,1};
MYRES["cannon1"] = {"cannon/cannon1.png",92,121,1,1};
MYRES["cannon2"] = {"cannon/cannon2.png",96,133,1,1};
MYRES["cannon3"] = {"Player/cardcannon.png",96,133,1,1};

MYRES["NET0"] = {"PLAYER/net0%02d.png",360,360,12,10};
MYRES["NET1"] = {"PLAYER/net1%02d.png",360,360,12,10};
MYRES["NET2"] = {"PLAYER/net2%02d.png",360,360,12,10};
MYRES["NET3"] = {"PLAYER/net3%02d.png",239,239,12,10};
MYRES["NET4"] = {"PLAYER/net4%02d.png",360,360,12,10};
MYRES["NET5"] = {"PLAYER/net5%02d.png",360,360,12,10};
MYRES["NET6"] = {"PLAYER/net6%02d.png",360,360,12,10};
MYRES["NET7"] = {"PLAYER/net7%02d.png",239,239,12,10};

MYRES["GOLD0"] = {"PLAYER/GOLD0%02d.png",48,48,12,10};
MYRES["GOLD1"] = {"PLAYER/GOLD1%02d.png",54,54,12,10};
MYRES["GOLD2"] = {"PLAYER/GOLD2%02d.png",78,77,12,10};
MYRES["GOLD3"] = {"PLAYER/GOLD3%02d.png",24,24,12,10};
MYRES["GOLD4"] = {"PLAYER/GOLD4%02d.png",27,27,12,10};
MYRES["GOLD5"] = {"PLAYER/GOLD5%02d.png",39,39,12,10};

MYRES["SCORE"] = {"PLAYER/SCORE%02d.png",30,47,10,10};
MYRES["FLYSCORE"] = {"PLAYER/FLYSCORE%02d.png",14,20,10,10};

MYRES["lockcard"] = {"PLAYER/lockcard_li.png",65,83,12,10};

MYRES["FIRE"] = {"PLAYER/FIRE%02d.png",108,51,2,10};
MYRES["fireboard"] = {"PLAYER/fireboard.png",209,94,1,1};
MYRES["fireboard1"] = {"PLAYER/fireboard1.png",209,94,1,1};
MYRES["fireseat"] = {"PLAYER/fireseat.png",93,42,1,1};

MYRES["CURSOR"] = {"ui/curson.png",127,135,5,10};
MYRES["CURSOR1"] = {"MANAGER/CURSOR1.png",23,23,1,1};
MYRES["nomoney"] = {"MANAGER/nomoney.png",132,68,1,1};

MYRES["cirmoney"] = {"MANAGER/cirmoney%02d.png",27,35,10,10};
MYRES["cir"] = {"PLAYER/cir%02d.png",256,256,10,10};
MYRES["cir1"] = {"PLAYER/cir1%02d.png",300,300,10,10};

MYRES["wordback"] = {"MANAGER/wordback.png",1250,105,1,1};
MYRES["firemoney"] = {"MANAGER/firemoney",14,20,10,10};

MYRES["border_bottom"] = {"WIN/border_bottom.png",1280,3,1,1};
MYRES["border_left"] = {"WIN/border_left.png",3,736,1,1};
MYRES["border_right"] = {"WIN/border_right.png",3,736,1,1};
MYRES["border_top"] = {"WIN/border_top.png",1280,29,1,1};
MYRES["bottombanner"] = {"WIN/bottombanner.png",1279,51,1,1};
MYRES["closebutton"] = {"WIN/closebutton.png",58,24,1,1};

MYRES["sound"] = {"WIN/sound.png",40,40,1,1};
MYRES["sound1"] = {"WIN/sound1.png",40,40,1,1};
MYRES["effect"] = {"WIN/effect.png",40,40,1,1};
MYRES["effect1"] = {"WIN/effect1.png",40,40,1,1};

MYRES["btnhelp"] = {"WIN/btnhelp.png",30,30,1,1};
MYRES["btnf2"] = {"WIN/btnf2.png",30,30,1,1};
MYRES["btniknow"] = {"WIN/btniknow.png",223,92,1,1};
MYRES["help"] = {"WIN/help.png",996,641,1,1};
MYRES["helpclose"] = {"WIN/helpclose.png",25,22,1,1};

--Òª»»³É+-
MYRES["keyup"] = {"WIN/keyup.png",30,30,1,1};
MYRES["keydown"] = {"WIN/keydown.png",30,30,1,1};
MYRES["moneyicon"] = {"WIN/moneyicon.png",23,23,1,1};
MYRES["namebk"] = {"WIN/namebk.png",234,32,1,1};
MYRES["namebk1"] = {"WIN/namebk1.png",94,23,1,1};

------------

--AudioEngine.playMusic(MUSIC_FILE, true) -- ²¥·ÅÒôÀÖ
--AudioEngine.stopMusic()  -- Í£Ö¹±³¾°ÒôÀÖ  
--AudioEngine.pauseMusic() -- ÔÝÍ£ÒôÀÖ  
--AudioEngine.resumeMusic() -- ¼ÌÐø²¥·ÅÒôÀÖ

--m_nSoundId = AudioEngine.playEffect(EFFECT_FILE)   -- ²¥·ÅÒôÐ§  
--AudioEngine.stopEffect(m_nSoundId) -- Í£Ö¹ÒôÐ§ 
--preloadBackgroundMusic
--preloadEffect


return GameData