
local MessageBox = class("MessageBox", function ( ... )
    return display.newLayer(cc.c4b(0,0,0,0))   
end)

function MessageBox:ctor(content,funcok,funccancel)
    self.content    = content
    self.funcok     = funcok
    self.funccancel = funccancel

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
end

function MessageBox:onEnter()
    self:init()
end

function MessageBox:init()
    -- message background
    self.bg_msg = display.newSprite(create_uipath("popup/bg_msg.png")):setPosition(display.center)
        :setScale(0):addTo(self)
    local size = self.bg_msg:getContentSize()

    -- label content
    local lab_content = cc.Label:createWithSystemFont(self.content,"",28,{size.width-100,size.height-220}
        ,cc.TEXT_ALIGNMENT_CENTER,cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    lab_content:setAnchorPoint(cc.p(0.5,1))
    lab_content:setPosition(cc.p(size.width/2,size.height-90))
    lab_content:setColor(cc.WHITE):addTo(self.bg_msg)

    -- button confirm
    local btn_confirm = ccui.Button:create(create_uipath("popup/btn_msg_confirm.png"));
    btn_confirm:setPosition(size.width/4,90)
    btn_confirm:addClickEventListener(handler(self,self.onConfirmClick))
    btn_confirm:addTo(self.bg_msg)

    -- button cancel
    local btn_cancel = ccui.Button:create(create_uipath("popup/btn_msg_cancel.png"));
    btn_cancel:setPosition(size.width/4*3,90)
    btn_cancel:addClickEventListener(handler(self,self.onCancelClick))
    btn_cancel:addTo(self.bg_msg)
end

function MessageBox:onConfirmClick()
    if self.funcok then
        self.funcok()
    end
    -- self:removeFromParent()
end

function MessageBox:onCancelClick()
    if self.funccancel then
        self.funccancel()
    end
    self:removeFromParent()
end

function MessageBox:showTo(parent)
    self:addTo(parent)

    self:runAction(cc.FadeTo:create(0.3,0.7*255))
    self.bg_msg:runAction(cc.EaseElasticOut:create(cc.ScaleTo:create(0.3,1.0),0.5))
end

return MessageBox


