
local MapState = {READY=0, PAUSE=1, END=3}

local FishLayer = class("FishLayer", function ( ... )
    return display.newLayer()
end)

function FishLayer:init()
    self.m_tagAllFishes = {}
    self.m_fMoveType = 0
    -- self.m_fUpdateFishPos = false
    self.m_state = MapState.READY

    -- 直线鱼移动
    -- self.line_count = 0

    -- 圆形鱼移动
    self:initCircleFish()
    
end

function FishLayer:ctor()
    self:init()
end

function FishLayer:AddCurveFish(f)
    -- self.m_fMoveType = CURVE_MOVE

    _path = g_point:getPathFromLua(f.pathtype,f.pathidx)
    -- log("=====>len", #_path)
    if _path == nil then
        log("_path error", f.pathtype, f.pathidx)
    end

    for i=1,f.num do
        local fish = GameFish.new(f.fishkind, f.idpos[i], f.lPropType, f.num, f.lMoveType, f.val):addTo(self) 
        fish:CreateCurveFish(_path)
        table.insert(self.m_tagAllFishes, fish)
        if self.m_state == MapState.PAUSE then
            fish.fish_state = GameData.Fish_Stop
        end
    end
end
function FishLayer:AddLineFish(f)
    self.m_fMoveType = LINE_MOVE
    for i=1,f.num do
        local fish = GameFish.new(f.fishkind, f.idpos[i], f.lPropType, f.num, f.lMoveType):addTo(self)
        fish:CreateLineFish(f.start_pos, f.end_pos, f.stoppos, 1000)
        -- if f.fishkind > 14 then
        --     self.line_count = self.line_count + 1
        -- end
        -- fish:LineFishMove(f.start_pos, f.end_pos, f.stoppos, self.line_count, self.m_fUpdateFishPos)

        table.insert(self.m_tagAllFishes, fish)
    end
end
function FishLayer:AddCircleFish(f)
    self.m_fMoveType = CIRCLE_MOVE
    -- log("====>", f.fishkind, f.start_pos.x, f.start_pos.y, f.end_pos.x, f.end_pos.y, f.num, f.stoppos, f.idpos[1].curpos)
    for i=1,f.num do
        local fish = GameFish.new(f.fishkind, f.idpos[i], f.lPropType, f.num, f.lMoveType):addTo(self) 
        fish:CreateCircle(f.start_pos, self.m_fCircleRol, f.end_pos.x, 900)

        table.insert(self.m_tagAllFishes, fish) 

        if self.circle_fishes[f.fishkind] == nil then
            self.circle_fishes[f.fishkind] = {}
        end
        table.insert(self.circle_fishes[f.fishkind], fish)

        -- if f.fishkind > 10 or f.idpos[i].curpos > 0 then
        --     local fish = GameFish.new(f.fishkind, f.idpos[i], f.lPropType,f.num, f.lMoveType):addTo(self) 
        --     fish:CreateCircle(f.start_pos, self.m_fCircleRol, f.end_pos.x, 900)
        --     -- fish:CreateCircle(f.start_pos, self.m_fCircleAngle, f.end_pos.x, 900)
        --     fish.fish_state = GameData.Fish_Move

        --     table.insert(self.m_tagAllFishes, fish) 
        --     table.insert(self.circle_fishes[fish._kind], fish)

        --     if f.fishkind > 10 then
        --         fish:setVisible(false)
        --         self.m_fCenterFish = fish
        --     end
        -- else
        --     if not utils.contain_value(self.temp_circle_id, f.idpos[i].id  ) then
        --         -- log("circle_fishes_data=======>", f.fishkind, i)
        --         table.insert(self.circle_fishes_data[f.fishkind], {f,i}) 
        --         table.insert(self.temp_circle_id,f.idpos[i].id)  
        --     end     
        -- end
    end
end

-- function FishLayer:setEnterBackgroundTime(time)
--     self.m_fEnterBkTime = time
-- end

--***************************Circle Move************************************
function FishLayer:initCircleFish()
    self.m_fCircleRol = 0
    self.m_pLeaveFishArr = {}
    self.circle_fishes = {}
end

-- function FishLayer:fishCreate( i, fish_kind , interval )
--     if #self.circle_fishes_data[fish_kind] < 1 then
--         return
--     end    
    
--     local fish_index = self.circle_update[i] + 1
--     local fishes = self.circle_fishes_data[fish_kind]      
--     if fish_index <= #fishes then
--         local v = fishes[fish_index][1]
--         local index = fishes[fish_index][2]
--         local f0 = GameFish.new(v.fishkind, v.idpos[index], v.lPropType,v.num, v.lMoveType ,nil):addTo(self) 
--         if (self.m_fUpdateTimer / interval)*0.1 > self.m_fEnterBkTime then
--             f0:CreateCircle(v.start_pos, self.m_fCircleRol, v.end_pos.x,900, self.m_fUpdateFishPos)
--             -- f0:CreateCircle(v.start_pos, self.m_fCircleAngle, v.end_pos.x,900, self.m_fUpdateFishPos)
--         else
--             f0:CreateCircle(v.start_pos, self.m_fCircleRol, v.end_pos.x,900, self.m_fUpdateFishPos, self.m_fEnterBkTime)
--             -- f0:CreateCircle(v.start_pos, self.m_fCircleAngle, v.end_pos.x,900, self.m_fUpdateFishPos, self.m_fEnterBkTime)
--         end    
        
--         -- f0:setVisible(false)
--         f0.fish_state = GameData.Fish_Move
--         table.insert(self.circle_fishes[v.fishkind] , f0)
--         table.insert(self.m_tagAllFishes,f0)
--     end
--     self.circle_update[i] = self.circle_update[i] + 1    
-- end

function FishLayer:overCircleMove()
    self:runAction(cc.Sequence:create(
            cc.CallFunc:create(function ()
                local _kind = self.m_pLeaveFishArr[1]
                self:circleLeave(_kind)
            end),
            cc.DelayTime:create(1.5),
            cc.CallFunc:create(function ()
                local _kind = self.m_pLeaveFishArr[2]
                self:circleLeave(_kind)
            end),
            cc.DelayTime:create(1.5),
            cc.CallFunc:create(function ()
                local _kind = self.m_pLeaveFishArr[3]
                self:circleLeave(_kind)
            end),
            cc.DelayTime:create(1.5),
            cc.CallFunc:create(function ()
                local _kind = self.m_pLeaveFishArr[4]
                self:circleLeave(_kind)
            end),
            cc.DelayTime:create(1.5),
            cc.CallFunc:create(function ()
                local _kind = self.m_pLeaveFishArr[5]
                self:circleLeave(_kind)
            end),
            cc.CallFunc:create(function ()
                -- reset circle fish data
                self:initCircleFish()
            end)
        ))  
    -- self.update_fishes = false       
end

function FishLayer:circleLeave( i )
    local kind = i --self.circle_kind[i]
    local fishes = self.circle_fishes[kind] 
    for k,v in pairs(fishes) do
        if v._target then
            -- v._move_type = 0
            v.fish_state = GameData.Fish_Stop
            local start_x,start_y = v._target:getPosition()
            local distance = 1000
            local end_x = start_x + distance*math.cos(-v.m_tagCurRol)
            local end_y = start_y + distance*math.sin(-v.m_tagCurRol)
    
            local dis = math.sqrt( math.pow((start_x-end_x),2) + math.pow((start_y-end_y),2) )
            local speed = 160
            local t = dis / speed
            local move_act = cc.MoveTo:create(t,cc.p(end_x,end_y))
            local move_done = function()
                v.fish_state = GameData.Fish_Die
            end
            v._target:runAction(cc.Sequence:create(move_act, cc.CallFunc:create(move_done)))
        end    
    end
end
--***************************Circle Move End************************************

function FishLayer:updateScheduler()
    -- for i,v in ipairs(self.m_tagAllFishes) do
    --     if v then
    --         v:updateScheduler()
    --     end    
    -- end

    for k_f,_fish in ipairs(self.m_tagAllFishes) do
        if _fish then
            _fish:updateScheduler()
            
            if (_fish.fish_state == GameData.Fish_Move or _fish.fish_state == GameData.Fish_Stop)
                and _fish.m_CurveIndex > 0 then
                -- 所有玩家都判断一下有没有碰撞
                for i=1,GAME_PLAYER do
                    local _player = Layer_LuaClient.m_pGameLayer.m_pGamePlayerArr[i]
                    if _player then
                        if _player.m_pMarkFish ~= nil and _player.m_pMarkFish._id ~= _fish._id then
                            -- print("Not Lock Fish")
                        else
                            self:JudgeFishCollide(_player, _fish)
                        end
                    end
                end
            end
        end
    end

end

function FishLayer:JudgeFishCollide(_player, _fish)
    local _bCollide = false
    
    for k,v in ipairs(_player.m_pGameCannon.m_bulletvec) do
        local _fishPos = cc.p(_fish._target:getPositionX(),_fish._target:getPositionY())
        local _fRol = math.rad(_fish._target:getRotation())
        local _scale = _fish._target:getScale()

        local _bulletPos = cc.p(v.m_bullet:getPositionX(),v.m_bullet:getPositionY())
        _bCollide = self:InFishSprite(_bulletPos, _fishPos, _fRol, _fish._target, _scale)
        
        -- for i=1,#v.m_tagCollidePosArr do
        --     local _pos = v.m_tagCollidePosArr[i]
        --     _bCollide = self:InFishSprite(_pos, _fishPos, _fRol, _fish._target, _scale)

        --     -- 碰撞成功
        --     if _bCollide then
        --         break
        --     end
        -- end

        -- 碰撞成功
        if _bCollide then
            self:doCollide(_player, v, _fish)
            -- log("碰撞成功")
            break
        end
    end
end

function FishLayer:InFishSprite(_bulletPos, _fishPos, _fRol, _sprite, _scale)
    local _point = self:convertPos(_bulletPos, _fishPos, _fRol)
    local size = _sprite:getContentSize()
    size.width = size.width*_scale
    size.height = size.height*_scale

    -- 判断该点是否在矩形内
    if math.abs(_point.x) <= size.width*0.5 and math.abs(_point.y) <= size.height*0.5 then
        return true
    end
    return false
end

function FishLayer:doCollide(_player, _bullet, _fish)
    -- 向服务器发送碰撞
    Layer_LuaClient:sendUserCollide(_fish._id, _player.nViewID, _bullet.m_idx)

    if _fish._kind == FISH_LI1 or _fish._kind == FISH_DRAGON then
        _fish:changeColor()    
    end 

    -- 播放撒网动作
    _bullet:addFishNet()
    _player.m_pGameCannon:removeBullet(_bullet)
end

-- function FishLayer:InFishSprite(_bulletPos, _fishPos, _fRol, _sprite, _scale)
--     -- 两点之间的距离
--     local _dir = cc.pMul(cc.pSub(_bulletPos, _fishPos), 1/_scale)

--     local size = _sprite:getContentSize()
--     -- 以较大的边做一个矩形
--     local fLength = 0
--     if size.height > size.width then
--         fLength = size.height
--     else
--         fLength = size.width
--     end

--     -- 判断该点是否在矩形内
--     if math.abs(_dir.x) > fLength*0.5 or math.abs(_dir.y) > fLength*0.5 then
--         return false
--     end

--     local s = cc.pGetLength(_dir)
--     local _rol = utils.GetRol(_dir)
--     _rol = _fRol - _rol - math.pi/2
--     _dir.y = math.sin(_rol)*s + size.height*0.5
--     _dir.x = math.cos(_rol)*s + size.width*0.5

--     if _dir.x > 0 and _dir.x < size.widht and _dir.y > 0 and _dir.y < size.height then
--         -- 获取纹理的透明度
--     end
--     return false
-- end

function FishLayer:convertPos(a, o, rol)
    -- 计算a以O为圆点的坐标
    a.x = a.x - o.x
    a.y = a.y - o.y

    -- 旋转rol度后的坐标
    local _pos = {}
    _pos.x = a.x*math.cos(rol)-a.y*math.sin(rol)
    _pos.y = a.x*math.sin(rol)+a.y*math.cos(rol)
    return _pos
end

function FishLayer:getColor(_point, _sprite)
    -- Create a new Texture to get the pixel datas.
    local _size = _sprite:getContentSize()
    local _render = cc.RenderTexture:create(_size.width, _size.height)
    -- Render the sprite to get a new texture.
    _render:begin()
    _render:visit() -- 3.0的渲染是异步的,已无效
    _render:endToLua()

    local _image = _render:newImage(false)
end
function FishLayer:getColor(_point, _image)

--     ccColor4B getColor4B(float x, float y)
-- {
--     ccColor4B color = { 0, 0, 0, 0 };
--     int ix = (int)x - 1;
--     int iy = (int)y - 1;
--     m_pData += (iy*getWidth() + ix) * 4;
--     color.r = *(m_pData++);
--     color.g = *(m_pData++);
--     color.b = *(m_pData++);
--     color.a = *(m_pData++);
--     return color;
-- };
end

function FishLayer:setMapState()
    
end

-- function FishLayer:resumeFish()
--     self:resetFish()
--     -- self:resumeCircleMove()
-- end

function FishLayer:resetFish()
    self:init()
    self:removeAllChildren()
    -- self.line_count = 0
    -- self.m_fMoveType = 0
    -- self.m_fUpdateFishPos = false
end

function FishLayer:fishResumeMove(stoppos)
    for i,v in ipairs(self.m_tagAllFishes) do
        v:resumeLineMove(stoppos)
    end
    -- self.line_count = 0
    -- self.m_fMoveType = 0
    -- self.m_fUpdateFishPos = false
end

function FishLayer:resumeCircleMove(fish_kinds)
    -- for i,v in ipairs(self.m_tagAllFishes) do
    --     if v:resumeCircleMove() then
    --         break
    --     end
    -- end
    log("stop circle")
    for i=1,5 do
        table.insert(self.m_pLeaveFishArr,fish_kinds[i])
    end
    self:overCircleMove()
end

function FishLayer:onPause()
    self.m_state = MapState.PAUSE
end
function FishLayer:onResume()
    self.m_state = MapState.READY
end

function FishLayer:killFish()
    
end

function FishLayer:removeFish(fish)
    fish:clearFish()
    utils.removeValue(self.m_tagAllFishes,fish)
    fish = nil
end
function FishLayer:removeAllFish()
    for i=#self.m_tagAllFishes,1,-1 do
        self.m_tagAllFishes[i]:clearFish()
        table.remove(self.m_tagAllFishes,i)
    end
end

return FishLayer


