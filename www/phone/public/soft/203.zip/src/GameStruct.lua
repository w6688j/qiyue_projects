local GameStruct = {}

function GameStruct.CMD_S_CanEnter( ... )
	local _data = {}
	_data.bCanEnter=0
	_data.lBringScore=0
	return _data
end

function GameStruct.CMD_S_TableInfo( ... )
	local _data = {}
	_data.bExits={0,0,0,0,0,0,0,0}
	_data.lUserMoney={0,0,0,0,0,0,0,0}
	return _data
end

function GameStruct.CMD_S_StatusFree( ... )
	local _data = {}
	_data.lCellScore=0
	_data.lCellMinScore=0
	_data.lCellMaxScore=0
	_data.lTaxScore=0
	_data.lBringScore=0

	_data.nStartTime=0
	_data.nBetTime=0
	_data.nEndTime=0
	return _data
end

function GameStruct.CMD_S_StatusPlay( ... )
	local _data = {}
	_data.lCellScore=0
	_data.lTurnMaxScore=0
	_data.lTurnLessScore=0
	_data.lCellMaxScore=0
	_data.lAddLessScore=0

	_data.lTableScore={0,0,0,0,0,0,0,0}
	_data.lTotalScore={0,0,0,0,0,0,0,0}
	_data.nCenterCnt=0
	_data.lCenterScore={0,0,0,0,0,0,0,0}
	_data.lCenterScoreTotal=0

	_data.wDUser=0
	_data.wCurrentUser=0
	_data.cbPlayStatus={0,0,0,0,0,0,0,0}
	_data.cbShowHand={0,0,0,0,0,0,0,0}
	_data.cbGiveup={0,0,0,0,0,0,0,0}
	_data.cbBalanceCount=0

	_data.cbCenterCardData={0,0,0,0,0}
	_data.cbHandCardData={0,0}

	_data.lBringMoney=0

	_data.nStartTime=0
	_data.nBetTime=0
	_data.nEndTime=0

	_data.nLeftBetTime=0
	return _data
end

function GameStruct.CMD_S_GameStart( ... )
	local _data = {}
	_data.wCurrentUser=0
	_data.wDUser=0
	_data.wMinChipInUser=0
	_data.wMaxChipInUser=0	
	_data.lCellScore=0
	_data.lTurnMaxScore=0
	_data.lTurnLessScore=0
	_data.lAddLessScore=0
	_data.cbCardData={{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0}}
	_data.cbAllData={{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0}}
	return _data
end

function GameStruct.CMD_S_AddScore( ... )
	local _data = {}
	_data.nActionState=0
	_data.wCurrentUser=0
	_data.wAddScoreUser=0
	_data.lAddScoreCount=0	
	_data.lTurnLessScore=0
	_data.lTurnMaxScore=0
	_data.lAddLessScore=0
	_data.cbShowHand={0,0,0,0,0,0,0,0}
	_data.lCell=0
	return _data
end

function GameStruct.CMD_S_GiveUp( ... )
	local _data = {}
	_data.wGiveUpUser=0
	_data.lLost=0
	_data.lCell=0
	return _data
end

function GameStruct.CMD_S_CenterPool( ... )
	local _data = {}
	_data.nCnt=0
	_data.lCenterPool={0,0,0,0,0,0,0,0}
	return _data
end

function GameStruct.CMD_S_SendCard( ... )
	local _data = {}
	_data.cbPublic=0
	_data.wCurrentUser=0
	_data.cbSendCardCount=0
	_data.cbCenterCardData={0,0,0,0,0}
	return _data
end

function GameStruct.CMD_S_GameEnd( ... )
	local _data = {}
	_data.cbTotalEnd=0
	_data.lGameTax={0,0,0,0,0,0,0,0}
	_data.lGameScore={0,0,0,0,0,0,0,0}
	_data.lWinScore={0,0,0,0,0,0,0,0}

	_data.cbCardData={{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0},{0,0}}
	_data.cbLastCenterCardData={{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0}}

	_data.lUserScore={0,0,0,0,0,0,0,0}

	_data.wWinUser={0,0,0,0,0,0,0,0}

	_data.wWinUserCnt=0

	_data.wPoolOwner={0,0,0,0,0,0,0,0}
	_data.wPoolCnt=0


	return _data
end

return GameStruct
