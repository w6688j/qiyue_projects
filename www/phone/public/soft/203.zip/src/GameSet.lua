

local GameSet= class("GameSet", function ( ... )
    return display.newLayer()   
end)

function GameSet:ctor()
    local mask = cc.LayerColor:create(cc.c4b( 0,0,0,160))
        :addTo(self)   
    local m_listener = cc.EventListenerTouchOneByOne:create()
    local function onTouchBegan(touch,event)
        local s = self.bg:getBoundingBox()
        local rect = cc.rect(s.x,s.y,s.width,s.height)

        if not cc.rectContainsPoint(rect,touch:getLocation()) then
            self:closeFun()
        end           
        return true
    end
    m_listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    local eventDispather = self:getEventDispatcher()
    eventDispather:addEventListenerWithSceneGraphPriority(m_listener,self)
    m_listener:setSwallowTouches(true) 
    self.m_listener = m_listener 
        
    local bg = display.newSprite(create_uipath("ui/setbg.png")):addTo(self)
    	:setPosition(display.cx,display.cy)
    utils.button(create_uipath("ui/btn_close.png"),create_uipath("ui/btn_close.png"),nil,handler(self,self.closeFun))
    	:addTo(bg)
    	:setPosition(bg:getContentSize().width-10,bg:getContentSize().height-36)
    self.bg = bg
    bg:setScale(1.2)
    local act = cc.EaseElasticOut:create(cc.ScaleTo:create(0.3, 1.0), 0.5)
    bg:runAction(act) 
    self.bg = bg
    self:initData()	
    self:initUI()	   
end

function GameSet:initData()
	self.init_pos = {}
		
	if GAMESOUND.getIsSound() then
		self.audio_open = 1
		table.insert(self.init_pos,38)
	else
		self.audio_open = 0
		table.insert(self.init_pos,110)
	end

	if GAMESOUND.getIsMusic() then
		self.music_open = 1
		table.insert(self.init_pos,38)
	else
		self.music_open = 0	
		table.insert(self.init_pos,110)
	end	
end

function GameSet:initUI()
	display.newSprite(create_uipath("ui/settitle.png")):addTo(self.bg)
		:setPosition(self.bg:getContentSize().width/2,self.bg:getContentSize().height-36)
	for i=1,2 do
		display.newSprite(create_uipath("ui/set"..i..".png")):addTo(self.bg)
			:setPosition(160,20+80*i)
		local item = display.newSprite(create_uipath("ui/set_itembg.png")):addTo(self.bg)
			:setPosition(340,20+80*i)
		utils.label("关",16,cc.c3b(177, 194, 212)):addTo(item):setPosition(40,item:getContentSize().height/2)
		utils.label("开",16,cc.c3b(177, 194, 212)):addTo(item):setPosition(110,item:getContentSize().height/2)
		utils.button(create_uipath("ui/set_itembtn.png"),create_uipath("ui/set_itembtn.png"),nil,handler(self,self.btnCallFun)):addTo(item)
			:setPosition(self.init_pos[i],item:getContentSize().height/2)
			:setTag(i)			
	end				
end

function GameSet:btnCallFun( sender )
	local tag = sender:getTag()
	if tag == 1 then--音效
		if self.audio_open == 1 then
        	self.audio_open = 0
        	sender:setPositionX(110)
        	GAMESOUND.stopEffects()
        	GAMESOUND.closeSound()    
    	else
        	self.audio_open = 1
        	sender:setPositionX(38)
        	GAMESOUND.openSound()
    	end
	elseif tag == 2 then--音乐
		if self.music_open == 1 then
        	self.music_open = 0
        	sender:setPositionX(110)
        	GAMESOUND.stopBGM()
        	GAMESOUND.closeMusic()  
    	else
        	self.music_open = 1
        	sender:setPositionX(38)
        	GAMESOUND.openMusic()
        	GAMESOUND.playBGM()
    	end
	end	
end

function GameSet:closeFun()
    utils.setTimeout(0,function ()
        self.m_listener:setSwallowTouches(false) 
        eventDispatcher:removeEventListener(self.m_listener)
        self:removeFromParent()
    end)
	
end

return GameSet


