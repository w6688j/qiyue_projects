
local GameUILayer= class("GameUILayer", function ( ... )
    return display.newLayer()  
end)

function GameUILayer:ctor(user,money) 
	--money = 100085000
	self.uilayer = cc.Layer:create():addTo(self)
    local bottom = display.newSprite(create_uipath("ui/bottombg.png")):addTo(self.uilayer)
    bottom:setPosition(display.cx,bottom:getContentSize().height/2)
    self.bottom = bottom
    self.user = user
    --头像会员
    -- local img = self:getClothImg(user.cloth) 
    -- display.newSprite(img):addTo(self.uilayer)
    --     :setPosition(100,26):setScale(0.7) 
    -- if user.vip ~= 0 and user.valitime - os.time() > 0 then
    --     utils.label("vip"..user.vip):addTo(self.uilayer)
    --         :setPosition(200,40) 
    -- end   
    local name_label = utils.label( iconv.TCNTCP(user.name),16,nil,0,0.5 ):addTo(bottom)
        :setPosition(400,16)         

    display.newSprite(create_uipath("ui/gold_icon.png")):addTo(bottom)
    	:setPosition(bottom:getContentSize().width/2-30,16)
    display.newSprite(create_uipath("ui/ticket_icon.png")):addTo(bottom)
    	:setPosition(bottom:getContentSize().width/2+175,16)
    self.money_label = cc.LabelAtlas:_create("0",create_uipath("ui/money_num.png"),10,15,string.byte('.')):addTo(bottom)	
    	:setPosition(bottom:getContentSize().width/2+100,15)
    	:setAnchorPoint(cc.p(1,0.5))	
    self.money_label:setString( self:formatNumber(money,1) )		
    self.ticket = GetBagTickets()
    self.ticket_label = cc.LabelAtlas:_create("0",create_uipath("ui/money_num.png"),10,15,string.byte('.')):addTo(bottom)
        :setPosition(bottom:getContentSize().width/2+300,15)
        :setAnchorPoint(cc.p(1,0.5))    
    self.ticket_label:setString( self:formatNumber(self.ticket,2) )        

    display.newSprite(create_uipath("ui/addgold_bg.png")):addTo(self.uilayer)
    	:setPosition(winSize.width-60,winSize.height/2+210) 
    	:setScale(1.4) 
    	:runAction(cc.RepeatForever:create(cc.RotateBy:create(8.0,360))) 
    local add_gold = utils.button(create_uipath("ui/addgold.png"),create_uipath("ui/addgold.png"),"",handler(self,self.openUI)):addTo(self.uilayer) 
    	:setPosition(winSize.width-60,winSize.height/2+210):setTag(300):setScale(0.8)  
    display.newSprite(create_uipath("ui/gold_word.png")):addTo(add_gold)
            :setPosition(add_gold:getContentSize().width/2,10) 
       	
    self:addBtnBack()
    self.back_state = 0
end

function GameUILayer:backGameFun()
	self.m_btnBack:setTouchEnabled(false)
    if self.back_state == 0 then
    	self.back_state = 1
    	self.m_pull:setVisible(true)
    	for i,v in ipairs(self.btn_items) do
    		v:setVisible(true)
    		v:runAction(cc.Sequence:create(
    				cc.MoveBy:create(0.3,cc.p(0,-80*i)),
    				cc.CallFunc:create(function (  )
    					self.m_btnBack:setTouchEnabled(true)
    				end)
    			))
    	end
    	self.m_btnBack:loadTextures(create_uipath("ui/arrow.png"),create_uipath("ui/arrow.png"))
    else
    	self.back_state = 0
    	self.m_pull:setVisible(false)
    	for i,v in ipairs(self.btn_items) do
    		v:runAction(cc.Sequence:create(
    				cc.MoveBy:create(0.3,cc.p(0,80*i)),
    				cc.CallFunc:create(function ()
    					v:setVisible(false)
    					self.m_btnBack:setTouchEnabled(true)
    				end)
    			))
    	end
    	self.m_btnBack:loadTextures(create_uipath("ui/btn_pulldown.png"),create_uipath("ui/btn_pulldown.png"))
    end	   
end

function GameUILayer:btnCallBack( sender )	
	local tag = sender:getTag()
	if tag == 100 then
		self:helpFun()
	elseif tag == 200 then
		self:setFun()
	elseif tag == 300 then	
        MessageBox.new("确认退出游戏?", function()
                CloseGameClient()
            end):showTo(self)
		--CloseGameClient()
        --self:backGameFun() 
	end	
end

function GameUILayer:addBtnBack()
    self.m_btnBack = utils.button(create_uipath("ui/btn_pulldown.png"),create_uipath("ui/btn_pulldown.png"),nil,handler(self,self.backGameFun))
        :setPosition(60, self:getContentSize().height-60)
        :setPressedActionEnabled(false)
        :addTo(self,10)
    self.m_pull = display.newSprite(create_uipath("ui/pulldown.png")):addTo(self,10)
    	:setPosition(60, self:getContentSize().height-60-128) 
    	:setVisible(false) 
    local btn_img = {"ui/btn_help.png","ui/btn_setting.png","ui/btn_back.png"}
    self.btn_items = {}
    for i=1,3 do
    	local btn = utils.button(create_uipath(btn_img[i]),create_uipath(btn_img[i]),nil,handler(self,self.btnCallBack))
    		:setPosition(60, self:getContentSize().height-60)
    		:addTo(self,10)
    		:setVisible(false)
    		:setTag(i*100)
    	table.insert(self.btn_items,btn)	
    end
end

function GameUILayer:formatNumber( num,tag )
	local result = num
	if num > 10000 then
		result = string.format("%0.2f",num / 10000)
		if self.bottom:getChildByTag(100+tag) == nil then
			display.newSprite(create_uipath("ui/wan_word.png")):addTo(self.bottom)	
				:setPosition(self.bottom:getContentSize().width/2+120+(tag-1)*200,14)
				:setTag(100+tag)	
		else
			self.bottom:getChildByTag(100+tag):setVisible(true)		
		end		
	else
		if self.bottom:getChildByTag(100+tag) then
			self.bottom:getChildByTag(100+tag):setVisible(false)
		end	
	end
	return result	
end

function GameUILayer:getClothImg(cloth)
    local img = ""
    if cloth < 10 then
        img = "00"..cloth
    elseif cloth < 100 then
        img = "0"..cloth
    else
    	img = cloth    
    end  
    return img..".png"  
end

function GameUILayer:updateMoney( money )
	self.money_label:setString(self:formatNumber(money,1))
end

function GameUILayer:updateTickets(num)
    self.ticket = num
    self.ticket_label:setString(self:formatNumber(num,2))
end

function GameUILayer:openUI(sender)
    local tag = sender:getTag()
    if tag == 100 or tag == 300 then
        OpenUICharge()
    elseif tag == 200 then
        OpenUIShop()
    end    
end

function GameUILayer:helpFun()
    GameHelp.new():addTo(self,20)
    self:backGameFun()
end

function GameUILayer:setFun()
    GameSet.new():addTo(self,20)
    self:backGameFun() 
end

function GameUILayer:showDebug( show_data )
    local d = show_data
    d.per = string.format("%0.2f", d.per)
    d.per0 = string.format("%0.2f", d.per0)
    d.per1 = string.format("%0.2f", d.per1)
    d.per2 = string.format("%0.2f", d.per2)
    local text = d.statistics..","..d.curmoney..","..d.per..","..d.per0..","..d.per1..","..d.per2
    if self.debug_label then
        self.debug_label:setString(text)
    else   
        self.debug_label = utils.label(text,24,nil,0,0.5):addTo(self.uilayer)  
            :setPosition(120,winSize.height-30)
    end        
end

return GameUILayer


