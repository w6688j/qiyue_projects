
-- G_client = {}
-- G_client.m_pGameLayer = nil
-- G_client.m_basescore = 0

local GameClient = class("GameClient", function ( ... )
    return display.newLayer()   
end)

---------------------------------------------------------------------------------
------------------------------- 接口 start ---------------------------------------
---------------------------------------------------------------------------------
--- enter exist user list
function GameClient:OnUserList( _userlist , _len)
    log("GameClient:OnUserList _len=".._len)

    for i=1,_len do
        local nViewID = self:SwitchViewChairID(_userlist[i].srvinfo.pos)
        log("OnUserList:",nViewID,_userlist[i].user.id)
        self.m_tableUser[nViewID] = _userlist[i]
    end
end

--- enter user sit behind me
function GameClient:OnUserEnter( userinfo)
    if self.m_tableUser[MY_VIEWID] == nil then
        self:initViewChairID(userinfo.srvinfo.pos)
        log("OnUserEnter:", "MY_VIEWID="..MY_VIEWID, "srvinfo.pos="..userinfo.srvinfo.pos)
    end

    local idx = self:SwitchViewChairID(userinfo.srvinfo.pos)
    if self.m_tableUser[idx] == nil then
        self.m_tableUser[idx] = userinfo
        if self.m_pGameLayer then
            self.m_pGameLayer:initPlayer(idx, userinfo, self.m_basescore)
        end
    end

    log("OnUserEnter:", "viewid="..idx, "srvinfo.pos="..userinfo.srvinfo.pos)
end

function GameClient:OnHandup(lUserID)
    local nViewID = self:getChairID(lUserID)
    --self.m_pPlayer[nViewID]:setUserState(GS_HANDUP)
end

function GameClient:OnOffline(lUserID)
    local nViewID = self:getChairID(lUserID)
    --self.m_pPlayer[nViewID]:setUserState(GS_OFFLINE)
end

function GameClient:OnUserChange( usermoney )
    local userid = usermoney.id
    local nViewID = self:getChairID(userid)
    --self.m_pPlayer[nViewID]:updateUserData(usermoney)
    if self.m_pGameLayer then
        self.m_pGameLayer:updateUserMoney(nViewID,usermoney.money)
    end
end

function GameClient:OnUserStateChange( lUserID,cbState )
    local nViewID = self:getChairID(lUserID)
    --self.m_pPlayer[nViewID]:setUserState(cbState)
end

function GameClient:OnUserStand( lUserID )
    local nViewID = self:getChairID(lUserID)
    log("OnUserStand",nViewID)
    self.m_tableUser[nViewID] = nil
    if self.m_pGameLayer then
        if self.m_pGameLayer.m_pGamePlayerArr[nViewID] then
            self.m_pGameLayer.m_pGamePlayerArr[nViewID]:removePlayer()
            self.m_pGameLayer.m_pGamePlayerArr[nViewID] = nil
        end
    end
    -- self.m_pGameLayer:removeOther(nViewID)
    -- self.m_pPlayer[nViewID]:reset(true)
    -- self.m_pPlayer[nViewID]:setVisible(false)
    -- self.m_cbPlayStatus[nViewID]=false

end

function GameClient:updateMeInfo( userinfo )
    self.m_pGameLayer:updateUserInfo(userinfo)
end

function GameClient:OnReenter( lUserID )
    local nViewID = self:getChairID(lUserID)
  --g_luaClient:OnReenter(_nViewID)
end

function GameClient:OnSwapSite( lUserID,lUserID1 )
    local nViewID = self:getChairID(lUserID)
  --g_luaClient:OnSwapSite(_nViewID,_nViewID1)
end

function GameClient:OnSwapTable( lUserID )
    local nViewID = self:getChairID(lUserID)
  --g_luaClient:OnSwapTable(_nViewID)
end

function GameClient:OnGameData(pData,len)
    -- log("GameClient:OnGameData", nCmdID)
    -- if nCmdID ~= 2102 then
    --     log("GameClient:OnGameData", nCmdID)
    -- end    
    local nCmdID = pData:readInt()

    if nCmdID == GAME_ENTER then    
        self:OnSubGameEnter(pData)
    elseif nCmdID == GAME_SCENE then
        self:OnSubGameScene(pData)
    elseif nCmdID == GAME_FISH then
        self:OnGameFish(pData)
    elseif nCmdID == GAME_USERFIRE then
        self:OnUserFire(pData)
    elseif nCmdID == GAME_MASTER then
        self:OnGameMaster(pData)
    elseif nCmdID == GAME_SHOWKU then
        self:OnSubShowKu(pData)
    elseif nCmdID == GAME_FISHDIE then
        self:OnSubFishDie(pData)
    elseif nCmdID == GAME_FISHSTOP then   

    elseif nCmdID == GAME_FISHAIMOVE then 
        self:OnSubFishAIMove(pData)
    elseif nCmdID == GAME_FISHMAPSTATE then 
        self:OnSubFishMapState(pData)
    elseif nCmdID == GAME_FISHLEAVE then
        self:OnSubFishLeave(pData)
    elseif nCmdID == GAME_ADDSCORE then
        self:OnSubAddScore(pData)
    elseif nCmdID == GAME_BOSSVALCHG then 
        self:OnSubBossValChange(pData)
    elseif nCmdID == GAME_TIPS then    
        self:OnSubGameTips(pData)
    elseif nCmdID == GAME_BOMB then
        self:OnSubGameBomb(pData)
    elseif nCmdID == GAME_LOCK then
        self:OnSubGameLock(pData)
    elseif nCmdID == GAME_ACTIVEENERGY then
    elseif nCmdID == GAME_CARDISAPEAR then
        self:OnSubCardDisapear(pData)  
    elseif nCmdID == GAME_MONEYCHG then
    elseif nCmdID == GAME_MONEYDROP then     
        self:OnSubMoneyDrop(pData)
    else
        log("-------no use cmdID:"..nCmdID)
    end
end
---------------------------------------------------------------------------------
------------------------------- 接口 end -----------------------------------------
---------------------------------------------------------------------------------

--//0 normal;1 100people;2 match
function GameClient:ctor(_srvParam)  
    --设置debug
    --g_luaSceneGame:getPhysicsWorld():setDebugDrawMask(cc.PhysicsWorld.DEBUGDRAW_ALL)

    self.m_master = false
    self.own_tag = false
    self.m_basescore = 0
    self.m_pGameLayer = nil
    self.m_tableUser = {}
    
    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)

	self:onResigterKeyBoardEvent()

    local function loadedCallback()
        self:init()

        if self.m_tableUser[MY_VIEWID] then
            --进入捕鱼界面
            self.m_pGameLayer = GameLayer.new():addTo(self)

            for i=1,GAME_PLAYER do
                local userinfo = self.m_tableUser[i]
                if userinfo then
                    self.m_pGameLayer:initPlayer(i, userinfo)
                end
            end
            self.m_pGameLayer:initGame()
            
            -- 发送客户端进入房间
            local userinfo = self.m_tableUser[MY_VIEWID]
            -- self.m_pGameLayer._money = userinfo.umoney.money
            self.m_pGameLayer = self.m_pGameLayer

            self:sendGameEnter(userinfo.user.id)
            log("当前桌子号:"..(userinfo.srvinfo.table+1)..",座位号:"..userinfo.srvinfo.pos+1)
        end
    end
    
    GameLoading.new(loadedCallback):addTo(self)
    --self:init()
end

function GameClient:getBasescore()
    print("getBasescore======>", self.m_basescore)
end

function GameClient:onEnter()
    -- display.getRunningScene():getPhysicsWorld():setGravity(cc.p(0,0)) --?????????Physics
end

function GameClient:onExit()
    -- self = nil
end

function GameClient:onResigterKeyBoardEvent()
    --self:setKeypadEnabled(true)

    local onKeyReleased = function ( keycode, event )       
        local _name  = cc.KeyCodeKey[keycode+1]
        if _name == "KEY_ESCAPE" then
            MessageBox.new("确认退出游戏?", function()
                log("确认退出游戏?")
                CloseGameClient()
            end):showTo(self)
        end
    end

    local listener = cc.EventListenerKeyboard:create()    
    listener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED )
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
    
end

------------------------


function GameClient:init()   

	--members

    self.m_nMeChairID=INVALID_CHAIR

    -- 桌子状态
    self.m_nGameState=GST_FREE

    --加载鱼路径
    -- for i = 1 , 3 do
    --     --g_point:initData(i-1,handler(self,self.LoadingDat)) 
    --     g_point:initData(i-1,nil)          
    -- end      
    --圆形路径
    self.circle_path = {}
    local rols = {31.5,37,30,35,34,33,32}
    local radius = {365,320,270,220,1}
    local nPosNum = 900
    local _fAddRol= 6.28 / nPosNum
    for k,v in pairs(rols) do
        for r=1,#radius do
            local pos_array = {}
            local _fRol = v
            local _radius = radius[r]
            for i = 1 , nPosNum do
                local temp = {}
                _fRol = _fRol + _fAddRol
                temp.x = 640 + _radius*math.cos(_fRol)
                temp.y = 384 + _radius*math.sin(_fRol)
                table.insert(pos_array,temp)
            end
   
            --table.insert(self.circle_path,{rol = v,radius = _radius,array = pos_array})
            pos_array = utils.reverseTable(pos_array) 
            self.circle_path[v.._radius] = pos_array
        end   
    end

    --plist
    local spriteFrame = cc.SpriteFrameCache:getInstance( )  
    for i=0,27 do
        spriteFrame:addSpriteFrames( create_uipath("plist/fish"..i..".plist") )
    end
    for i=0,17 do
        spriteFrame:addSpriteFrames( create_uipath("plist/die"..i..".plist") )
    end
    spriteFrame:addSpriteFrames( create_uipath("plist/die26.plist") )
    for i=0,7 do
        spriteFrame:addSpriteFrames( create_uipath("plist/net"..i..".plist") )
    end
    spriteFrame:addSpriteFrames( create_uipath("plist/wave.plist") )

    GAMESOUND.initSound()
end

function GameClient:updateBuglePos()
    SetBuglePos(self:getContentSize().width/2,self:getContentSize().height-100)
end

function GameClient:updateBagTickets(num)
    self.m_pGameLayer.g_uiLayer:updateTickets(num)
end

--************************************* Revice Game Data ***********************************************************
function GameClient:OnSubGameScene( _data )
    log("GAME_SCENE")
    -- --桌子状态
    -- self.m_nGameState = _data:readInt()
    -- log("SUB_S_GAME_SCENE",self.m_nGameState)
    -- if self.m_nGameState==GST_FREE then
    --     --self:OnGameFree(_data)
    -- elseif self.m_nGameState==GST_PLAY then
    --     --self:OnGamePlay(_data)
    -- end

    local scene_data = GameData.readGameScene( _data )
    self.mapidx = scene_data.mapidx

    -- self.m_pGameLayer:initGame(self.mapidx)
    self.m_pGameLayer:initBg(self.mapidx)
    
    local scorelen = scene_data.scorelen
    for i=1,scene_data.scorelen do
        local userinfo = self:getUser(scene_data.uids[i])
        if userinfo then
            local nViewID = self:getChairID(userinfo.user.id)
            -- self.m_pGameLayer:updateOther(nViewID,scene_data.score[i],userinfo.user.name) 
            self.m_pGameLayer.m_pGamePlayerArr[nViewID].m_pGameCannon:setMoney(scene_data.score[i])
        end
    end
end

function GameClient:OnSubGameEnter( _data )
    log("GAME_ENTER")
    local game_data = GameData.readGameEnter( _data )
    self.m_basescore = game_data.basescore

end

function GameClient:OnGameFish( _data )
    log("ON_GAME_FISH")
    local fishes = GameData.readAddFish( _data )
    self.m_pGameLayer:addFish(fishes)
end

function GameClient:OnUserFire( _data )
    --log("GAME_USERFIRE")
    local fires = GameData.readUserFire( _data )
    if fires.uid ~= self.m_tableUser[MY_VIEWID].user.id then
        for i=1,GAME_PLAYER do
            if self.m_tableUser[i] and fires.uid == self.m_tableUser[i].user.id then
                -- log("addOtherFire:", "viewid="..i)
                -- self.m_pGameLayer:addOtherFire(i,fires.fRol,fires.idx)
                self.m_pGameLayer.m_pGamePlayerArr[i].m_pGameCannon:fire(fires.fRol, fires.idx)
                break
            end
        end
        
    end    
end

function GameClient:OnSubShowKu( _data )
    local show_data = GameData.readShowKU( _data )
    self.m_pGameLayer.g_uiLayer:showDebug( show_data )
end

function GameClient:OnSubGameTips( _data )
    local p = GameData.readGameTips( _data )
    self.m_pGameLayer:addTips(g_tips[p.tips+1],TIPSTIME)
end

function GameClient:OnSubFishDie( _data )
    local fish_die = GameData.readFishDie( _data )
    for i=1,GAME_PLAYER do
        if self.m_tableUser[i] and fish_die.uid == self.m_tableUser[i].user.id then
            self.m_pGameLayer:killFish(fish_die,i)
            break
        end    
    end  
end

function GameClient:OnSubFishAIMove( _data )
    log("ON_SUB_FISH_AI_MOVE")
    local fish_info = GameData.readFishMove( _data )
    self.m_pGameLayer.fish_layer:fishResumeMove(fish_info.stoppos)
end

function GameClient:OnSubFishLeave(_data)
    log("ON_SUB_FISH_LEAVE")
    local fish_kinds = GameData.readFishLeave(_data)
    self.m_pGameLayer.fish_layer:resumeCircleMove(fish_kinds)
end

function GameClient:OnSubFishMapState( _data )
    log("ON_SUB_FISH_MAP_STATE")
    local map_state = GameData.readFishMapState( _data )
    self.m_pGameLayer:mapMsg(map_state)
end

function GameClient:OnSubGameLock( _data )
    local locks = GameData.readGameLock( _data )
    for i=1,GAME_PLAYER do
        if self.m_tableUser[i] and locks.userid == self.m_tableUser[i].user.id then
            self.m_pGameLayer:revLockFish(i,locks.fishid)
            break
        end    
    end   
end

function GameClient:OnSubGameBomb( _data )
    local pbomb = GameData.readBomb(_data)
    for i=1,GAME_PLAYER do
        if self.m_tableUser[i] and pbomb.uid == self.m_tableUser[i].user.id then
            self.m_pGameLayer:onBomb(i,pbomb)
            break
        end    
    end
    
end

function GameClient:OnSubBossValChange( _data )
    local change = GameData.readBossValChg(_data)
    self.m_pGameLayer:bossChangeVal(change)
end

function GameClient:OnSubMoneyDrop( _data )
    log("SUB_MONEY_DROP")
    local drops = GameData.readMoneyDrop(_data)
    for i=1,GAME_PLAYER do
        if self.m_tableUser[i] and drops.userid == self.m_tableUser[i].user.id then
            self.m_pGameLayer:dropMoney(i,drops.fishid,drops.val)
            break
        end    
    end
end

function GameClient:OnSubCardDisapear( _data )
    local userid = GameData.readCardDisApear(_data) 
    for i=1,GAME_PLAYER do
        if self.m_tableUser[i] and userid == self.m_tableUser[i].user.id then
            -- self.m_pGameLayer:energyDisapear(i)
            self.m_pGameLayer.m_pGamePlayerArr[i]:removeEnergy()
            break
        end    
    end
end

function GameClient:OnGameMaster( _data )
    log("ON_GAME_MASTER")
    self.m_master = true
end

function GameClient:OnSubAddScore( _data )
    -- log("SUB_S_ADD_SCORE")

    local pAddScore = GameData.readAddScore(_data) --GameData.read_CMD_S_AddScore(_data)
    -- dump(pAddScore)
    -- if pAddScore.userid == self.m_tableUser[MY_VIEWID].user.id then
    --     if self.own_tag == false then
    --         --初始化游戏
    --         self.own_tag = true
    --         self.m_pGameLayer.m_userdata = self.m_tableUser[MY_VIEWID]
    --         self.m_pGameLayer:init(pAddScore.score,self.mapidx)

    --         --test
    --         --self.m_pGameLayer:testAll()
    --     else
    --         self.m_pGameLayer:changeScore(pAddScore.score)
    --     end    

    -- else
        for i=1,GAME_PLAYER do
            if self.m_tableUser[i] and pAddScore.userid == self.m_tableUser[i].user.id then
                -- log("OnSubAddScore:", "viewid="..i, pAddScore.score)
                --self.m_pGameLayer:updateOther(i,pAddScore.score,self.m_tableUser[i].user.name)
                self.m_pGameLayer.m_pGamePlayerArr[i].m_pGameCannon:setMoney(pAddScore.score)
                break
            end    
        end 
    -- end
end
--************************************* Revice Game Data End ************************************************

--************************************* Send Data ***********************************************************
function GameClient:sendAddScore( _score )
    local _id = self.m_tableUser[MY_VIEWID].user.id
    local _data = GameData.write_CMD_C_AddScore(GAME_ADDSCORE, _score*self.m_basescore, _id)
    SendGameData(_data, _data:getLen())
end

function GameClient:sendGameEnter(_id)
    local _data = GameData.write_CMD_C_GameEnter(GAME_ENTER, _id)
    SendGameData(_data, _data:getLen())
end

function GameClient:sendUserFire(fRol)
    if self.fire_id then
        self.fire_id = self.fire_id + 1
    else
        self.fire_id = 1
    end
    local fire = {}
    fire.uid = self.m_tableUser[MY_VIEWID].user.id; --uint32_t
    fire.idx = 0--self.fire_id; --int32_t
    fire.fRol = fRol; --float//short
    fire.type = 0; --char
    fire.energy = 0; --char
    local _data = GameData.write_CMD_C_UserFire(GAME_USERFIRE, fire)
    SendGameData(_data, _data:getLen())
end

function GameClient:sendUserCollide(fishid,nViewID,bulletidx)
    local userinfo = self.m_tableUser[nViewID]
    if userinfo then
        local user = userinfo.user
        if nViewID == MY_VIEWID or (self.m_master and isrobot(user)) then
            local o = {}
            o.uid = user.id; --uint32_t
            o.fishid = fishid; --int32_t
            o.idx = bulletidx; --int32_t
            --log("fish"..fishid.." collide, user "..o.uid..", bulletidx "..bulletidx)
            local _data = GameData.write_CMD_C_UserCollide(GAME_USERCOLLIDE, o)
            SendGameData(_data, _data:getLen())
        end
    end
end

function GameClient:sendKindKill(bomb)
    local _data = GameData.write_CMD_C_GameBomb(GAME_BOMB, bomb)
    SendGameData(_data, _data:getLen())
end

function GameClient:sendLockFish(fishid)
    local o = {}
    o.uid = self.m_tableUser[MY_VIEWID].user.id
    o.fishid = fishid
    local _data = GameData.write_CMD_C_GAME_LOCK(GAME_LOCK, o)
    SendGameData(_data, _data:getLen())
end
--************************************* Send Data End *******************************************************

function GameClient:getChairID(userid)
    for i=1,GAME_PLAYER do
        if self.m_tableUser[i] ~= nil and self.m_tableUser[i].user.id == userid then
            return i
        end
    end
    return INVALID_CHAIR
end

function GameClient:getUser( userid )
    for i=1,GAME_PLAYER do
        if self.m_tableUser[i] and self.m_tableUser[i].user.id == userid then
            return self.m_tableUser[i]
        end
    end
    return nil
end

function GameClient:SwitchViewChairID( pos )
    return USER_POS_TABLE[pos+1] + 1
end

function GameClient:initViewChairID( pos )
    -- server pos
    -- 0   1   2
    -- 3   4   5
    -- client pos -- pos<3则翻转game_layer
    -- 0   1   2
    -- 3   4   5

    if pos == 0 then
        USER_POS_TABLE = {5,4,3,2,1,0}
        G_bViewTurn = true
        MY_VIEWID = 5
    elseif pos == 1 then
        USER_POS_TABLE = {5,4,3,2,1,0}
        G_bViewTurn = true
        MY_VIEWID = 4
    elseif pos == 2 then
        USER_POS_TABLE = {5,4,3,2,1,0}
        G_bViewTurn = true
        MY_VIEWID = 3
    elseif pos == 3 then
        USER_POS_TABLE = {0,1,2,3,4,5}
        G_bViewTurn = false
        MY_VIEWID = 3
    elseif pos == 4 then
        USER_POS_TABLE = {0,1,2,3,4,5}
        G_bViewTurn = false
        MY_VIEWID = 4
    elseif pos == 5 then
        USER_POS_TABLE = {0,1,2,3,4,5}
        G_bViewTurn = false
        MY_VIEWID = 5
    end
    MY_VIEWID = MY_VIEWID + 1
end


return GameClient


