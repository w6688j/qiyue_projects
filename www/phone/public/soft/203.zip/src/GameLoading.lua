
local GAME_RES_NAMES = {"backimg/backimg0.png", "backimg/backimg1.png", "backimg/backimg2.png","backimg/cockles.png"
            ,"plist/wave.png", "Player/cir.png", "Player/cir1.png", "Player/GOLD2.png", "ui/curson.png"}

-- spriteframe fish 
for i=0,27 do
    table.insert(GAME_RES_NAMES,"plist/fish"..i..".png")
end
-- spriteframe fish die
for i=0,17 do
    table.insert(GAME_RES_NAMES,"plist/die"..i..".png")
end
    table.insert(GAME_RES_NAMES,"plist/die26.png")
-- spriteframe bullet and fishing net
for i=0,7 do
    table.insert(GAME_RES_NAMES,"plist/net"..i..".png")
    table.insert(GAME_RES_NAMES,"Player/bullet"..i..".png")
end

local GAME_RES_COUNT = table.getn(GAME_RES_NAMES)

local GameLoading = class("GameLoading", function ( ... )
    return display.newLayer()   
end)

function GameLoading:ctor(loadedCallback)

    self.loadedCallback = loadedCallback

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
end

function GameLoading:onEnter()
    self:init()
end

function GameLoading:init()   
	-- loading background
    display.newSprite(create_uipath("loading/loading_bg.png")):setPosition(display.center):addTo(self)

    -- loading_bar bg
    local loading_bar_bg = display.newSprite(create_uipath("loading/loading_bar_bg.png")):setPosition(display.cx, 100):addTo(self)

    -- loading_bar
    self.m_loaded = 0
    self.loading_bar = ccui.LoadingBar:create(create_uipath("loading/loading_bar.png"))
    self.loading_bar:setPosition(loading_bar_bg:getPosition()):setPercent(0):addTo(self)

    local function loadedImage(texture)
    	self.m_loaded = self.m_loaded + 1
    	local percent = self.m_loaded/GAME_RES_COUNT*100
    	self.loading_bar:setPercent(percent)
    	-- log("load progress:", percent, self.m_loaded, GAME_RES_COUNT)

    	if percent >= 100 then
            local function scheduleOnce()
                self.loadedCallback()
                
                self:removeFromParent()
            end
            performWithDelay(self,scheduleOnce,1.0)
    	end
    end

    for i=1,GAME_RES_COUNT do
    	local filename = create_uipath(GAME_RES_NAMES[i])
    	display.loadImage(filename, loadedImage)
    end

end

G_loading = {}
function G_loading.removeImage()
    for i=1,GAME_RES_COUNT do
        local filename = create_uipath(GAME_RES_NAMES[i])
        display.removeImage(filename, loadedImage)
    end
end


return GameLoading


