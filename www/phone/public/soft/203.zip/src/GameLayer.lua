
-- local TAG_CANNON_START = 100


local GameLayer= class("GameLayer", function ( ... )
    return display.newLayer()   
end)
local scheduler=cc.Director:getInstance():getScheduler()

function GameLayer:init()
    -- self.position = nil
    -- self.init_position = 0
    self.m_bStopFire = false
    -- self.m_fishes = {}

    -- self.circle_kind = {}
    -- self.circle_fishes = {}
    -- self.circle_fishes_data = {}
    -- self.circle_update = {}
    -- self:initCircleFish()

    -- self.update_fishes = false
    -- self.temp_circle_id = {}
    -- self.dif_time = 0

    -- self.line_count = 0

    -- self.times = 1
    self.test_count = 0

    -- for auto fire
    self.m_bAutoOpen = false
    -- for lock fire
    self.m_bLastAuto = false
    self.m_bLockOpen = false
    self.mark_fish = nil
    -- self.m_bNoMark = false

    self.bgmove_time = 0
    self.time_tip = false
    self.long_touch = false 
    -- self.no_money = false
    -- self.pause = false
end

function GameLayer:ctor()
    self:init()

    -- self._money = 0
    -- self.m_userdata = nil

    -- self.times = 1

    self.m_pGamePlayerArr = {}

    -- game layer
    self.fish_layer = FishLayer.new():addTo(self)
    -- self.fish_layer = cc.Layer:create():addTo(self)

    -- player layer
    self.player_layer = cc.Layer:create():addTo(self)
end

-- function GameLayer:initData()
    -- self.m_tagPos = POS.new();                  --坐标
    -- self.m_fRol = 0;                            --角度
    -- self.m_tagDir = POS.new();                  --方向//上下
    -- self.m_tagDir1 = POS.new();             --方向//左右
    -- self.m_fishes = {}
    -- self.position = nil
    -- self.init_position = 0

    -- self.circle_kind = {}
    -- self.circle_fishes = {}
    -- self.circle_fishes_data = {}
    -- self.circle_update = {}

    -- self.line_count = 0

    -- self.floor_glods = {}

    -- self.other_cannons = {}

    -- self.temp_circle_id = {}

    -- self.time_tip = false
    -- self.long_touch = false 
    -- self.update_fishes = false
    -- -- self.no_money = false
    -- self.dif_time = 0
    -- self.pause = false
-- end

function GameLayer:initGame()
    -- self:initData()

    -- local bgimg = GameData.MYRES["BACKIMG"..mapidx][GameData.MYRES_PATH]
    -- local bg = display.newSprite(create_uipath(bgimg)):addTo(self.fish_layer)
    --     :setPosition(display.cx,display.cy) 
    -- self.now_bg = bg

    self:initTouch()

    -- GAMESOUND.playBGM(mapidx+1)
    -- self:bgWave(0)

    if G_bViewTurn then -- 座位需要转换
        self.fish_layer:setRotation(180)
        --self.back_layer:setRotation(180)
    end


    self.fire_time = os.time()
    
    -- self.cost_score = base_score

    -- self.m_bullets = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.m_bulletvec
    --主定时器
    self.state_update = scheduler:scheduleScriptFunc(handler(self,self.updateScheduler),1/50, false) 
    -- self:scheduleUpdate(handler(self, self.updateScheduler))

    -- self.update_timer = 0   
    --物理引擎碰撞  
    -- self:initContact() --?????????Physics
    --事件侦听
    self:eventListener()
    self:enterEvent()
    --ui
    self:initUI() 


    self.test_label = utils.label(#self.fish_layer:getChildren(),30):addTo(self)
        --:setPosition(120,600)   
        :move(120,600)
end

function GameLayer:initBg(mapidx)
    self.fish_layer:resetFish()

    local bgimg = GameData.MYRES["BACKIMG"..mapidx][GameData.MYRES_PATH]
    local bg = display.newSprite(create_uipath(bgimg)):addTo(self.fish_layer,-1)
        :setPosition(display.cx,display.cy) 
    self.now_bg = bg

    GAMESOUND.playBGM(mapidx+1)
    self:bgWave(0)
end

-- function GameLayer:initCircleFish()
--     self.circle_fishes[0] = {}
--     self.circle_fishes[2] = {}
--     self.circle_fishes[3] = {}
--     self.circle_fishes[5] = {}
--     self.circle_fishes[17] = {}
--     self.circle_fishes_data[0] = {}
--     self.circle_fishes_data[2] = {}
--     self.circle_fishes_data[3] = {}
--     self.circle_fishes_data[5] = {}
--     self.circle_fishes_data[17] = {}

--     for i=1,5 do
--         self.circle_update[i] = 0 
--     end 
-- end

-- function GameLayer:init( base_score , mapidx)
--     -- self:initData()
--     self:initTouch()

--     -- self.fish_layer = cc.Layer:create():addTo(self)
--     -- local bgimg = GameData.MYRES["BACKIMG"..mapidx][GameData.MYRES_PATH]
--     -- local bg = display.newSprite(create_uipath(bgimg)):addTo(self.fish_layer)
--     --     :setPosition(display.cx,display.cy) 
--     GAMESOUND.playBGM(mapidx+1)     
--     self:bgWave(0)
      
    
--     self.m_fRol, self.m_tagPos, self.m_tagDir, self.m_tagDir1 = self:getLocation(MY_VIEWID)
--     if G_bViewTurn then -- 座位需要转换
--         self.fish_layer:setRotation(180)
--         --self.back_layer:setRotation(180)
--     end
--     -- if self.my_viewID < 3 then
--     --     self.m_fRol = 0
--     --     --self.G_bViewTurn = true
--     --     self.m_tagPos:set(self.my_viewID * (display.width / 3) + display.width / 6, display.height - 76-14)
--     --     self.m_tagDir:set(0,-1)
--     --     self.m_tagDir1:set(1,0)

--     --     --self.fish_layer:setRotation(180)
--     --     -- bg:setRotation(180)
        
--     -- else
--     --     self.m_fRol = 3.14
--     --     self.m_tagPos:set((self.my_viewID%3) * (display.width / 3) + display.width / 6, 76-14)
--     --     self.m_tagDir:set(0,1)
--     --     self.m_tagDir1:set(-1,0)
--     -- end 

--     --设置炮塔
--     -- self.m_pGameCannon = GameCannon.new( self.m_tagPos,self.m_fRol,self.m_tagDir,self.m_tagDir1,base_score,MY_VIEWID ):addTo(self.player_layer) 
--     --     --:setRotation(180) 
--     -- self.m_pGameCannon:setTag(TAG_CANNON_START+MY_VIEWID)     
--     -- self.m_pGameCannon:setmoney(base_score)
--     self.fire_time = socket:gettime()
    
--     self.cost_score = base_score

--     self.m_bullets = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.m_bulletvec   
--     --主定时器
--     self.state_update = scheduler:scheduleScriptFunc(handler(self,self.updateState),0.1,false) 
--     self.update_timer = 0   
--     --物理引擎碰撞  
--     self:initContact()
--     --事件侦听
--     self:eventListener()
--     self:enterEvent()
--     --ui
--     self:initUI() 

--     --test
--     --self:test()
--     --内存信息
--     -- self.debug = DebugLayer.new():addTo(self,100):setPosition(0, display.cy)
--     -- self.debug:updateInfo()  

--     self.test_count = 0
--     self.test_label = utils.label(#self.fish_layer:getChildren(),30):addTo(self)
--         --:setPosition(120,600)   
--         :move(120,600)

--     --local color = utils.HEXCOLOR(0xffffff)
--     --log("===>", color.r, color.g, color.b)         

--     -- local effect = cc.CSLoader:createNode(create_uipath("animate/ly_10001.csb"))
--     --     :addTo(self,200)
--     --     :setPosition(self:getContentSize().width/2,self:getContentSize().height/2)
--     -- local act = cc.CSLoader:createTimeline(create_uipath("ly_10001.csb"))
--     -- act:gotoFrameAndPlay(0,false)
--     -- effect:runAction(act) 
--     -- utils.setTimeout(4.0,function ( ... )
--     --     effect:removeFromParent()
--     -- end)     
-- end

function GameLayer:initPlayer(viewid,userinfo,base_score)
    self.m_pGamePlayerArr[viewid] = GamePlayer.new(viewid,userinfo):addTo(self.player_layer)
    if base_score ~= nil then
        self.m_pGamePlayerArr[viewid].m_pGameCannon:setMoney(base_score)
    end
end

function GameLayer:test( ... )
    local test_time = 0
    --每帧调用
    self:scheduleUpdateWithPriorityLua(function(dt)
        test_time = test_time + dt
        log(test_time)
    end,1)
end

function GameLayer:shakeScreen( )
    local delay = 0.05 -- 时间
    local arr = cc.Sequence:create(
        cc.MoveTo:create(delay,cc.p( 0, 12 )),
        cc.MoveTo:create(delay,cc.p( 12, 0 )),
        cc.MoveTo:create(delay,cc.p( 0, 8 )),
        cc.MoveTo:create(delay,cc.p( 8, 0 )),
        cc.MoveTo:create(delay,cc.p( 0, 6 )),
        cc.MoveTo:create(delay,cc.p( 6, 0 )),
        cc.MoveTo:create(delay,cc.p( 0, 4 )),
        cc.MoveTo:create(delay,cc.p( 4, 0 )),
        cc.MoveTo:create(delay,cc.p( 0, 2 )),
        cc.MoveTo:create(delay,cc.p( 2, 0 )),
        cc.MoveTo:create(delay,cc.p( 0, 1 )),
        cc.MoveTo:create(delay,cc.p( 1, 0 ))
    )

    self:runAction(arr)
end

function GameLayer:bgWave(tag)
    self.wave_bg = cc.Layer:create():addTo(self.fish_layer,tag)
    local x1=512 / 2
    local y1=0
    for i=1,3 do
        x1 = 512 / 2
        for j=1,5 do
            self:addWave(x1,y1)
            x1=x1+300  
        end
        y1=y1+300
    end
end

function GameLayer:addWave(x,y)
    local spriteFrame = cc.SpriteFrameCache:getInstance( )  
  
    local wave_sp = cc.Sprite:createWithSpriteFrameName("wave1.png")    
  
    local animation = cc.Animation:create()  
    for i=1, 32 do  
        local blinkFrame = spriteFrame:getSpriteFrame( "wave"..i..".png" )  
        animation:addSpriteFrame( blinkFrame )  
    end  
    animation:setDelayPerUnit( 0.08 )  
    local animate = cc.Animate:create(animation)  

    wave_sp:runAction(cc.RepeatForever:create(animate))
    wave_sp:setPosition(x,y)
    wave_sp:setOpacity(255/2)
    wave_sp:addTo(self.wave_bg)
end

-- function GameLayer:getLocation(_viewID)
--     local m_fRol = 0
--     local m_tagPos = POS.new()
--     local m_tagDir = POS.new()
--     local m_tagDir1 = POS.new()

--     local index = (_viewID-1)%3;
--     if GamePlayer.isTopUser(_viewID) then
--         m_fRol = 0
--         m_tagPos:set(index * (display.width/ 3) + display.width / 6, display.height - (76+14) + 31)
--         m_tagDir:set(0,-1)
--         m_tagDir1:set(1,0)
--     else
--         m_fRol = 3.14
--         m_tagPos:set(index * (display.width / 3) + display.width / 6, 76+14)
--         m_tagDir:set(0,1)
--         m_tagDir1:set(-1,0)
--     end
--     log("_viewID ", _viewID, ", m_tagPos", m_tagPos.x, m_tagPos.y)
--     return m_fRol,m_tagPos,m_tagDir,m_tagDir1
-- end

function GameLayer:updateUserInfo( info )
    -- self.m_userdata = info
    --更新锁定
    if info.user.vip > 0 and info.user.valitime - os.time() > 0 then --锁定开启
        if self.lock_tag then
            utils.cleanChildAndEffect(self.lock_tag)
        end    
    end 
    self.m_pGamePlayerArr[MY_VIEWID]:setUserInfo(info)
    self:updateMeMoney(infos.umoney.money)
    -- self.m_pGamePlayerArr[MY_VIEWID]:updateMoney(infos.umoney.money)
    -- self._money = infos.umoney.money
    -- self.g_uiLayer:updateMoney(infos.umoney.money) 
    -- if self._money - self.cost_score > 0 then
    --     self.no_money = false
    -- end  
end
function GameLayer:updateMeMoney(nMoney)
    self.m_pGamePlayerArr[MY_VIEWID]:updateMoney(nMoney)
    self.g_uiLayer:updateMoney(nMoney) 
end

-- function GameLayer:updateOther(viewid,base_score,username)
    -- log("update other",viewid, base_score, username)
    -- local cannon_target = self.m_pGamePlayerArr[viewid].m_pGameCannon
    -- if table.getn(self.other_cannons) > 0 then
    --     for i,v in pairs(self.other_cannons) do
    --         if v:getTag() == TAG_CANNON_START+_viewID then
    --             cannon_target = v
    --             break
    --         end
    --     end
    -- end
    -- if cannon_target == nil then
    --     log("add cannon")
    --     local m_fRol,m_tagPos,m_tagDir,m_tagDir1 = self:getLocation(viewid)
    --     local m_cannon = GameCannon.new( m_tagPos,m_fRol,m_tagDir,m_tagDir1,base_score,_viewID,username ):addTo(self.player_layer)
    --     m_cannon:setTag(TAG_CANNON_START+viewid)
    --     m_cannon:setmoney(base_score)

    --     table.insert(self.other_cannons,m_cannon)
    -- else
    --     log("update cannon")
    --     cannon_target.base_label:setString(base_score)
    --     cannon_target:setmoney(base_score)
    -- end    
    
-- end

-- function GameLayer:addOtherFire(viewid,fRol,idx)
--     --log("addOtherFire:", _viewID)
--     -- local t_cannon = self.player_layer:getChildByTag(TAG_CANNON_START+_viewID)
--     local m_cannon = self.m_pGamePlayerArr[viewid].m_pGameCannon
--     local r = math.deg(fRol)
--     if GamePlayer.isTopUser(viewid) then
--         m_cannon.cur_cannon:setRotation(r+180)
--     else
--         m_cannon.cur_cannon:setRotation(r) 
--     end
    
--     m_cannon.rotate = r
--     m_cannon:addbullet(idx)
-- end

-- function GameLayer:removeOther(viewid)
--     self.m_pGamePlayerArr[viewid]:removePlayer()
--     self.m_pGamePlayerArr[viewid] = nil
    -- local m_cannon = self.player_layer:getChildByTag(TAG_CANNON_START+_viewID)
    -- local m_cannon = self.m_pGamePlayerArr[viewid].m_pGameCannon
    -- if m_cannon then
    --     utils.removeValue(self.other_cannons,t_cannon)
    --     if m_cannon.card_sp then
    --         m_cannon.card_sp:removeFromParent()
    --     end
    --     m_cannon:clearCannon()
    -- end    
-- end

function GameLayer:initUI()     
    cc.FileUtils:getInstance():addSearchPath(getReadWritePath()..create_uipath("ui"))

    local _player = self.m_pGamePlayerArr[MY_VIEWID]

    self.g_uiLayer = GameUILayer.new(_player.m_info.user,0):addTo(self,20) 

    self.auto_btn = utils.button(create_uipath("ui/auto_icon.png"),create_uipath("ui/auto_icon.png"),"",handler(self,self.onClickAutoFire)):addTo(self.g_uiLayer) 
        :setPosition(winSize.width-60,winSize.height/2+30):setScale(0.8) 

    local effect = utils.getAnimationPlist(create_uipath("ui/skill_box.plist"), "UIkuang", 20, 0.1)
        :addTo(self.auto_btn)
        :setPosition(self.auto_btn:getContentSize().width/2,self.auto_btn:getContentSize().height/2)
    effect:setVisible(false)
    self.auto_effect = effect   
    -- self.m_bAutoOpen = 1  
    -- local effect = cc.CSLoader:createNode(create_uipath("ui/UIkuang.csb"))
    --     :addTo(self.auto_btn)
    --     :setPosition(self.auto_btn:getContentSize().width/2,self.auto_btn:getContentSize().height/2)
    -- local act = cc.CSLoader:createTimeline(create_uipath("ui/UIkuang.csb"))
    -- act:gotoFrameAndPlay(0,true)
    -- effect:runAction(act) 
    -- effect:setVisible(false)
    -- self.auto_effect = effect
    display.newSprite(create_uipath("ui/auto_word.png")):addTo(self.auto_btn)
        :setPosition(self.auto_btn:getContentSize().width/2,0)  
    self.lock_btn = utils.button(create_uipath("ui/lock_icon.png"),create_uipath("ui/lock_icon.png"),"",handler(self,self.onClickLockFire)):addTo(self.g_uiLayer) 
        :setPosition(winSize.width-60,winSize.height/2-95):setScale(0.8) 

    local effect = utils.getAnimationPlist(create_uipath("ui/skill_box.plist"), "UIkuang", 20, 0.1)
        :addTo(self.lock_btn)
        :setPosition(self.lock_btn:getContentSize().width/2,self.lock_btn:getContentSize().height/2)
    effect:setVisible(false)
    self.lock_effect = effect    
    -- local effect = cc.CSLoader:createNode(create_uipath("ui/UIkuang.csb"))
    --     :addTo(self.lock_btn)
    --     :setPosition(self.lock_btn:getContentSize().width/2,self.lock_btn:getContentSize().height/2)
    -- local act = cc.CSLoader:createTimeline(create_uipath("ui/UIkuang.csb"))
    -- act:gotoFrameAndPlay(0,true)
    -- effect:runAction(act) 
    -- effect:setVisible(false)
    -- self.lock_effect = effect    
    display.newSprite(create_uipath("ui/lock_word.png")):addTo(self.lock_btn)
        :setPosition(self.lock_btn:getContentSize().width/2,0)    
    -- self.lock_open = 1    
  
    if _player.m_info.user.vip > 0 and _player.m_info.user.valitime - os.time() > 0 then --锁定开启
    else
        self.lock_tag = display.newSprite(create_uipath("ui/lock.png")):addTo(self.lock_btn)
            :setPosition(80,80)    
    end        
end

function GameLayer:onClickLockFire()   
    -- local PM = PM.new():addTo(self.fish_layer,10):setPosition(display.cx-180,display.cy-220)
    -- PM:moreGold()  
    -- if 1 then
    --     return
    -- end
    local _player = self.m_pGamePlayerArr[MY_VIEWID]
    if _player.m_info.user.vip > 0 and _player.m_info.user.valitime - os.time() > 0 then --vip功能
    else    
        BuyPopup.new():addTo(self,20)
        return
    end    
    if self.m_bLockOpen == false then
        self.m_bLockOpen = true   
        self.lock_effect:setVisible(true)

        self.m_bLastAuto = self.m_bAutoOpen
        self.m_bAutoOpen = true
        self.auto_effect:setVisible(true)

        -- if self.m_bAutoOpen == true then
        --     self.m_bLastAuto = true
        -- else
        --     self.al_auto = false
        --     self.m_bAutoOpen = true
        --     self.auto_effect:setVisible(true)
        -- end    
        
        self:selectFish()
    else
        self.m_bLockOpen = false
        self.lock_effect:setVisible(false)
        -- self.mark_fish = nil
        -- self.nolock_fish = false
        self.m_bAutoOpen = self.m_bLastAuto
        if self.m_bAutoOpen == false then
            self.auto_effect:setVisible(false)
            self.auto_xy = nil
        end    
        
        if self.mark_fish then
            self:removeMarkFish()
            -- self.mark_fish:subMark(MY_VIEWID)
            -- -- self.mark_fish.bMark = false
            -- self.mark_fish._target:getChildByTag(999):removeFromParent()
            -- self.mark_fish = nil
            --utils.cleanChildAndEffect(self.m_card) 
            -- self.m_card:clear()
            -- self.m_card = nil
            Layer_LuaClient:sendLockFish(-1)
        end   
    end 
end
function GameLayer:onClickAutoFire()      
    -- if self.no_money == true then
    --     return
    -- end
    if self.m_bAutoOpen == false then
        self.m_bAutoOpen = true   
        self.auto_effect:setVisible(true)
    else
        self.m_bAutoOpen = false
        self.auto_effect:setVisible(false)
        self.auto_xy = nil
    end    
end

function GameLayer:killFish( fish_die,viewid )
    for i,v in ipairs(self.fish_layer.m_tagAllFishes) do 
        if v._id == fish_die.fishid then
            local card = fish_die.card
            if card ~= 0 then --能量炮
                local eneryPos = cc.p(v._target:getPositionX(),v._target:getPositionY())
                if G_bViewTurn then
                    eneryPos.x = display.width - eneryPos.x
                    eneryPos.y = display.height - eneryPos.y
                end
                self:changeEnergyCannon(viewid,eneryPos)
            end    
            v:struggle(fish_die.score , fish_die.val , viewid)
            break
        end   
    end
end

function GameLayer:changeEnergyCannon( viewid,eneryPos)
    -- local m_cannon = self.player_layer:getChildByTag(TAG_CANNON_START + viewid)
    -- m_cannon:changeEnergy(eneryPos)
    local m_player = self.m_pGamePlayerArr[viewid]
    m_player:createCard(eneryPos)
    -- m_player.m_pGameCannon:setCannon(Cannon.CANNON_3)
    m_player.m_pGameCannon:setCannon(3)
end

-- function GameLayer:energyDisapear(viewid)
--     -- local m_cannon = self.player_layer:getChildByTag(TAG_CANNON_START + viewid)
--     local m_cannon = self.m_pGamePlayerArr[viewid].m_pGameCannon
--     m_cannon:removeEnergy()
-- end

function GameLayer:addFish(fishes)

    -- 背景移动时，不需要addfish
    if self.m_bStopFire == true then
        return
    end

    -- for CIRCLE_MOVE test
    -- if fishes[1].lMoveType == LINE_MOVE then
    --     local len = #fishes
    --     for i=1,len do
    --         local f = fishes[i]
    --         f.lMoveType = CIRCLE_MOVE
    --         f.start_pos.x = 640
    --         f.start_pos.y = 384
    --         f.num = 1
    --         if i == len then
    --             f.fishkind = 17
    --             f.end_pos.x = 1
    --         elseif i % 4 == 0 then
    --             f.fishkind = 0
    --             f.end_pos.x = 365
    --         elseif i % 4 == 1 then
    --             f.fishkind = 3
    --             f.end_pos.x = 320
    --         elseif i % 4 == 2 then
    --             f.fishkind = 5
    --             f.end_pos.x = 270
    --         elseif i % 4 == 3 then
    --             f.fishkind = 5
    --             f.end_pos.x = 220
    --         end
    --     end
    -- end

    for k,f in ipairs(fishes) do
        if f.lMoveType == LINE_MOVE then
            self.fish_layer:AddLineFish(f)
        elseif f.lMoveType == CIRCLE_MOVE then
            self.fish_layer:AddCircleFish(f)
        else
            self.fish_layer:AddCurveFish(f)
        end

        if f.fishkind == FISH_LI1 then
            self:addTipFish(FISH_LI1,3)
        end     
        -- if self.mark_fish == nil then
        --     if self:haslockedFish(fish) then
        --         -- self.nolock_fish = false
        --     end   
        -- end
    end
end

--[[function GameLayer:addFish( fishes )
    -- if self.map_change then
    --     return
    -- end        
    -- if self.times > 1 then
    --     return
    -- end
    -- self.times = self.times + 1
    -- if self.init_position == LINE_MOVE then--map move
    --     return
    -- end    
    
    log("_addFish:", fishes[1].fishkind, fishes[1].lMoveType, fishes[1].num, #fishes)
    for k,f in ipairs(fishes) do
        -- dump(f)
        -- log("======>addfish ", f.lMoveType, f.start_pos.x, f.start_pos.y)
        -- 按座位转换x,y的值
        -- if G_bViewTurn and f.lMoveType == LINE_MOVE then
        --     f.start_pos.x = display.width-f.start_pos.x
        --     f.start_pos.y = display.height-f.start_pos.y
        --     f.end_pos.x = display.width-f.start_pos.x
        --     f.end_pos.y = display.height-f.start_pos.y
        -- end

        local _path = nil
        if f.lMoveType ~= LINE_MOVE or f.lMoveType ~= CIRCLE_MOVE then
            --_path = g_point:getkeypath(f.pathtype,f.pathidx) 
            _path = g_point:getPathFromLua(f.pathtype,f.pathidx)
            --_path = g_point:getPathFromLua(0,0)
            if _path == nil then
                log("_path error",f.pathtype,f.pathidx)
            end
        end    

        -- if f.lMoveType == LINE_MOVE then
        --     log("addFish:LINE_MOVE", f.fishkind, f.num)
        -- elseif f.lMoveType == CIRCLE_MOVE then
        --     log("addFish:CIRCLE_MOVE", f.fishkind, f.num)
        -- end
   
        for i=1,f.num do
            if self:isExist(f.idpos[i],f) == false then     
                local fish = nil          
                if f.lMoveType == LINE_MOVE then
                    local f0 = GameFish.new(f.fishkind, f.idpos[i], f.lPropType,f.num, f.lMoveType ,_path):addTo(self.fish_layer) 
                    if f.fishkind > 14 then
                        self.line_count = self.line_count + 1
                    end    
                    f0:LineFishMove(f.start_pos,f.end_pos,f.stoppos,self.line_count,self.update_fishes)
                    self.position = GameData.Line_Position

                    table.insert(self.m_fishes , f0) 
                    fish = f0
                elseif f.lMoveType == CIRCLE_MOVE then 
                    if f.fishkind > 10 then
                        local f0 = GameFish.new(f.fishkind, f.idpos[i], f.lPropType,f.num, f.lMoveType ,_path):addTo(self.fish_layer) 
                        f0:CreateCircle(f.start_pos,self.circle_angle,f.end_pos.x,900)
                        f0:setVisible(false)
                        self.spec_fish_sp = f0
                        table.insert(self.m_fishes , f0) 
                        table.insert(self.circle_fishes[self.spec_fish_sp._kind], self.spec_fish_sp)
                    else
                        if not utils.contain_value(self.temp_circle_id, f.idpos[i].id  ) then
                            -- log("circle_fishes_data=======>", f.fishkind, i)
                            table.insert(self.circle_fishes_data[f.fishkind], {f,i}) 
                            table.insert(self.temp_circle_id,f.idpos[i].id)  
                        end     
                    end    
                    --local f0 = GameFish.new(f.fishkind, f.idpos[i], f.lPropType,f.num, f.lMoveType ,_path,self.my_viewID):addTo(self.fish_layer) 
                    --f0:CreateCircle(f.start_pos,self.circle_angle,f.end_pos.x,900)
                    --f0:setVisible(false)

                    -- if not utils.contain_value(self.circle_kind,f.fishkind) then
                    --     table.insert(self.circle_kind,f.fishkind) 
                    --     self.circle_fishes[f.fishkind] = {}
                    -- end 

                    --table.insert(self.circle_fishes[f.fishkind] , f0)
                else
                    local f0 = GameFish.new(f.fishkind, f.idpos[i], f.lPropType,f.num, f.lMoveType ,_path,f.val):addTo(self.fish_layer) 
                    table.insert(self.m_fishes , f0)     
                    if self.pause then
                        f0.fish_state = GameData.Fish_Stop
                    end    
                    fish = f0
                end  
                --table.insert(self.m_fishes , f0)  
                if fish then
                    if fish._kind == FISH_LI1 then
                        self:addTipFish(FISH_LI1,3)
                    end     
                    if self.nolock_fish then
                        if self:haslockedFish(fish) then
                            self.nolock_fish = false
                        end   
                    end     
                end 
            end
        end
        _path = nil
    end

    --if #self.circle_kind > 0 then
    if self.circle_fishes[0] and #self.circle_fishes[0] > 0 then
        self.position = GameData.Circle_Position 
        --self.circle_update[#self.circle_kind] = 0    
    end  

    if self.circle_fishes_data[0] and #self.circle_fishes_data[0] > 0 then
        self.position = GameData.Circle_Position   
    end   
end--]]

-- function GameLayer:AddFishMsg(f)
    
-- end

-- function GameLayer:isExist(idpos,fish)
--     local is_exist = false
--     for i,f in ipairs(self.m_fishes) do
--         if f._id == idpos.id then
--             f.cur_point = idpos.curpos
--             f:updatePos(idpos)
--             is_exist = true
--             break
--         end        
--     end
--     return is_exist
-- end

-- function GameLayer:changeScore(score)
--     if score == self.cost_score then
--         --判断鱼阵
--         if self.position then
--             log("update")
--             self.update_fishes = true
--             -- self.circle_fishes_data = {}
--             -- self.circle_fishes_data[0] = {}
--             -- self.circle_fishes_data[2] = {}
--             -- self.circle_fishes_data[3] = {}
--             -- self.circle_fishes_data[5] = {}
--             -- self.circle_fishes_data[17] = {}
--             if self.position == GameData.Line_Position then
--                 for i=#self.m_fishes,1,-1 do
--                     if self.m_fishes[i]._kind > 10 then
--                         self.m_fishes[i]:clearFish()
--                         table.remove(self.m_fishes,i)
--                     end    
--                 end
--                 self.line_count = 0 
--             end              
--         end    
--         return
--     end    
--     -- self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.base_label:setString(score)
--     self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon:setMoney(score)
--     -- self.cost_score = score
--     -- if self._money - self.cost_score > 0 then
--     --     self.no_money = false
--     -- end
--     GAMESOUND.playEffect(Add_Gold_Sound)
-- end

-- function GameLayer:fishResumeMove(stoppos)
--     self.fish_layer:resumeLineMove(stoppos)
    -- for i,v in ipairs(self.m_fishes) do
    --     v:resumeLineMove() 
    -- end
    -- self.line_count = 0
    -- self.position = nil
    -- self.update_fishes = false
-- end

function GameLayer:addTipFish(_kind,delay)
    local img = ""
    if _kind == FISH_LI1 then
        img = "ui/showli1.png"
    end    
    display.newSprite(create_uipath(img)):addTo(self,10)
        :setPosition(display.cx,display.cy)
        :runAction(cc.Sequence:create(cc.DelayTime:create(delay),
                    cc.RemoveSelf:create()
                ))     
end

function GameLayer:mapMsg( map_data )    
    local state = map_data.state
    local mapidx = map_data.idx
    if state == Map_Comon then
        -- for i,v in ipairs(self.m_fishes) do
        --     if v:resumeCircleMove() then
        --         break
        --     end    
        --     --v:resumeMove()
        -- end
        -- self.fish_layer:resumeFish()
    elseif state == Map_Buffer then
        --停止射击
        self.m_bStopFire = true
        self:addTips( TIPS_READYSTYLE,TIPSTIME / 1000 )
    elseif state == Map_Move then
        self.m_bStopFire = true
        self:removeMarkFish()
        -- if self.mark_fish then
        --     self.mark_fish = nil
        --     --utils.cleanChildAndEffect(self.m_card) 
        --     self.m_card:clear()
        --     self.m_card = nil
        --     -- self.nolock_fish = true
        -- end 
        self:changeBG(mapidx)
    elseif state == Map_Waite then

    elseif state == Map_FishList then
        self.fish_layer.m_fCircleRol = map_data.circle
        local circle = map_data.circle
        -- local angle = circle * 180 / math.pi
        -- self.circle_angle = math.floor(angle + 0.5)
        -- self.fish_layer.m_fCircleAngle = math.floor(angle + 0.5)
        log("map circle: ", circle, math.deg(circle))
        --开始射击
        self.m_bStopFire = false

        -- self.circle_fishes[0] = {}
        -- self.circle_fishes[2] = {}
        -- self.circle_fishes[3] = {}
        -- self.circle_fishes[5] = {}
        -- self.circle_fishes[17] = {}
        -- self.circle_fishes_data[0] = {}
        -- self.circle_fishes_data[2] = {}
        -- self.circle_fishes_data[3] = {}
        -- self.circle_fishes_data[5] = {}
        -- self.circle_fishes_data[17] = {}
        -- for i=1,5 do
        --     self.circle_update[i] = 0 
        -- end  
    end    
end

function GameLayer:updateUserMoney(nViewID,usermoney)
    if nViewID == MY_VIEWID then
        self:updateMeMoney(usermoney)
        -- self._money = usermoney
        -- self.g_uiLayer:updateMoney(usermoney)
        -- if self._money - self.cost_score > 0 then
        --     self.no_money = false
        -- end
    end    
end

function GameLayer:addTips( tag,delay )
    local tip = g_tips[tag]
    --if tag == TIPS_READYSTYLE then        
    if tag == TIPS_NOBULLET then
        local count = delay
        local str = string.gsub(tip, "==", count) 
        local m_tip,tiplabel = utils.showTip(str)
        m_tip:addTo(self,10)
        m_tip:setPosition(display.cx,display.cy)
        
        self.m_tip = m_tip
        local function changeTime()
            count = count - 1
            if count == 0 then --关闭游戏
                scheduler:unscheduleScriptEntry(self.tip_update)
                CloseGameClient()
            end    
            local str = string.gsub(tip, "==", count) 
            tiplabel:setString(str)
        end    
        self.tip_update = scheduler:scheduleScriptFunc(changeTime,1,false) 
    else
        utils.showTip(tip):addTo(self,10)
            :setPosition(display.cx,display.cy)
            :runAction(cc.Sequence:create(cc.DelayTime:create(delay),
                    cc.RemoveSelf:create()
                ))              
    end    
       
end
--鱼潮
function GameLayer:changeBG(mapidx)   
    local res = GameData.MYRES["COCKLES"] 
    local bgimg = GameData.MYRES["BACKIMG"..mapidx][GameData.MYRES_PATH]
    local next_bg = display.newSprite(create_uipath(bgimg)):addTo(self.fish_layer)
    --next_bg:setPosition(winSize.width+next_bg:getContentSize().width/2,next_bg:getContentSize().height/2) 
    
    --self:bgWave(1)  
    self.wave_bg:setLocalZOrder(1) 
    local cockles = utils.getAnimSprite(create_uipath("backimg/cockles.png"),res):addTo(self.fish_layer)
    cockles:setPosition(winSize.width+cockles:getContentSize().width/2-30,winSize.height/2)  
    local c_x = 0 - 5
    if G_bViewTurn then
        --next_bg:setRotation(180)
        --next_bg:setPosition(-next_bg:getContentSize().width/2,next_bg:getContentSize().height/2) 

        next_bg:setRotation(180)
        next_bg:setAnchorPoint(cc.p(1,0.5))
        next_bg:setPosition(0,winSize.height/2) 
        cockles:setRotation(180)
        cockles:setPosition(-cockles:getContentSize().width/2+30,winSize.height/2) 
        c_x = winSize.width + 5
    else
        next_bg:setAnchorPoint(cc.p(1,0.5))  
        next_bg:setPosition(winSize.width,winSize.height/2)   
    end    
    GAMESOUND.playEffect(Wave_Enter_Sound)
    cockles:runAction(cc.Sequence:create(cc.MoveTo:create(3.0,cc.p(c_x,winSize.height/2)),  
        cc.CallFunc:create(function ()
            self.fish_layer:removeAllFish()
            -- for i=#self.m_fishes,1,-1 do
            --     self.m_fishes[i]:clearFish()
            --     table.remove(self.m_fishes,i)
            -- end
            self.wave_bg:setLocalZOrder(0) 
            self.now_bg:removeFromParent()
            self.now_bg = next_bg
            self.next_bg = nil
            GAMESOUND.stopBGM()
            GAMESOUND.playBGM(mapidx+1) 
        end),
        cc.RemoveSelf:create() ))
    --next_bg:runAction(cc.MoveTo:create(3.0,cc.p(winSize.width/2,winSize.height/2)))

    next_bg:setTextureRect(cc.rect(winSize.width,0,0,winSize.height))
    self.next_bg = next_bg
    self.bgmove_time = 0

    log("===========>", next_bg)
end

function GameLayer:QQFly(sp,viewid,act_end)
    if self.m_pGamePlayerArr[viewid] then
        self.m_pGamePlayerArr[viewid]:PropFly(sp,act_end)
    end
    -- local x = sp:getPositionX()
    -- local y = sp:getPositionY()
    -- local move_y = self.m_tagPos.y-100    
    -- if GamePlayer.isTopUser(viewid) then
    --     move_y = self.m_tagPos.y+100   
    -- end    
    -- local _speed = 400
    -- local dis = math.sqrt( math.pow((x-self.m_tagPos.x),2) + math.pow((y-move_y),2) )    
    -- sp:runAction(cc.Sequence:create(
    --         cc.MoveTo:create(dis/_speed,cc.p(self.m_tagPos.x,move_y)),
    --         cc.RemoveSelf:create(),
    --         cc.CallFunc:create(function ()
    --             act_end()      
    --         end)    
    --     ))
end

function GameLayer:catchFish(event)   
    --log("catch over")
    local fish = event._usedata[1]
    local score = event._usedata[2]
    local get_money = event._usedata[3]
    local viewid = event._usedata[4] 
    
    local fishPos = cc.p(fish._target:getPositionX(),fish._target:getPositionY())
    local f_kind = fish._kind
    local f_prop = fish._prop
    local spec_fish = 0
    --特殊处理
    if f_prop == Kind_Kill_Prop then--一网打尽
        self:kindKill(f_kind,fishPos.x,fishPos.y,score)
    elseif f_prop == Star_Prop then
        self:someKill(fish,f_kind)    
    end

    if f_kind == STOPFISHID then
        spec_fish = 1
        local PM = PM.new():addTo(self.fish_layer,10):setPosition(display.cx,display.cy)
        PM:stopTime()
        self:PauseAllFish()    
    elseif f_kind == AREABOMBID then
        spec_fish = 1   
        self:areaKill(fishPos.x,fishPos.y,score)
    elseif f_kind == FISH_ZONGYITANG then
        spec_fish = 1   
        self:kindKill(f_kind,fishPos.x,fishPos.y,score)
    elseif f_kind == FULLWINDOWBOMBID then  
        spec_fish = 1
        self:allKill(f_kind,fishPos.x,fishPos.y,score)
    elseif f_kind == FIHS_QQ then
        self.get_ticket = 100 * fish.val    
    end

    GAMESOUND.playDieSound(f_kind)

    if utils.contain_value(fishshake,f_kind) then
        self:shakeScreen()
    end    
    
    -- fish:clearFish()
    -- utils.removeValue(self.m_fishes,fish)
    if self.mark_fish then
    log("=====>", self.mark_fish._kind, fish._id, self.mark_fish._id) end
    if fish == self.mark_fish then
        self:changeMark()
    end
    self.fish_layer:removeFish(fish)

    if spec_fish == 1 then
        return
    end    

    if get_money == 0 then
        log("error===========",f_kind)
        return
    end   
    -- local add_money = cc.LabelAtlas:_create("0",create_uipath("Player/FLYSCORE.png"),14,20,string.byte('0')):addTo(self.player_layer)
    -- add_money:setPosition(fishPos)
    -- add_money:setString(get_money):setScale(2.0)
    -- local add_y = 100
    -- if GamePlayer.isTopUser(viewid) then
    --     add_money:setRotation(180)
    --     add_y = -100
    -- end
    -- local act = cc.Sequence:create( cc.MoveTo:create(1,cc.p(fishPos.x,fishPos.y+add_y)),cc.RemoveSelf:create() )
    -- add_money:runAction(act)

    -- local _cannon = self.player_layer:getChildByTag(TAG_CANNON_START+viewid)
    local _player = self.m_pGamePlayerArr[viewid]
    if _player == nil then
        log("user leave")
        return
    end
    local m_tagPos = _player.m_pGameCannon.m_tagPos

    _player:AddGameGold(fishPos,get_money,f_kind,f_prop)
    if viewid == MY_VIEWID then
        self.g_uiLayer:updateMoney(_player:getMoney())
    end
    -- self:addGameGold(viewid,f_kind,f_prop,get_money,m_tagPos,fishPos)
    --大鱼效果
    if f_kind >= WHITE_SHARK then
        local pos_y = m_tagPos.y+150 
        local angle = 0 
        if GamePlayer.isTopUser(viewid) then
            pos_y = m_tagPos.y-150
            angle = 180
        end
        local cir_name = "cir"
        if f_kind >= BIG_SHARK then
            cir_name = "cir1"
        end    
        local res = GameData.MYRES[cir_name]
        local cir_sp = utils.getAnimSprite(create_uipath("Player/"..cir_name..".png"),res):addTo(self.player_layer)
            :setPosition(m_tagPos.x,pos_y)
            :setScale(0.75)
            :setRotation(angle)
        local cir_label = cc.LabelAtlas:_create("0",create_uipath("Player/cirmoney.png"),27,35,string.byte('0')):addTo(cir_sp)
            :setAnchorPoint(cc.p(0.5,0.5))
            :setPosition(cir_sp:getContentSize().width/2,cir_sp:getContentSize().height/2)
            :setScale(4/3)
        cir_label:setString(get_money)
        --cir_label:setRotation(angle)
        local act = cc.Sequence:create(cc.RotateBy:create(0.2,30),cc.RotateBy:create(0.2,-30),cc.RotateBy:create(0.2,-30),cc.RotateBy:create(0.2,30))
        cir_label:runAction(cc.Repeat:create(act,5))    
        cir_sp:runAction(cc.Sequence:create(cc.DelayTime:create(4),cc.RemoveSelf:create()))

        -- if G_bViewTurn then
        --     fishPos.x = display.width - fishPos.x
        --     fishPos.y = display.height - fishPos.y
        -- end
        -- if G_bViewTurn then
        --     fishPos.x = fishPos.x - 180
        --     fishPos.y = fishPos.y - 220  
        -- end    
        local PM = PM.new():addTo(self.fish_layer,10):setPosition(fishPos)
        PM:moreGold()
    end    
          
    -- if viewid == MY_VIEWID then
    --     self._money = self._money + get_money
    --     self.g_uiLayer:updateMoney(self._money)
    --     if self._money - self.cost_score > 0 then
    --         self.no_money = false
    --     end 
    -- end    
end

-- function GameLayer:addGameGold(viewid,kind,prop,get_money,m_tagPos,goldPos)

--     if G_bViewTurn then
--         goldPos.x = display.width - goldPos.x
--         goldPos.y = display.height - goldPos.y
--     end

--     -- show fly score number
--     local add_money = cc.LabelAtlas:_create(get_money,create_uipath("Player/FLYSCORE.png"),14,20,string.byte('0'))
--     add_money:setPosition(goldPos):setScale(2.0):addTo(self.player_layer)
--     local move_y = 100
--     if GamePlayer.isTopUser(viewid) then
--         add_money:setRotation(180)
--         move_y = -100
--     end
--     local act = cc.Sequence:create( cc.MoveBy:create(1,cc.p(0,move_y)),cc.RemoveSelf:create() )
--     add_money:runAction(act)

--     -- show fly gold
--     local gold_num = 1
--     local gold_width = 78
--     if prop > 0 then
--         gold_num = 5
--     else
--         if kind < 3 then
--         elseif kind < 10 then
--             gold_num = 2
--         elseif kind < 14 then
--             gold_num = 4
--         elseif kind < 18 then
--             gold_num = 6
--         else
--             gold_num = 8
--         end            
--     end 
--     local g_speed = 400

--     for i=1,gold_num do 
--         local _tagPos_x = goldPos.x + (gold_num/2-i)*gold_width
--         local res = GameData.MYRES["GOLD2"]
--         local gold_sp = utils.getAnimSprite(create_uipath("Player/GOLD2.png"),res)
--         gold_sp:setPosition(_tagPos_x,goldPos.y):addTo(self.player_layer)
--         -- local end_y = m_tagPos.y-100    
--         -- if GamePlayer.isTopUser(viewid) then
--         --     end_y = m_tagPos.y+100   
--         -- end
--         local end_y = m_tagPos.y
--         local dis = math.sqrt( math.pow((_tagPos_x-m_tagPos.x),2) + math.pow((goldPos.y-end_y),2) )    
--         gold_sp:runAction(cc.Sequence:create(
--                 cc.MoveTo:create(dis/g_speed,cc.p(m_tagPos.x,end_y)),
--                 cc.RemoveSelf:create(),
--                 cc.CallFunc:create(function ()
--                     if i == gold_num then
--                         self:showFloorGold(m_tagPos,get_money,kind,viewid) 
--                     end      
--                 end)    
--             ))
--     end 
-- end

-- function GameLayer:showFloorGold(m_tagPos,get_money,f_kind,viewid)
--     local index = #self.floor_glods
--     self.m_floorgold = GameFloorGold.new( f_kind ):addTo(self.player_layer) 
--     table.insert(self.floor_glods,self.m_floorgold)
--     self.m_floorgold:initData( get_money,m_tagPos,self.m_fRol,index,viewid )
--     GAMESOUND.playEffect(Gold_Show_Sound)
--     if viewid == MY_VIEWID then
--         self.m_floorgold:setPosition(40,0)
--     end    
-- end

function GameLayer:dropMoney(viewid,fishid,get_money)
    for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
        if v._id == fishid then
            local fishPos = cc.p(v._target:getPositionX(),v._target:getPositionY())
            local _player = self.m_pGamePlayerArr[viewid]
            _player:AddGameGold(fishPos,get_money,0,0)
            if viewid == MY_VIEWID then
                self.g_uiLayer:updateMoney(_player:getMoney())
            end
            break
        end    
    end
    -- local add_money = cc.LabelAtlas:_create("0",create_uipath("Player/FLYSCORE.png"),14,20,string.byte('0')):addTo(self.fish_layer,10)
    -- add_money:setPosition(f_x,f_y)
    -- add_money:setString(get_money):setScale(2.0)
    -- local add_y = 100
    -- if GamePlayer.isTopUser(viewid) then
    --     add_money:setRotation(180)
    --     add_y = -100
    -- end
    -- local act = cc.Sequence:create( cc.MoveTo:create(1,cc.p(f_x,f_y+add_y)),cc.RemoveSelf:create() )
    -- add_money:runAction(act)

    -- local _cannon = self.player_layer:getChildByTag(TAG_CANNON_START+viewid)
    -- local m_cannon = self.m_pGamePlayerArr[viewid].m_pGameCannon
    -- local m_tagPos = m_cannon.m_tagPos
    
    -- self:addGameGold(viewid,0,0,get_money,m_tagPos,fishPos)

    -- if viewid == MY_VIEWID then
    --     self._money = self._money + get_money
    --     self.g_uiLayer:updateMoney(self._money)
    --     if self._money - self.cost_score > 0 then
    --         self.no_money = false
    --     end
    -- end)
end

-- function GameLayer:overCircle()
--     self:runAction(cc.Sequence:create(
--             cc.CallFunc:create(function ()
--                 self:circleLeave(0)
--             end),
--             cc.DelayTime:create(1.5),
--             cc.CallFunc:create(function ()
--                 self:circleLeave(2)
--             end),
--             cc.DelayTime:create(1.5),
--             cc.CallFunc:create(function ()
--                 self:circleLeave(3)
--             end),
--             cc.DelayTime:create(1.5),
--             cc.CallFunc:create(function ()
--                 self:circleLeave(5)
--             end),
--             cc.DelayTime:create(1.5),
--             cc.CallFunc:create(function ()
--                 self:circleLeave(17)
--             end),
--             cc.CallFunc:create(function ()
--                 self.circle_kind = {}
--                 self.circle_fishes = {}
--                 self.circle_fishes_data = {}
--                 self.circle_update = {}
--                 self.position = nil
--                 self.update_timer = 0
--             end)
--         ))  
--     self.update_fishes = false       
-- end

-- function GameLayer:circleLeave( i )
--     local kind = i --self.circle_kind[i]
--     local fishes = self.circle_fishes[kind] 
--     for k,v in pairs(fishes) do
--         if v._target then
--             v._move_type = 0
--             local start_x,start_y = v._target:getPosition()
--             local distance = 1000
--             local end_x = start_x + distance*math.cos(math.rad(-v._fAddRol))
--             local end_y = start_y + distance*math.sin(math.rad(-v._fAddRol))
    
--             local dis = math.sqrt( math.pow((start_x-end_x),2) + math.pow((start_y-end_y),2) )
--             local speed = 160
--             local t = dis / speed
--             local move_act = cc.MoveTo:create(t,cc.p(end_x,end_y))
--             v._target:runAction( move_act )
--         end    
--     end
-- end

function GameLayer:eventListener()
    local eventDispatcher = self:getEventDispatcher()

    local function deleteFish(event) 
        local fish = event._usedata
        if self.mark_fish then
        log("===>", self.mark_fish._kind, fish._id, self.mark_fish._id) end
        if fish == self.mark_fish then
            self:changeMark()
        end    
        
        self.fish_layer:removeFish(fish)
        -- fish:clearFish()
        -- utils.removeValue(self.m_fishes,fish)
        -- fish = nil
    end
    local function overCircle()
        self.fish_layer:overCircleMove()
    end
    local function fishMark()
        -- self:changeMark()
    end
    local function removeFloorGold(event)
        local _gold = event._usedata
        self.m_pGamePlayerArr[_gold.nViewID]:removeFloorGold(_gold)
        -- utils.removeValue(self.floor_glods,_gold)
        -- for k,v in pairs(self.floor_glods) do
        --     v.move_state = 1
        -- end
    end
    local function changeCannon( event )
        if self.m_bAutoOpen == false and self.mark_fish == false then
            Layer_LuaClient:sendAddScore(event._usedata)
        else
            log("自动锁定状态不能升降炮")
        end
    end 
    local listener1 = cc.EventListenerCustom:create(GameData.DELETE_FISH, deleteFish)
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener1, self)
    local listener2 = cc.EventListenerCustom:create(GameData.CATCH_FISH, handler(self,self.catchFish))
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener2, self)
    local listener3 = cc.EventListenerCustom:create(GameData.OEVER_CIRCLE, overCircle)
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener3, self)
    -- local listener4 = cc.EventListenerCustom:create("change_mark", fishMark)
    -- eventDispatcher:addEventListenerWithSceneGraphPriority(listener4, self)
    local listener5 = cc.EventListenerCustom:create(GameData.REMOVE_FLOOR_GLOD, removeFloorGold)
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener5, self)
    local listener6 = cc.EventListenerCustom:create(GameData.CHANGE_CANNON,changeCannon)
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener6, self)
    --

    self:registerScriptHandler(handler(self,self.onNodeEvent))
end

function GameLayer:someKill( fish,_kind )
    local remove_fish = {}
    for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
        if v._kind == _kind and v._prop == Star_Prop and v ~= fish then
            v:clearFish()
            table.insert(remove_fish, v)
        end    
    end
    for i=1,#remove_fish do
        utils.removeValue(self.fish_layer.m_tagAllFishes,remove_fish[i])
    end
end

function GameLayer:initBomb( score,posx,posy )
    local _player = self.m_pGamePlayerArr[MY_VIEWID]
    local bomb = {}
    bomb.score = score
    bomb.uid = _player.m_info.user.id 
    bomb.particle = 1
    bomb.freez = 1
    bomb.x = posx
    bomb.y = posy
    return bomb
end

function GameLayer:areaKill( posx,posy,score )
    local angle = 400
    local bomb = self:initBomb(score,posx,posy)
    local fish = {}
    for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
        if v:isInside() and GameData.GetValByFish(v._kind) < 13 and v.fish_state <= GameData.Fish_Stop then
            if v._target:getPositionX() > posx - angle and v._target:getPositionX() < posx + angle 
                and v._target:getPositionY() > posy - angle and v._target:getPositionY() < posy + angle then
                local m_cannon = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon
                table.insert(fish,{id = v._id,val = GameData.GetValByFish(v._kind)*m_cannon:getMoney()})
            end    
        end    
    end
    self:sendClientKill(bomb,fish)
end

function GameLayer:kindKill( _kind,posx,posy,score )
    log("send kind kill")
    local bomb = self:initBomb(score,posx,posy)
    local fish = {}
    if _kind == FISH_ZONGYITANG then
        for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
            if v:isInside() and GameData.GetValByFish(v._kind) < 13 and v.fish_state <= GameData.Fish_Stop then
                local m_cannon = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon
                table.insert(fish,{id = v._id,val = GameData.GetValByFish(v._kind)*m_cannon:getMoney()})
            end    
        end
    else
        for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
            if v:isInside() and v._kind == _kind and v.fish_state <= GameData.Fish_Stop then
                local m_cannon = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon
                table.insert(fish,{id = v._id,val = GameData.GetValByFish(v._kind)*m_cannon:getMoney()})
            end    
        end    
    end    
    self:sendClientKill(bomb,fish)
end

function GameLayer:allKill(_kind,posx,posy,score)
    local bomb = self:initBomb(score,posx,posy)
    local fish = {}
    for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
        if v:isInside() and v.fish_state <= GameData.Fish_Stop then
                local m_cannon = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon
            table.insert(fish,{id = v._id,val = GameData.GetValByFish(v._kind)*m_cannon:getMoney()})
        end    
    end
    self:sendClientKill(bomb,fish)
end

function GameLayer:sendClientKill( bomb,fish )
    bomb.len = #fish
    bomb.idval = fish
    
    Layer_LuaClient:sendKindKill( bomb )
end

function GameLayer:onBomb( viewid,_bomb )

    local bombPos = cc.p(_bomb.pos.x, display.height-_bomb.pos.y)

    local PM = PM.new():addTo(self.fish_layer,10):setPosition(bombPos)
    PM:moreGold()
    local idval = _bomb.idval
    local add_money = 0
    for k,v in pairs(idval) do
        add_money = add_money + v.val
        --self:killFish(v.id)
        for i,f in ipairs(self.fish_layer.m_tagAllFishes) do
            if f._id == v.id then
                f:struggle(v.val , v.val , viewid)
                break
            end   
        end
    end
    GAMESOUND.playEffect(Bom_Sound)
    log("bomb add_money",add_money)
end

function GameLayer:revLockFish(viewid,fishid)
    --log("revLockFish",viewid,fishid)
    local _player = self.m_pGamePlayerArr[viewid]
    if viewid == MY_VIEWID and _player == nil then
        return
    end    
    -- local m_cannon = self.player_layer:getChildByTag(TAG_CANNON_START+viewid)
    -- local m_cannon = _player.m_pGameCannon
    if fishid < 0 then-- -1
        -- m_cannon._other_lock = nil
        -- m_cannon._lock_fish = nil
        _player.m_pGameCannon:setLockFishid(nil)

        -- local t_cannon = self.player_layer:getChildByTag(TAG_CANNON_START+viewid)
        local m_bullets = _player.m_pGameCannon.m_bulletvec
        for i,v in ipairs(m_bullets) do
            v:setMark(false)
        end

        -- remove fish mark
        for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
            if v._id == fishid then 
                v:subMark(viewid)
                -- v.bMark = true 
                break 
            end 
        end   
    else    
        -- m_cannon._other_lock = viewid
        -- m_cannon._lock_fish = fishid
        _player.m_pGameCannon:setLockFishid(fishid)

        -- add fish mark
        for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
            if v._id == fishid then 
                v:addMark(viewid)
                -- v.bMark = true 
                break 
            end 
        end       
    end   
end

function GameLayer:lockFish() 
    local fishid = self.mark_fish._id
    Layer_LuaClient:sendLockFish(fishid)
end

function GameLayer:bossChangeVal( change )
    local id = change.id
    local val = change.val
    for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
        if v._id == id then
            v:bossVal(val)
            break
        end
    end
end

function GameLayer:updateScheduler(dt)
    self.test_count = self.test_count + 1

    if self.test_count % 300 == 0 then
        collectgarbage("collect")
    elseif self.test_count % 5 == 0 then
        self.test_label:setString(#self.fish_layer:getChildren()) 
    end   

    -- fish layer update
    self.fish_layer:updateScheduler()

    -- player update
    for i=1,GAME_PLAYER do
        if self.m_pGamePlayerArr[i] then
            self.m_pGamePlayerArr[i]:updateScheduler()
        end
    end


    local _player = self.m_pGamePlayerArr[MY_VIEWID]
    local m_bullets = _player.m_pGameCannon.m_bulletvec

    -- add tips no bullet
    if (os.time() - self.fire_time) > 60 and self.time_tip == false then
        self.time_tip = true
        self:addTips( TIPS_NOBULLET,60 )
    end 

    -- lock fish auto fire
    if self.mark_fish and self.mark_fish._target and _player:checkNoMoney() == false then
        if #m_bullets < MAX_BULLET and self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon:isFire() and self.m_bStopFire == false then
            local fire_x = self.mark_fish._target:getPositionX()
            local fire_y = self.mark_fish._target:getPositionY()
            if G_bViewTurn then
                fire_x = winSize.width-self.mark_fish._target:getPositionX() 
                fire_y = winSize.height-self.mark_fish._target:getPositionY()
            end    
            if self:userFire(fire_x,fire_y) then
                Layer_LuaClient:sendUserFire(self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.rotate / 180 * math.pi)
            end
        end    
    end 

    -- open auto fire and long touch auto fire
    if (self.m_bAutoOpen == true or self.long_touch == true) and _player:checkNoMoney() == false then
        if #m_bullets < MAX_BULLET and self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon:isFire() and self.m_bStopFire == false then   
            local fire_x = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.m_tagPos.x + 1000*math.sin(math.rad(self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.rotate))
            local fire_y = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.m_tagPos.y + 1000*math.cos(math.rad(self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.rotate))
            if self.auto_xy then
                fire_x = self.auto_xy.x
                fire_y = self.auto_xy.y 
            end 
            if self.long_touch == true then
                fire_x = self.touch_x
                fire_y = self.touch_y
            end  
            if self:userFire(fire_x,fire_y) then
                Layer_LuaClient:sendUserFire(self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.rotate / 180 * math.pi)
            end    
        end 
    end  

    -- auto lock fish
    if self.m_bLockOpen and self.mark_fish == nil and self.m_bStopFire == false then
        self:selectFish()
    end 

    -- show next background
    if self.next_bg then
        self.bgmove_time = self.bgmove_time + dt
        local w = self.bgmove_time * (display.width / 3)
        self.next_bg:setTextureRect(cc.rect(display.width-w,0,w,display.height))
    end  
end

--[[function GameLayer:updateState()
    --log(collectgarbage("count"))

    self.test_count = self.test_count + 1  
    if self.test_count % 300 == 0 then
        collectgarbage("collect")
    elseif self.test_count % 5 == 0 then
        --self.test_label:setString(string.format("%.2fk" , collectgarbage("count") ))   
        self.test_label:setString(#self.fish_layer:getChildren()) 
    end    

    --collectgarbage("setpause",100)  
    --collectgarbage("setstepmul",5000)  
    
    local _player = self.m_pGamePlayerArr[MY_VIEWID]
    local m_bullets = _player.m_pGameCannon.m_bulletvec 

    -- for k,v in pairs(self.other_cannons) do
    --     local m_bs = v.m_bulletvec 
    --     for i,t in pairs(m_bs) do
    --         if t then
    --             t:judgeborder()
    --         end   
    --     end
    -- end

    -- for i,v in ipairs(self.m_bullets) do
    --     if v then
    --         v:judgeborder()
    --     end    
    -- end


    for i,v in ipairs(self.m_fishes)  do
        --if v then
        if v then
            v:updateScheduler()
        end
    end
    
    if self.position == GameData.Line_Position then

    elseif self.position == GameData.Circle_Position then
        -- self.update_timer = self.update_timer + 1
        -- if self.update_timer % 15 == 0 and self.spec_fish_sp then 
        --     --self:fishChange(5,17) 
        --     --self:fishCreate(5,17,25)
        --     self.spec_fish_sp.fish_state = GameData.Fish_Move
        --     -- if #self.circle_fishes[self.spec_fish_sp._kind] == 0 then
        --     --     table.insert(self.circle_fishes[self.spec_fish_sp._kind] , self.spec_fish_sp)
        --     -- end    
        -- end    
        -- if (self.update_timer+1) % 10 == 0 then 
        --     --self:fishChange(4,5)
        --     self:fishCreate(4,5,10)
        -- end    
        -- if self.update_timer % 8 == 0 then
        --     --self:fishChange(3,3)
        --     self:fishCreate(3,3,8)
        -- end    
        -- if self.update_timer % 7 == 0 then
        --     --self:fishChange(2,2)
        --     self:fishCreate(2,2,7)
        -- end    
        -- if self.update_timer % 6 == 0 then  
        --     --self:fishChange(1,0)
        --     self:fishCreate(1,0,6)
        -- end           
    end   

    if (socket.gettime() - self.fire_time)*1000 > 60000 and self.time_tip == false then
        self.time_tip = true
        self:addTips( TIPS_NOBULLET,60 )
    end 

    if self.mark_fish and self.mark_fish._target and _player:checkNoMoney() == false then
        if #m_bullets < MAX_BULLET and self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon:isFire() and self.init_position == 0 then
            local fire_x = self.mark_fish._target:getPositionX()
            local fire_y = self.mark_fish._target:getPositionY()
            if G_bViewTurn then
                fire_x = winSize.width-self.mark_fish._target:getPositionX() 
                fire_y = winSize.height-self.mark_fish._target:getPositionY()
            end    
            if self:userFire(fire_x,fire_y) then
                Layer_LuaClient:sendUserFire(self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.rotate / 180 * math.pi)
            end
        end    
    end 

    if (self.auto_open == 0 or self.long_touch == true) and _player:checkNoMoney() == false then
        if #m_bullets < MAX_BULLET and self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon:isFire() and self.init_position == 0 then   
            local fire_x = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.m_tagPos.x + 1000*math.sin(math.rad(self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.rotate))
            local fire_y = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.m_tagPos.y + 1000*math.cos(math.rad(self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.rotate))
            if self.auto_xy then
                fire_x = self.auto_xy.x
                fire_y = self.auto_xy.y 
            end 
            if self.long_touch == true then
                fire_x = self.touch_x
                fire_y = self.touch_y
            end  
            if self:userFire(fire_x,fire_y) then
                Layer_LuaClient:sendUserFire(self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.rotate / 180 * math.pi)
            end    
        end 
    end  

    if self.nolock_fish and self.init_position == 0 then
        self:selectFish()
    end 

    if self.next_bg then
        self.bgmove_time = self.bgmove_time + 0.1
        local w = self.bgmove_time * (winSize.width / 3)
        self.next_bg:setTextureRect(cc.rect(winSize.width-w,0,w,winSize.height))
    end    
end--]]

-- function GameLayer:fishCreate( i, fish_kind , interval )
--     if #self.circle_fishes_data[fish_kind] < 1 then
--         return
--     end    
    
--     local fish_index = self.circle_update[i] + 1
--     local fishes = self.circle_fishes_data[fish_kind]      
--     if fish_index <= #fishes then
--         local v = fishes[fish_index][1]
--         local index = fishes[fish_index][2]
--         local f0 = GameFish.new(v.fishkind, v.idpos[index], v.lPropType,v.num, v.lMoveType ,nil):addTo(self.fish_layer) 
--         if (self.update_timer / interval)*0.1 > self.dif_time then
--             f0:CreateCircle(v.start_pos,self.circle_angle,v.end_pos.x,900,self.update_fishes)
--         else
--             f0:CreateCircle(v.start_pos,self.circle_angle,v.end_pos.x,900,self.update_fishes,self.dif_time)
--         end    
        
--         f0:setVisible(false)
--         f0.fish_state = GameData.Fish_Move
--         table.insert(self.circle_fishes[v.fishkind] , f0)
--         table.insert(self.m_fishes,f0)
--     end
--     self.circle_update[i] = self.circle_update[i] + 1    
-- end

-- function GameLayer:fishChange(i,fish_kind)
--     --if self.circle_update[i] == nil then
--     if #self.circle_fishes[fish_kind] < 1 then    
--         return
--     end    
--     --local fish_kind = self.circle_kind[i]
--     local fish_index = self.circle_update[i] + 1
--     local fishes = self.circle_fishes[fish_kind]           
--     if fish_index <= #fishes then
--         table.insert(self.m_fishes,fishes[fish_index])
--         fishes[fish_index].fish_state = GameData.Fish_Move
--     end
--     self.circle_update[i] = self.circle_update[i] + 1
-- end

function GameLayer:initContact()
    local wall = cc.Node:create()
    --local wall_box = cc.PhysicsBody:createEdgeBox(cc.size(1000,600), cc.PhysicsMaterial(0.1, 1, 0.0))
    local wall_box = cc.PhysicsBody:createEdgeBox(winSize, cc.PhysicsMaterial(0.1, 0.5, 0.5))--(0.1, 1, 0.0))
    wall:setPhysicsBody(wall_box)
    wall_box:setCategoryBitmask(1)
    wall_box:setContactTestBitmask(1) 
    wall_box:setCollisionBitmask(3)   
    wall:setPosition(display.cx,display.cy)
    wall:setTag(GameData.WALL_TAG)
    self:addChild(wall)
    self.wall = wall

    local function onContactBegin(contact)
        local node1 = contact:getShapeA():getBody():getNode()
        local node2 = contact:getShapeB():getBody():getNode()
        --log(node1:getTag(),node2:getTag())
        if not node1 or not node2 then return end  
        if (node1:getTag() == GameData.WALL_TAG and node2:getTag() == GameData.BULLET_TAG) or 
                (node2:getTag() == GameData.WALL_TAG and node1:getTag() == GameData.BULLET_TAG) then      
            local bullet = nil  
            if node1:getTag() == GameData.BULLET_TAG then  
                bullet = node1 
            else
                bullet = node2 
            end  
            self:changeBulletDirection(bullet)
            return    
        end        
        if node1:getTag() ~= node2:getTag() and (node1:getTag() ~= GameData.WALL_TAG and node2:getTag() ~= GameData.WALL_TAG) then 
            local fish = nil  
            local bullet = nil  
            if node1:getTag() == GameData.BULLET_TAG then  
                bullet = node1 
                fish = node2 
            else
                bullet = node2 
                fish = node1
            end
            if fish:getParent():isVisible() == false then
                return 
            end

            -- 判断子弹是否已锁定鱼
            if self:getMark(bullet) == true then
                self:shootMark(fish,bullet)
                return true
            end

            -- if self.lock_open == 0 and self.mark_fish and self:getMark(bullet) == 1 then
            --     --只射被锁定的鱼
            --     self:shootMark(fish,bullet)
            -- else
            --先判断鱼是否死亡
            if fish:getParent():isDie() then

            else
                --向服务器发送碰撞
                if bullet and bullet:getParent() then
                    self:collide(fish, bullet:getParent().nViewID, bullet:getParent().m_idx)
                else
                    log("bullet parent is not exist", bullet:getTag())
                end
                --播放撒网动作  
                self:FallingNet(bullet) 
            end
            -- end     
        end
        
        return true
    end
    local contactListener = cc.EventListenerPhysicsContact:create()    
    contactListener:registerScriptHandler(onContactBegin, cc.Handler.EVENT_PHYSICS_CONTACT_BEGIN);
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(contactListener, self);
end

function GameLayer:getMark( _bullet )
    if _bullet:getParent() then
        return _bullet:getParent():getMark()
    end
    return false
    -- local m_mark = _bullet:getParent():getMark()
    -- local m_mark = false
    -- for i=1,GAME_PLAYER do
    --     if self.m_pGamePlayerArr[i] then
    --         m_mark = self.m_pGamePlayerArr[i].m_pGameCannon:getMarkWithBullet(bullet)
    --         break
    --     end
    -- end
    -- for i,v in ipairs(self.other_cannons) do
    --     local m_bs = v.m_bulletvec
    --     for m=1,#m_bs do
    --         if m_bs[m].m_bullet == bullet then
    --             m_mark = m_bs[m]:getmark()
    --             break
    --         end
    --     end       
    -- end
    -- return m_mark
end

-- function GameLayer:getMark( bullet )
--     local m_mark = 0
--     for i,v in ipairs(self.m_bullets) do
--         if v.m_bullet == bullet then
--             m_mark = v:getmark()
--             break
--         end
--     end
--     return m_mark
-- end

function GameLayer:collide(_fish,nViewID,bulletidx)
    local m_fish = _fish:getParent()
    local fishid = m_fish._id
    -- for i,v in ipairs(self.m_fishes) do
    --     if v._target == _fish and v.fish_state ~= GameData.Fish_Stru then
    --         fishid = v._id
    --         break
    --     end    
    -- end 
    if m_fish.fish_state ~= GameData.Fish_Stru then
        Layer_LuaClient:sendUserCollide(fishid,nViewID,bulletidx)
    end    
    if m_fish._kind == FISH_LI1 or m_fish._kind == FISH_DRAGON then
        m_fish:changeColor()    
    end    
end
--需要延时1秒???
function GameLayer:changeMark()
    self:removeMarkFish()
    -- self.mark_fish:subMark(MY_VIEWID)
    -- self.mark_fish.bMark = false
    --self.mark_fish._target:getChildByTag(999):removeFromParent()
    -- self.mark_fish = nil
    -- if self.m_card then
    --     self.m_card:clear()
    --     self.m_card = nil
    -- end    
    local m_bullets = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.m_bulletvec
    for i,v in ipairs(m_bullets) do
        
        v:setMark(false)
    end
    --取下一个
    self:selectFish()
end

function GameLayer:shootMark(_fish,_bullet)
    -- for i,v in ipairs(self.m_fishes) do
    --     if v._target == _fish and v.bMark == true then --and v.fish_state ~= GameData.Fish_Stru then
    --         self:collide(_fish)
    --         self:FallingNet(_bullet) 
    --     end    
    -- end    
    -- if _fish:getParent().bMark == true then
    if _fish:getParent():getMark(_bullet:getParent().nViewID) == true then
        self:collide(_fish,_bullet:getParent().nViewID,_bullet:getParent().m_idx)
        self:FallingNet(_bullet) 
    end    
end

function GameLayer:FallingNet(_bullet)
    -- for i,v in ipairs(self.m_bullets) do
    --     if v.m_bullet == _bullet then
    --         v:addFishNet()
    --         table.remove(self.m_bullets,i)
    --         --break
    --         return
    --     end    
    -- end

    -- for k,v in pairs(self.other_cannons) do
    --     local m_bs = v.m_bulletvec 
    --     for i,t in pairs(m_bs) do
    --         if t.m_bullet == _bullet then
    --             t:addFishNet()
    --             table.remove(m_bs, i)
    --             break
    --         end   
    --     end
    -- end

    for i=1,GAME_PLAYER do
        if self.m_pGamePlayerArr[i] then
            m_mark = self.m_pGamePlayerArr[i].m_pGameCannon:addFishNet(_bullet)
        end
    end
end
--撞墙改变方向
function GameLayer:changeBulletDirection(_bullet)
    _bullet:getParent():changeDirection()
    -- for i,v in ipairs(self.m_bullets) do
    --     if v.m_bullet == _bullet then
    --         v:change()
    --         --break
    --         return
    --     end    
    -- end
    -- for k,v in pairs(self.other_cannons) do
    --     local m_bs = v.m_bulletvec 
    --     for i,t in pairs(m_bs) do
    --         if t.m_bullet == _bullet then
    --             t:change()
    --             break
    --         end   
    --     end
    -- end
end
--暂停所有鱼
function GameLayer:PauseAllFish()
    for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
        --v._target:pause()
        v.fish_state = GameData.Fish_Stop
    end
    self.fish_layer:onPause()
    -- self.pause = true
    self.stop_handler = utils.setTimeout(10,handler(self,self.ResumeAllFish))
end
--恢复所有鱼
function GameLayer:ResumeAllFish()
    for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
        --v._target:resume()
        v.fish_state = GameData.Fish_Move
    end
    self.fish_layer:onResume()
    -- self.pause = false
    self.stop_handler = nil
end

function GameLayer:touchSelectFish(x,y)
    local is_select = false
    for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
        local s = v._target:getBoundingBox()
        if cc.rectContainsPoint(s,cc.p(x,y)) then 
            if self:haslockedFish(v) then 
                is_select = true
            end      
            break    
        end
    end
    if is_select then
        self:showLockCard()
        self:lockFish()
        -- self.nolock_fish = false
        --改变子弹路径
        -- self:lockBullet()
    else  
        --转自动
        --self.nolock_fish = true
        log("未选中目标")
    end
end

function GameLayer:haslockedFish( fish )
    if utils.contain_value( GameData._kindseq , fish._kind ) and fish:isInside(0) then
        self:removeMarkFish()

        local name = "CURSOR"
        local res = GameData.MYRES[name]
        local sp = utils.getAnimSprite(create_uipath("ui/curson.png"),res,nil,nil,0.1):addTo(fish._target)
            :setPosition(fish._target:getContentSize().width/2,fish._target:getContentSize().height/2)   
            :setTag(999)
        -- fish.bMark = true
        self.m_pGamePlayerArr[MY_VIEWID].m_pMarkFish = fish
        fish:addMark(MY_VIEWID)
        self.mark_fish = fish
        --self:updateSelect(fish)
        log("locked fish kind:",fish._kind)
        return true
    end
    return false
end
--自动:_kindseq
function GameLayer:selectFish()
    -- if self.init_position == LINE_MOVE then
    --     self.nolock_fish = true
    --     return
    -- end    
    local is_select = false
    for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
        if (v.fish_state == GameData.Fish_Move or v.fish_state == GameData.Fish_Stop) and self:haslockedFish(v) then
            is_select = true
            break
        end      
    end  
    if is_select then
        self:showLockCard()
        self:lockFish()
        -- self.nolock_fish = false
    else  
        --转自动
        -- self.nolock_fish = true
    end  
end

function GameLayer:showLockCard()
    if self.m_card then
        --utils.cleanChildAndEffect(self.m_card) 
        self.m_card:clear()      
    end 
    self.m_card = LockCard.new():addTo(self.player_layer)
    self.m_card:show(self.mark_fish, self.m_pGamePlayerArr[MY_VIEWID])
end

function GameLayer:removeMarkFish()
    if self.mark_fish then
        if self.mark_fish._target then
            self.mark_fish._target:removeChildByTag(999)
            self.mark_fish:subMark(MY_VIEWID)
        end
        self.m_pGamePlayerArr[MY_VIEWID].m_pMarkFish = nil
        self.mark_fish = nil
    end
    if self.m_card then
        self.m_card:clear()
        self.m_card = nil
    end
    -- for i,v in ipairs(self.fish_layer.m_tagAllFishes) do
    --     -- if v ~= fish and v._target:getChildByTag(999) then
    --     --     log("remove target")
    --     --     v.bMark = false
    --     --     v._target:getChildByTag(999):removeFromParent()
    --     -- end 
    --     if v._target:getChildByTag(999) then
    --         log("remove target")
    --         -- v.bMark = false
    --         v:subMark(MY_VIEWID)
    --         v._target:getChildByTag(999):removeFromParent()
    --     end   
    -- end
end

-- function GameLayer:lockBullet()
    -- local m_bullets = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.m_bulletvec
    -- for i,v in ipairs(m_bullets) do
    --     v:changeLock(self.mark_fish._target:getPositionX(),self.mark_fish._target:getPositionY())
    -- end
-- end

function GameLayer:userFire(fire_x, fire_y)
    local _player = self.m_pGamePlayerArr[MY_VIEWID]
    if _player:checkNoMoney() == true then
        if os.time() - self.last_charge_time > 5 then
            OpenUICharge()
            self.last_charge_time = os.time()
        end    
        return
    end
    -- local m_money = self._money - self.cost_score
    -- if m_money < 0 then
    if _player:checkNoMoney() == true then
        -- if self.auto_open == 0 then
        --     self.auto_open = 1
        --     self.auto_effect:setVisible(false)
        --     self.auto_xy = nil
        --     self.mark_fish = nil
        --     self.lock_open = 1
        -- end
        OpenUICharge()
        self.last_charge_time = os.time()
        return false
    end    
    _player.m_pGameCannon:removeOwnTip()

    -- self._money = m_money
    -- self.g_uiLayer:updateMoney(self._money)
    _player:subMoney()
    self.g_uiLayer:updateMoney(_player:getMoney())

    local fishid = nil 
    if self.mark_fish then
        fishid = self.mark_fish._id
    end
    
    self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon:rotateToPoint(fire_x, fire_y, true, fishid)
    self.fire_time = os.time()
    if self.m_tip then
        scheduler:unscheduleScriptEntry(self.tip_update)
        utils.cleanChildAndEffect(self.m_tip)
        self.m_tip = nil
        self.time_tip = false
    end   
    return true 
end

function GameLayer:initTouch()
    local function onTouchBegan(touch, event)
        if self.m_bStopFire == true then
            return true
        end    
        --if self.g_uiLayer.help and self.g_uiLayer.help:isVisible() == true then
            --self.g_uiLayer.help:setVisible(false)
        --else    
            if self.m_bLockOpen == true then
                local x = touch:getLocation().x
                local y = touch:getLocation().y
                if G_bViewTurn then
                    x = winSize.width - touch:getLocation().x
                    y = winSize.height - touch:getLocation().y
                end    
                self:touchSelectFish( x,y )
            else
                local m_bullets = self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.m_bulletvec
                if #m_bullets < MAX_BULLET then 
                    if self.m_bAutoOpen == true then
                        if self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon:isFire() then 
                            if self:userFire( touch:getLocation().x,touch:getLocation().y ) then
                                self.auto_xy = {x=touch:getLocation().x,y=touch:getLocation().y}
                                Layer_LuaClient:sendUserFire(self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.rotate / 180 * math.pi)
                            end
                        else
                            self.auto_xy = {x=touch:getLocation().x,y=touch:getLocation().y}        
                        end    
                    elseif self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon:isFire() then
                        if self:userFire( touch:getLocation().x,touch:getLocation().y ) then
                            Layer_LuaClient:sendUserFire(self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon.rotate / 180 * math.pi)
                        end    
                    end        
                else    
                end  
                self.touch_x = touch:getLocation().x
                self.touch_y = touch:getLocation().y
                self:beginLongTime()  
            end 
        --end        
        return true
    end

    local function onTouchMoved(touch, event) 
        if self.mark_fish then
            return
        end    
        self.auto_xy = {x=touch:getLocation().x,y=touch:getLocation().y}
        self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon:rotateToPoint(touch:getLocation().x, touch:getLocation().y, false)
         
        self.touch_x = touch:getLocation().x
        self.touch_y = touch:getLocation().y           
    end

    local function onTouchEnded(touch, event) 
        --log("zzz",touch:getLocation().x,touch:getLocation().y)
        if self.long_time then
            --log("cancel long end")
            scheduler:unscheduleScriptEntry(self.long_time)
            self.long_time = nil
        end   
        self.long_touch = false 
    end

    local listener = cc.EventListenerTouchOneByOne:create()
    listener:setSwallowTouches(true)

    listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
    listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED )
    listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED )
   

    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
end

function GameLayer:beginLongTime()
    local function longTouch()
        log("long Touch")
        scheduler:unscheduleScriptEntry(self.long_time)
        self.long_touch = true   
    end
    if self.long_time == nil then
        self.long_time = scheduler:scheduleScriptFunc(longTouch,0.25,false)
    end     
end

function GameLayer:onNodeEvent(event)
    if event == "enter" then
        -- self:onEnter()
    elseif event == "exit" then
        self:onExit()
    end
end

function GameLayer:enterEvent()
    self.customListenerBg = cc.EventListenerCustom:create("APP_ENTER_BACKGROUND_EVENT",
                                handler(self, self.onEnterBackground))
    eventDispatcher:addEventListenerWithFixedPriority(self.customListenerBg, 1)
    self.customListenerFg = cc.EventListenerCustom:create("APP_ENTER_FOREGROUND_EVENT",
                                handler(self, self.onEnterForeground))
    eventDispatcher:addEventListenerWithFixedPriority(self.customListenerFg, 1)
end

function GameLayer:onEnterForeground()
    --log("foreground",socket:gettime())
    local _player = self.m_pGamePlayerArr[MY_VIEWID]
    -- self.dif_time = socket:gettime() - self.back_time
    -- local diff_time = socket:gettime() - self.back_time
    -- self.fish_layer:setEnterBackgroundTime(diff_time)
    Layer_LuaClient:sendGameEnter(_player.m_info.user.id)
    if self.lock_back then
        utils.setTimeout(0,function ()
            self:onClickLockFire()
            self.lock_back = false
        end)   
    end    
end

function GameLayer:onEnterBackground() 
    log("background", os.time())
    -- self.back_time = socket:gettime()
    --退到后台取消锁定
    if self.m_bLockOpen == true then
        self.lock_back = true
        self:onClickLockFire()
    end    
end

function GameLayer:onExit()
    if self.state_update then
        scheduler:unscheduleScriptEntry(self.state_update) 
    end    
    if self.tip_update then
        scheduler:unscheduleScriptEntry(self.tip_update)
    end    
    if self.stop_handler then
        utils.cleanTimeout(self.stop_handler)
    end    

    eventDispatcher:removeEventListener(self.customListenerBg)
    eventDispatcher:removeEventListener(self.customListenerFg)
    
    self.fish_layer:removeAllFish()
    -- for i=1 , #self.m_fishes do
    --     self.m_fishes[i]:clearFish()
    --     self.m_fishes[i] = nil
    -- end
    -- for i,v in ipairs(self.floor_glods) do
    --     v:onExit()
    -- end 
    
    -- self.m_pGamePlayerArr[MY_VIEWID].m_pGameCannon:clearCannon()
    -- for i,v in ipairs(self.other_cannons) do    
    --     v:clearCannon()
    -- end   
    
    -- local body = self.wall:getPhysicsBody() --?????????Physics
    -- body:removeFromWorld()

    -- remove image cache
    G_loading.removeImage()

    -- cc.SpriteFrameCache:getInstance():removeUnusedSpriteFrames()
    -- cc.Director:getInstance():getTextureCache():removeUnusedTextures()--removeAllTextures()
    GAMESOUND.stopBGM()
end

return GameLayer


