local utils = {}

function utils.isEmpty(value)
	return value==nil or value=="" or value==json.null or tonumber(value)==0 or type(value)=="userdata"
end

function utils.getCocosPos(pos)
	return cc.p(pos.x, display.height-pos.y)
end

function utils.GetRol(tagDir)
	local rol = 0
	if tagDir.y > 0 then
		if tagDir.x > 0 then
			rol = rol + math.pi/2
			rol = rol + math.atan(tagDir.y/tagDir.x)
		elseif tagDir.x < 0 then
			rol = rol + math.pi
			rol = rol + math.pi/2 + math.atan(tagDir.y/tagDir.x)
		else
			rol = math.pi
		end
	elseif tagDir.y < 0 then
		if tagDir.x > 0 then
			rol = rol + math.pi/2
			rol = rol + math.atan(tagDir.y/tagDir.x)
		elseif tagDir.x < 0 then
			rol = rol + math.pi
			rol = rol + math.pi/2 + math.atan(tagDir.y/tagDir.x)
		else
			rol = 0
		end
	else
		if tagDir.x > 0 then
			rol = rol + math.pi/2
		elseif tagDir.x < 0 then
			rol = rol + math.pi
			rol = rol + math.pi/2 + math.atan(tagDir.y/tagDir.x)
		else
			rol = 0
		end
	end
	return -rol -- cocos2dx的原点在左下角，所以返回负数
end

--------------------阴影----------------
function utils.setShader(node,shaderName)
	local vertDefaultSource = CCString:createWithContentsOfFile(cc.FileUtils:getInstance():fullPathForFilename("shaders/"..shaderName..".vsh")):getCString()
	local pszFragSource = CCString:createWithContentsOfFile(cc.FileUtils:getInstance():fullPathForFilename("shaders/"..shaderName..".fsh")):getCString()
--	log(vertDefaultSource)
	local pProgram = cc.GLProgram:createWithByteArrays(vertDefaultSource, pszFragSource)
    
    pProgram:bindAttribLocation(cc.ATTRIBUTE_NAME_POSITION, cc.VERTEX_ATTRIB_POSITION)
    pProgram:bindAttribLocation(cc.ATTRIBUTE_NAME_COLOR, cc.VERTEX_ATTRIB_COLOR)
    pProgram:bindAttribLocation(cc.ATTRIBUTE_NAME_TEX_COORD, cc.VERTEX_ATTRIB_FLAG_TEX_COORDS)
    pProgram:link()
    pProgram:updateUniforms()

    node:setGLProgram(pProgram)
end
function utils.setDefaultShader(node)
	Aprisk:setDefaultShaderForCCNode(node)
end
function utils.setGray(node)
	utils.setShader(node,"grey")
end
function utils.setDark(node)
	utils.setShader(node,"dark")
end
-------------------随机函数-----------------
function utils.random(a,b)
	math.randomseed(tostring(os.time()):reverse():sub(1, 6)) 
	return math.random(a,b)
end

--------------------清理类----------------
function utils.cleanChildAndEffect(child)
	if child then
		child:stopAllActions()
		-- if child.type_name and child.type_name == "animate" then
		-- 	child:clean()
		-- end
		child:removeFromParent(true)
		child = nil
	end
	--删纹理
	--cc.SpriteFrameCache:getInstance():removeUnusedSpriteFrames()
	--cc.Director:getInstance():getTextureCache():removeUnusedTextures()
end
--不好用
function utils.cleanAllChildAndEffect(childs)
	if childs then
		for k,v in pairs(childs) do
			utils.cleanChildAndEffect(v)
		end
	end
end

------------------延时函数------------------
function utils.setTimeout(timeout,handler)
	local id = 0
	function onTimeout()
		utils.cleanTimeout(id)
		handler()
	end
	id = cc.Director:getInstance():getScheduler():scheduleScriptFunc(onTimeout,timeout,false)
	return id
end
function utils.cleanTimeout(id)
	if id==nil or id<1 then return end
	cc.Director:getInstance():getScheduler():unscheduleScriptEntry(id)
end

-----------------纹理动画——----------------
function utils.getAnimationPlist(plist_path, img_name, num, per, times)
    local spriteFrame = cc.SpriteFrameCache:getInstance( )  
    spriteFrame:addSpriteFrames( plist_path )

	--spriteFrame:addSpriteFrames( create_uipath("plist/"..name..kind..".plist") )  
  
	local sp = cc.Sprite:createWithSpriteFrameName(img_name.."_01.png")    
  
	local animation = cc.Animation:create()  
	for i=1, num do  
		local framename = string.format(img_name.."_%02d.png", (i-1))
    	local blinkFrame = spriteFrame:getSpriteFrame( framename )
    	animation:addSpriteFrame( blinkFrame )  
	end  
	animation:setDelayPerUnit( per )  
	--animation:setRestoreOriginalFrame( true )
	local animate = cc.Animate:create(animation)  
	if times then
		sp:runAction(cc.Sequence:create(cc.Repeat:create(animate,times),cc.CallFunc:create(_endFunc)))
	else
		sp:runAction(cc.RepeatForever:create(animate))
	end	
	
	animation = nil
	return sp
	
end
function utils.getAnimSprite(img_path,res,times,_endFunc,per)
	local num =res[GameData.MYRES_FRAMES]
	local w = res[GameData.MYRES_WIDTH]
	local h = res[GameData.MYRES_HEIGHT]

	local per = per or 0.05

	--local texture = cc.Director:getInstance():getTextureCache():addImage(img_path)
	local texture = cc.Director:getInstance():getTextureCache():getTextureForKey(img_path)
	local frame_array = {}
	for i=1,num do
		local frame = cc.SpriteFrame:createWithTexture(texture,cc.rect(w*(i-1),0,w,h))
		table.insert(frame_array,frame)
	end
	local sp = cc.Sprite:createWithSpriteFrame(frame_array[1])
	local animation = cc.Animation:createWithSpriteFrames(frame_array,per)
	local animate = cc.Animate:create(animation)
	if times then
		sp:runAction(cc.Sequence:create(cc.Repeat:create(animate,times),cc.CallFunc:create(_endFunc)))
	else
		sp:runAction(cc.RepeatForever:create(animate))
	end	
	frame_array = nil
	return sp
end

function utils.plistAnimation( name,kind,times,_endFunc,per )
	local res = nil
	local per = per or 0.1
	local img_name = kind
	if name == "fish" then
		local n = "FISH"..kind
		res = GameData.MYRES[n]
	elseif name == "die" then
		local n = "FISHDIE"..kind
		res = GameData.MYRES[n]	
		img_name = name..kind
	elseif name == "net" then
		local n = "NET"..kind
		res = GameData.MYRES[n]
		img_name = name..kind
	end	
	
	local num =res[GameData.MYRES_FRAMES]

	local spriteFrame = cc.SpriteFrameCache:getInstance( )  
	--spriteFrame:addSpriteFrames( create_uipath("plist/"..name..kind..".plist") )  
  
	local sp = cc.Sprite:createWithSpriteFrameName(img_name.."_01.png")    
  
	local animation = cc.Animation:create()  
	for i=1, num do  
		local index = i 
		if i < 10 then
			index = "0"..index
		end	
    	local blinkFrame = spriteFrame:getSpriteFrame( img_name.."_"..index..".png" )  
    	animation:addSpriteFrame( blinkFrame )  
	end  
	animation:setDelayPerUnit( per )  
	--animation:setRestoreOriginalFrame( true )
	local animate = cc.Animate:create(animation)  
	if times then
		sp:runAction(cc.Sequence:create(cc.Repeat:create(animate,times),cc.CallFunc:create(_endFunc)))
	else
		sp:runAction(cc.RepeatForever:create(animate))
	end	
	res = nil
	animation = nil
	return sp
end

function utils.showTip(str)
	local showbg = display.newSprite(create_uipath("ui/wordback.png"))
	local tiplabel = utils.label(str,24):addTo(showbg)
		:setPosition(showbg:getContentSize().width/2,showbg:getContentSize().height/2)
		:setColor(cc.c3b(255,255,90))

	return showbg,tiplabel	
end
-----------------table-----------------
function utils.reverseTable( tab )
	local tmp = {}
	local total = #tab
	for i = 1, #tab do
		tmp[i] = tab[total-i+1]
	end

	return tmp
end

function utils.removeValue( _table,value )
	for k,v in pairs(_table) do
		if v == value then
			table.remove(_table,k)
			return _table
		end	
	end
	return false
end

function utils.contain_value(t,value)
	for i,v in pairs(t) do
		if v==value then			
			return true
		end
	end
	return false
end

-----------------string-----------------
function string.substringBetweenArray (str,beginStr,endStr)	
	local resultArr={};
	while true do
		local beginPos=string.find(str,beginStr,1,1)
		if beginPos ==nil then break end
		if(beginPos<=0) then
			break;
		end
		local beginStrLen = string.len(beginStr)
		local strlen=string.len(str)
		local leftstr=string.sub(str,beginPos+beginStrLen,strlen)
		local endPos=string.find(leftstr,endStr,1,1)
		if(endPos<=0) then
			break;
		end
		local ret = string.sub(str,beginPos+beginStrLen,beginPos+endPos-1)
		table.insert(resultArr, ret);
		str = string.sub(str,beginPos+endPos);
	end		
	return resultArr;	
end
function string.substringBefore(str,searchStr)
	if string.find(str,"&&") then
		str = string.replace(str,"&&","")
		searchStr = string.replace(searchStr,"&&","%%")
	end 
	
	local pos = string.find(str, searchStr)
	if not pos then
		return str
	end
	return string.sub(str,0,pos-1)
end
function string.replace(str,searchStr,replaceStr)
	return string.gsub(str,searchStr,replaceStr)
end

function string.substringAfter(str,searchStr)
	if string.find(str,"&&") then
		str = string.replace(str,"&&","")
		searchStr = string.replace(searchStr,"&&","%%")
	end 
	
	local pos = string.find(str, searchStr)
	if not pos then
		return str
	end
	return string.sub(str, pos + string.len(searchStr))
end
-----------------string-----------------

function utils.HEXCOLOR(c)
    return cc.c3b(bit.band(bit.brshift(c,16),0xff),
        bit.band(bit.brshift(c,8),0xff),
        bit.band(bit.brshift(c,0),0xff))
end

-------------------UI-------------------
function utils.label(text,size,color,an_px,an_py)
	local _size = size or 18
	local px = an_px or 0.5
	local py = an_py or 0.5
	local color = color or cc.c3b(255,255,255)
	local m_lable = cc.Label:create()
        :setSystemFontSize(_size)
        :setAnchorPoint(cc.p(px, py))
        :setString(text)
        :setColor(color)
    return m_lable   
end

function utils.richlabel(str , size)
	local richlabel = ccui.RichText:create()
	local wordsArr = {}
	local _color = cc.c3b(255,255,255)
	local arr = string.substringBetweenArray (str,"<",">")
	for k,v in ipairs(arr) do
		local before = string.substringBefore(str,"<"..v..">")	
		if not utils.isEmpty(before) then
			table.insert(wordsArr , {words = before , size = size , color = _color})
		end	
		local middleArr = string.substringBetweenArray (v,"{","}")
		local after = ""
		local m_size = size
		local m_color = _color
		--local line_color = 0
		--local line_size = 0
		for i,j in ipairs(middleArr) do
			after = after.."{"..j.."}"
				
			local formart = string.split(j,",")
			if #formart == 1 then--size
				m_size =  formart[1]
			elseif #formart == 3 then--color
				m_color = cc.c3b(formart[1],formart[2],formart[3]) 
			-- elseif #formart == 5 then--line color
			-- 	line_color = cc.c4b(formart[1],formart[2],formart[3],formart[4])
			-- 	line_size = formart[5]
			end
		end
		local middle = string.substringAfter (v,after)
		table.insert(wordsArr , {words = middle , size = m_size , color = m_color})

		str = string.substringAfter(str,"<"..v..">")
	end
	if string.len(str)>0 then
		table.insert(wordsArr , {words = str , size = size , color = _color})
	end

	for k,v in ipairs(wordsArr) do
		local element = ccui.RichElementText:create(0, v.color, 255, v.words, "arial", v.size)
		richlabel:pushBackElement(element)
	end	
	return richlabel
end

function utils.button(res_normal,res_pressed,title,callFunc,title_size)
	local _size = title_size or 20
	local m_btn =ccui.Button:create(res_normal,res_pressed)
	m_btn:setPressedActionEnabled(true)
	if title then
        m_btn:setTitleText(title)
        m_btn:setTitleFontSize(_size)
    end    
    m_btn:addClickEventListener(function ()
    	callFunc(m_btn)
    end)
    m_btn.setString = function(self,value)
    	m_btn:setTitleText(value)
    end
    return m_btn
end
function utils.loadBar(bgName,barName,bgW,bgH,barW,barH)
    local bg = utils.scale9Sprite(bgName[1],bgName[2],bgW,bgH)
    bg:setAnchorPoint(cc.p( 0.5,0.5 ))
    
    local bar = utils.scale9Sprite(barName[1],barName[2],barW,barH)
    bar:setAnchorPoint(cc.p( 0,0.5 ))
    bar:setPosition(cc.p( (bgW-barW)/2,bg:getContentSize().height/2 ))
    bg:addChild(bar)
    
    bg.percent = function (self,value)
        value = math.min(value , 100)
        bar:setVisible(true)
        if value>5 then
            bar:setContentSize(cc.size(barW*value/100,barH))
        elseif value>5 then
            bar:setVisible(false)
        else
            bar:setContentSize(cc.size(barW*6/100,barH))
        end
    end
    
    bg:percent (0)
    
    return bg
end

function utils.scale9Sprite(fullPath, param,width , height)
    local function getCapInsets(param)

        local capInsetsT = param
        local top, bottom, left, right = capInsetsT[1], capInsetsT[2], capInsetsT[3], capInsetsT[4]
        local x = left
        local y = top
        local w = right - left > 0 and right - left or 1
        local h = bottom - top > 0 and bottom - top or 1
        return cc.rect(x, y, w, h)
    end
    local sprite = cc.Scale9Sprite:create(fullPath) 
    sprite:setCapInsets(getCapInsets(param))  
    sprite:setContentSize(cc.size(width, height))
    return sprite
end

return utils
