module("GAMESOUND",package.seeall)

local bgm = {Back_Sound_0,Back_Sound_1,Back_Sound_2,Back_Sound_3}
local die_sound = {Die_Sound_0,Die_Sound_1,Die_Sound_2,Die_Sound_3,Die_Sound_4}
local is_sound = true
local is_music = true
local music_index = 1

local user_default = cc.UserDefault:getInstance()

function initSound()
    local _music = user_default:getStringForKey("music_203")
    local _sound = user_default:getStringForKey("sound_203")
    if _music == "0" then
        is_music = false
    end
    if _sound == "0" then
        is_sound = false
    end   
end

function playBGM( _index )
    if _index == nil then
        _index = music_index
    end    
    if is_music then
	    audio.preloadMusic(create_uipath(bgm[_index]))   
        audio.playMusic(create_uipath(bgm[_index]))
    end    
    music_index = _index
end

function stopBGM()
	audio.stopMusic()
end

function playEffect( effect_file )
	if is_sound then
		audio.playSound( create_uipath(effect_file) ) 
	end	
end

function playDieSound( _kind )
	local sound = nil
    if _kind == 15 then
        sound = die15_Sound
    elseif _kind == 17 then 
        sound = die_shark_Sound 
    elseif _kind == 19 then 
        sound = die18_Sound
    elseif _kind == 25 then
        sound = die25_Sound
    elseif _kind == 30 then
        sound = die30_Sound
    elseif _kind >=5 and _kind <=9 then
        local rand = utils.random(1,5) 
        sound = die_sound[rand]
    end
    if sound then
        playEffect( sound )
    end 
end

function stopEffects( )
	audio.stopAllSounds()
end

function openSound()
	is_sound = true
    user_default:setStringForKey("sound_203",1)
    user_default:flush()
end

function closeSound()
	is_sound = false
    user_default:setStringForKey("sound_203",0)
    user_default:flush()
end

function getIsSound()
    return is_sound
end

function openMusic()
    is_music = true
    user_default:setStringForKey("music_203",1)
    user_default:flush()
end

function closeMusic()
    is_music = false
    user_default:setStringForKey("music_203",0)
    user_default:flush()
end

function getIsMusic()
    return is_music
end