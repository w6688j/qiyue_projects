local GameFloorGold = class("GameFloorGold", function (...)
	return display.newSprite()
end)

function GameFloorGold:initData(money,m_tagPos,m_fRol,index,viewID)	
	self.money = money
	self.m_tagPos = m_tagPos
	self.m_fRol = m_fRol
	self.index = index
	self.nViewID = viewID
	self.time_count = 0
	self.golds = {}
	self.move_state = 0

	if self.index > 2 then
		self.index = self.index % 3
	end	
end

function GameFloorGold:ctor(fishkind)
	self.gold_height = max_gold[fishkind+1]
	if self.gold_height then
		local scheduler=cc.Director:getInstance():getScheduler()
		self.time_update = scheduler:scheduleScriptFunc(handler(self,self.update),0.1,false)    
	end

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
end
function GameFloorGold:onEnter()
	
end

function GameFloorGold:update()
	self.time_count = self.time_count + 1
	local add_y = self.time_count*6
	local _x = self.m_tagPos.x-100- self.index*40
	local _y = self.m_tagPos.y - 30
	if GamePlayer.isTopUser(self.nViewID) then
		add_y = -self.time_count*6
		_x = self.m_tagPos.x+100+ self.index*40
		_y = self.m_tagPos.y + 30
	end	
	local sp = display.newSprite(create_uipath("Player/FLOORGOLDS.png")):addTo(self)
        :setPosition(cc.p( _x ,_y+add_y))
    table.insert(self.golds,sp)    
    --log(self.time_count,self.gold_height)
    if self.time_count == self.gold_height then
    	local scheduler=cc.Director:getInstance():getScheduler()
    	scheduler:unscheduleScriptEntry(self.time_update)
    	self:addMoney()
    	if self.move_state > 0 then
    		self:move()
    	else
    		self:FadeOut()
    	end		
    end  
end

function GameFloorGold:addMoney()
	local add_money = cc.LabelAtlas:_create("0",create_uipath("Player/FLOORSCORE.png"),16,18,string.byte('0')):addTo(self)
		:setAnchorPoint(cc.p(0.5,0.5))
	local add_y = self.gold_height*6 
	local _x = self.m_tagPos.x-100- self.index*40
	local _y = self.m_tagPos.y - 30
	if GamePlayer.isTopUser(self.nViewID) then
		add_y = -self.gold_height*6 - 30
		_x = self.m_tagPos.x+100+ self.index*40
		add_money:setRotation(180)
		_y = self.m_tagPos.y + 30
	end
    add_money:setPosition(_x  ,_y+15+add_y)
    add_money:setString(self.money)

    self.add_money = add_money
end

function GameFloorGold:FadeOut()
	local act = cc.Sequence:create(
				cc.DelayTime:create(1.0),
				cc.FadeOut:create(1.0),
				cc.CallFunc:create(function ()
					local event = cc.EventCustom:new(GameData.REMOVE_FLOOR_GLOD)
					event._usedata = self
    				eventDispatcher:dispatchEvent(event)
    				-- self:clear()
    				self:removeFromParent()
				end)
			)
	self.add_money:runAction(act)
	for k,v in pairs(self.golds) do
		v:runAction(cc.Sequence:create(
				cc.DelayTime:create(1.0),
				cc.FadeOut:create(1.0)
			))
	end
end

function GameFloorGold:move()
	local moveby = 40
	if GamePlayer.isTopUser(self.nViewID) then
		moveby = -40
	end	
	if self.index == 0 then
		self:FadeOut()
		return
	end	
	for k,v in pairs(self.golds) do
		v:runAction(cc.MoveBy:create(0.3,cc.p(moveby,0)))
	end	
	self.add_money:runAction(cc.Sequence:create(
			cc.MoveBy:create(0.3,cc.p(moveby,0)),
			cc.CallFunc:create(function ()
				self:FadeOut()
			end)
		))
end

function GameFloorGold:clear()
	self.money = nil
	self.m_tagPos = nil
	self.m_fRol = nil
	self.index = nil
	self.nViewID = nil
	self.time_count = nil
	self.golds = nil
	self.move_state = nil
	self.time_update = nil
	--utils.cleanAllChildAndEffect(self:getChildren())
	-- self:removeFromParent()
end

function GameFloorGold:onExit()
	if self.time_update then
		local scheduler=cc.Director:getInstance():getScheduler()
		scheduler:unscheduleScriptEntry(self.time_update)
	end
	self:clear()
end

return GameFloorGold