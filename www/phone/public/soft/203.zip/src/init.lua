
import(".Marco")
import(".GameDef")
import(".GameSound")

--获取时间毫秒
-- socket = require "socket"

GamePos		=import(".GamePos")
POS			=import(".POS")
--Player 		=import(".Player")
GameLoading =import(".GameLoading")
GameData 	=import(".GameData")
GameClient 	=import(".GameClient")

GameLayer   =import(".GameLayer")
KeyPoint 	=import(".keypoint")
g_point     =KeyPoint.new()

GamePlayer  =import(".GamePlayer")
GameCannon  =import(".GameCannon")
GameBullet  =import(".GameBullet")
FishLayer	=import(".FishLayer")
GameFish    =import(".GameFish")
GameHelp    =import(".GameHelp")
GameSet     =import(".GameSet")
BuyPopup    =import(".BuyPopup")
GameUILayer =import(".GameUILayer")
utils       =import(".utils")
PM          =import(".ParticlesLayer")
GameFloorGold =import(".GameFloorGold") 
LockCard    =import(".LockCard")
MessageBox  = import(".MessageBox")

DebugLayer  =import(".DebugLayer")

-- pGameLayer	= nil

log = function (...)
	if device.platform == "mac" or device.platform == "ios" then
		local debug = debug.getinfo(2)
		local more = ...
		local _, _, filename = string.find(debug.source, "src/(%a+.lua)")
		if debug.name then
    		print(filename..": "..debug.name..":"..debug.currentline..": ", ...)
    	else
    		print(filename..": "..debug.currentline..": "..more)
    	end
    end
end
