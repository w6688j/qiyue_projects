
local GameFish = class("GameFish", function (...)
	return display.newSprite()
end)

function GameFish:init()
	self.m_CurveIndex = 0
	self.m_StopCurveIndex = 0
	self.m_nPosNum = 0
	self.m_fDifRol = 0

	self.m_tagPosArr = {}
	self.m_tagRolArr = {}
	self.m_tMarkPlayer = {}

	-- 圆形鱼阵
	self.m_tagCurRol = 0
end

-- function GameFish:ctor(_kind,_idpos,_prop_type,_size,_move_type,_path,viewid,val)
function GameFish:ctor(_kind,_idpos,_prop_type,_size,_move_type,val)
	self:init()

	self._idpos = _idpos
	self._id = _idpos.id
	self._kind = _kind
	self._prop = _prop_type
	self.offset = _idpos.offset
	-- self.val = val

	self.die_tag = false
	-- self.update_tag = false

	-- if G_bViewTurnthen
	-- 	self.offset_tag = -1
	-- end	

	local name = "FISH".._kind
	if _kind == FISH_QQ then
		-- local cardtype = utils.random(1,2)
        local qq_sp = display.newSprite(create_uipath("qq/popo.png")):setTag(1000):addTo(self)
        qq_sp:runAction(cc.RepeatForever:create(cc.RotateBy:create(1.5,360))) 

        -- local point = _path[1]
        -- self._target = display.newSprite(create_uipath("qq/q"..cardtype..".png")):addTo(self)
        self._target = display.newSprite(create_uipath("qq/qqcard.png")):addTo(self)
            -- :setPosition( point[2]-self.offset.x,self:changePos(point[1]-self.offset.y) )  
            
        -- if cardtype == 1 then
        cc.LabelAtlas:_create(val,create_uipath("qq/qqnum.png"),23,37,string.byte('0')):addTo(self._target)
            :setPosition(qq_sp:getContentSize().width/2-12,qq_sp:getContentSize().height/2-4)
        -- else
        --     cc.LabelAtlas:_create(val,create_uipath("qq/num2.png"),28,43,string.byte('0')):addTo(self._target)
        --         :setPosition(qq_sp:getContentSize().width/2-12,qq_sp:getContentSize().height/2-8)
        -- end
        --qq_sp:runAction(cc.RepeatForever:create(cc.RotateBy:create(1.5,-360))) 					
	else
		if self._prop == NO_Prop then
			if _kind == 18 then
				self._target = utils.plistAnimation("fish",_kind,nil,nil,0.3):addTo(self)
			else	
				self._target = utils.plistAnimation("fish",_kind):addTo(self)
			end
		else --道具
			local prop_img = self._prop
			if _size == 3 then
				prop_img = 0
			end	
			local sp = cc.Sprite:create(create_uipath(GameData.MYRES["PROP"..prop_img][GameData.MYRES_PATH]))
				:setTag(1000):addTo(self)
			local rotate_time = 2
			-- log(prop_img)
			if prop_img == 2 then
				rotate_time = 1.3
				sp:setScale(0.8)
			end	
			sp:runAction(cc.RepeatForever:create(cc.RotateBy:create(rotate_time,360)))

			self._target = utils.plistAnimation("fish",_kind):addTo(self)
			-- local point = _path[1]	
			-- sp:setPosition( point[2]-self.offset.x,self:changePos(point[1]-self.offset.y) )
			
			-- if _kind >= 4 and _kind <= 19 then
			-- 	sp:setScale(0.8)
			-- end	
		end
	end			

	--鱼尺寸处理
	-- if _kind==FISH_DRAGON then
	-- 	self._target:setScale(1.5)
	-- end	
	self:adjustScale(self._target, _kind)

	-- self:addHitBox(self._target)	 --?????????Physics

	-- self.cur_point = _idpos.curpos
	--log("zzzz point",self.cur_point)
	-- if self.cur_point <= 0 then
	-- 	self.cur_point = 1
	-- end		
	-- if _move_type ~= LINE_MOVE and _move_type ~= CIRCLE_MOVE then
	-- 	local point = _path[self.cur_point] 
	-- 	if point == nil then
	-- 		log("point nil========",#_path.points,self.cur_point)
	-- 	end
 --    	self._target:setPosition(point[2]-_idpos.offset.x ,self:changePos(point[1]-_idpos.offset.y))
 --    	--log("self._target:getPosition()",self._target:getPositionX(), self._target:getPositionY())
 --    	self._path = _path
 --    elseif _move_type == LINE_MOVE then
 --    	if self.cur_point < 0 then
	-- 		self.cur_point = 1
	-- 	elseif self.cur_point > Line_Point then
	-- 		self.cur_point = self.cur_point % Line_Point	
	-- 	end		
	-- end	
	
	-- self.count_point = 0
	self._move_type = _move_type
	
	self.fish_state = GameData.Fish_Rendy
	-- self.first_game = false
	-- self.bMark = false

	--self:updateScheduler()
    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
end

function GameFish:onEnter()
	
end

function GameFish:adjustScale(target,_kind)
	local m_scale = 1
	if _kind == 0 or _kind == 1 then
		m_scale = 1.3
	elseif _kind == 6 then
		m_scale = 1.1	
	elseif _kind == 15 or _kind == 16 then
		m_scale = 1.1
	elseif _kind == 17 then
		m_scale = 0.9
	elseif _kind == 20 or _kind == 27 then
		m_scale = 1.1
	elseif _kind == 25 then
		m_scale = 1.2
	elseif _kind == 26 then
		m_scale = 1.0		
	end	
	if m_scale == 1 then
		return
	end	
	target:setScale(m_scale)
end

-- function GameFish:changePos(pos_y)
    -- Cocos的原点坐标在左下角
	-- local result = pos
	-- if G_bViewTurn then
	-- 	result = winSize.height - pos
	-- end	
	-- return result
-- 	return display.height - pos_y
-- end

function GameFish:updateScheduler()
    -- self.cur_point = self.cur_point + 1
	-- if self._move_type == LINE_MOVE or self._move_type == CIRCLE_MOVE then
		-- local x,y = self._target:getPosition()
		-- local dis = math.sqrt( math.pow((self.line_start_p.x-x),2) + math.pow((self.line_start_p.y-y),2) )
		-- if dis / self.line_dis >= self.stoppos / Line_Point and self._kind < 10 then
		-- 	self._target:stopAction(self.move_act)
		-- end	
		if self.fish_state == GameData.Fish_Rendy then
			if self.m_CurveIndex >= 0 then
				-- self.m_CurveIndex = math.floor(self.m_CurveIndex)
				self.fish_state = GameData.Fish_Move
			else
				self.m_CurveIndex = self.m_CurveIndex + 1
			end
		elseif self.fish_state == GameData.Fish_Move then
			if self._move_type == LINE_MOVE then
				self:LineFishMove()
			elseif self._move_type == CIRCLE_MOVE then
				self:CircleFishMove()
			else
				self:CurveFishMove()
			end
		elseif self.fish_state == GameData.Fish_Die then
			self:DeleteFish()
		end
		-- if self._kind == 20 then
		-- 	log("=====>", self.fish_state, self.m_CurveIndex)
		-- end

	-- elseif self._move_type == CIRCLE_MOVE then
	-- 	if self.fish_state == GameData.Fish_Move then
	-- 		-- self.count_point = self.count_point + 1
	-- 		self:CircleFishMove()
	-- 	end	

	-- 	self:JudgeOutOfBoundary()
	-- else--if self._move_type == 0 or self._move_type == 1 or self._move_type == 3 then
	-- 	if self._path then
	-- 		if self.cur_point > #self._path then
 --    			local event = cc.EventCustom:new("delete_fish")
 --    			event._usedata = self
 --    			eventDispatcher:dispatchEvent(event) 
	-- 			return
	-- 		end
	-- 		self:CurveFishMove()
	-- 	end	

	-- 	self:JudgeOutOfBoundary()
	-- end	
end

--[[function GameFish:updatePos(idpos)
	if self._move_type == LINE_MOVE then
		-- if idpos.curpos == self.stoppos then
		-- 	return
		-- end	
		-- log("updatePos",idpos.curpos)
		-- self._target:stopAction(self.move_act)
		-- local x = self.line_start_p.x
		-- local y = self.line_start_p.y
		-- local speed = 90
		-- --大鱼坐标处理
		-- if self._kind > 14 and self.stoppos then
		-- 	if self.line_start_p.x < 0 then
		-- 		x = self.line_start_p.x + idpos.curpos - self.line_count * 100
		-- 	else
		-- 		x = self.line_start_p.x - idpos.curpos + self.line_count * 100
		-- 	end	
		-- 	speed = 102
		-- else--小鱼
		-- 	y = idpos.curpos	
		-- end	
		-- self._target:setPosition(cc.p( x,y ))	

		-- local dis = math.sqrt( math.pow((x-self.line_end_p.x),2) + math.pow((y-self.line_end_p.y),2) )	
		-- local t = dis / speed
		-- self.move_act = cc.MoveTo:create(t,cc.p(self.line_end_p.x,self.line_end_p.y))
		-- self._target:runAction( self.move_act )

	elseif self._move_type == CIRCLE_MOVE then
		--log("updatePos",self._id,idpos.curpos)
		--local point_dif = idpos.curpos - self.count_point 
		--self.count_point = idpos.curpos
		local point_dif = idpos.curpos - self._idpos.curpos 
		self._idpos.curpos  = idpos.curpos
		self.count_point = self.count_point + point_dif
		local point_num = 6
		local now_index = self.count_point * point_num  
		if self.count_point * point_num > #self.m_tagPosArr then
			local more = math.floor(self.count_point * point_num / #self.m_tagPosArr)
	
			now_index = self.count_point * point_num - more * #self.m_tagPosArr

			if now_index == 0 then
				now_index = #self.m_tagPosArr
			end	
		end	
		local point = self.m_tagPosArr[now_index]
		self._target:setPosition(cc.p(point.x,point.y))

		local _fAddRol=point_dif * (180 / math.pi) * point_num * 6.28/900--nPosNum

		--反向
		self._target:setRotation(self.m_fAngle+_fAddRol ) 
		self.m_fAngle = self.m_fAngle+_fAddRol
	else
		local point = self._path[self.cur_point]

		self.fish_state = GameData.Fish_Move

		local next_x = point[2]-self.offset.x  
		local next_y = self:changePos( point[1]-self.offset.y ) 
    	self._target:setPosition(next_x,next_y)
    	local rol = -(point[3] - 90)
    	-- if G_bViewTurn then
    	-- 	rol = - rol
    	-- end

    	if self._prop == NO_Prop then   		
    		self._target:setRotation(rol)
    	else
    		if self:getChildByTag(1000) then
    			local sp = self:getChildByTag(1000) 
    			local next_y = self:changePos( point[1]-self.offset.y ) 
    			sp:setPosition(point[2]-self.offset.x,next_y)
    			sp:setRotation(rol)
    		end	
    	end
	end	
end--]]

function GameFish:addHitBox(sp)	
	local box = nil
	if self._kind == 15 or self._kind == 16 then
		m_size = cc.size(sp:getContentSize().width,sp:getContentSize().height*0.75)
		box = cc.PhysicsBody:createBox(m_size)
	elseif self._kind == 17 or self._kind == 26 then
		m_size = cc.size(sp:getContentSize().width*0.9,sp:getContentSize().height*0.4)
		box = cc.PhysicsBody:createBox(m_size)
	else
		box = cc.PhysicsBody:createCircle(sp:getContentSize().width/3) 	
	end	
	box:setDynamic(true) 
	box:setCategoryBitmask(1)    
	box:setContactTestBitmask(1)    
	box:setCollisionBitmask(2)  
	sp:setPhysicsBody(box) 
	sp:setTag(GameData.FISH_TAG)
end

function GameFish:isInside(border)
	local border = border or 100
	--local w = self._target:getContentSize().width
	--local h = self._target:getContentSize().height
	if self._target:getPositionX() < -(border) or self._target:getPositionX() > winSize.width+border or 
		self._target:getPositionY() < -(border) or self._target:getPositionY() > winSize.height+border then
		return false
	end	
	return true
end

-- function GameFish:JudgeOutOfBoundary()	
-- 	if not self:isInside() then
-- 		if self.first_game then
--     		-- local event = cc.EventCustom:new("delete_fish")
--     		-- event._usedata = self
--     		-- eventDispatcher:dispatchEvent(event)
--     		self:DeleteFish()
--     	end	
--     else	
--     	self.first_game = true
-- 	end	
-- end
function GameFish:DeleteFish()
	local event = cc.EventCustom:new(GameData.DELETE_FISH)
	event._usedata = self
	eventDispatcher:dispatchEvent(event) 
end

function GameFish:bossVal( val )
	if self.boss_val == nil then
		self.boss_val = cc.LabelAtlas:_create("0",create_uipath("Player/FLYSCORE.png"),14,20,string.byte('0')):addTo(self._target)
    	self.boss_val:setPosition(self._target:getContentSize().width/2,self._target:getContentSize().height/2):setScale(2.0)
	end	
	self.boss_val:setString(val)
end

function GameFish:resumeMove()
	if self._move_type == LINE_MOVE then
		-- local x,y = self._target:getPosition()
		-- local dis = math.sqrt( math.pow((x-self.line_end_p.x),2) + math.pow((y-self.line_end_p.y),2) )
		-- local speed = 80
		-- local m_act = cc.MoveTo:create(dis / speed,cc.p(self.line_end_p.x,self.line_end_p.y))
		-- self._target:runAction(m_act)
	elseif self._move_type == CIRCLE_MOVE then	
		log("stop circle")
		local event = cc.EventCustom:new(GameData.OEVER_CIRCLE)
    	event._usedata = self
    	eventDispatcher:dispatchEvent(event)
	end	
end

function GameFish:resumeLineMove(stoppos)
	if self._move_type == LINE_MOVE then
		self.m_StopCurveIndex = stoppos
		self.fish_state = GameData.Fish_Move
		-- local x,y = self._target:getPosition()
		-- local dis = math.sqrt( math.pow((x-self.line_end_p.x),2) + math.pow((y-self.line_end_p.y),2) )
		-- local speed = 55
		-- local m_act = cc.MoveTo:create(dis / speed,cc.p(self.line_end_p.x,self.line_end_p.y))
		-- self._target:runAction(m_act)
	end
end

-- function GameFish:resumeCircleMove()
-- 	if self._move_type == CIRCLE_MOVE then
-- 		log("stop circle")
-- 		local event = cc.EventCustom:new("over_circle")
--     	event._usedata = self
--     	eventDispatcher:dispatchEvent(event)
--     	return true
--     end
--     return false
-- end

function GameFish:CurveFishMove()

	-- 每5帧移动一个点,用浮点数易产生误差
	self.m_CurveIndex = self.m_CurveIndex + 1

	if self.m_CurveIndex/5 >= self.m_nPosNum then
		self.fish_state = GameData.Fish_Die
		return
	end
	if self.m_CurveIndex % 5 == 0 then
		
		local posidx = self.m_CurveIndex/5 + 1
		local curPos = self.m_tagPosArr[posidx]
		local curRol = self.m_tagRolArr[posidx]

		if self:isVisible() == false then
			-- 初次显示，设置pos
			self._target:setPosition(cc.p(curPos.x, curPos.y))
			self._target:setRotation(math.deg(curRol))
			local sp = self:getChildByTag(1000)
			if sp then 
				sp:setPosition(cc.p(curPos.x, curPos.y))
			end

			self:setVisible(true)
		else
			local act_move = cc.MoveTo:create(1/50*5, cc.p(curPos.x, curPos.y))
			local act_rotate = cc.RotateTo:create(1/50*5, math.deg(curRol))
			self._target:runAction(cc.Spawn:create(act_move, act_rotate))
			-- self._target:runAction(cc.MoveTo:create(0.1, cc.p(curPos.x, curPos.y)))
			-- self._target:setRotation(math.deg(curRol))

			-- set prop or QQ position/angle
			local sp = self:getChildByTag(1000)
			if sp then 
				sp:runAction(cc.MoveTo:create(1/50*5, cc.p(curPos.x, curPos.y)))
		  		-- sp:setRotation(math.deg(curRol))

				-- sp:setPosition(cc.p(curPos.x, curPos.y))
		    	-- sp:setRotation(math.deg(curRol))
			end
		end
	end
end

--[[function GameFish:CurveFishMove()
	if self.fish_state == GameData.Fish_Stru or self.fish_state == GameData.Fish_Stop then
		self.cur_point = self.cur_point - 1
		return
	end	

	local point = self._path[self.cur_point]

	self.fish_state = GameData.Fish_Move

	local next_x = point[2]-self.offset.x  
	local next_y = self:changePos( point[1]-self.offset.y ) 
    self._target:runAction(cc.MoveTo:create(0.1,cc.p(next_x,next_y)))
    local rol = -(point[3] - 90)
    -- if G_bViewTurn then
    -- 	rol = - rol
    -- end

    if self._prop == NO_Prop then
    	if self._kind == FISH_QQ then
    		local sp = self:getChildByTag(1000) 
    		local next_y = self:changePos( point[1]-self.offset.y ) 
    		sp:runAction(cc.MoveTo:create(0.1,cc.p(point[2]-self.offset.x,next_y)))
    		sp:setRotation(rol)
    	else
    		self._target:setRotation(rol)	
    	end   			
    else
    	if self:getChildByTag(1000) then
    		local sp = self:getChildByTag(1000) 
    		local next_y = self:changePos( point[1]-self.offset.y ) 
    		sp:runAction(cc.MoveTo:create(0.1,cc.p(point[2]-self.offset.x,next_y)))
    		sp:setRotation(rol)
    	end	
    end	
end--]]

function GameFish:LineFishMove()
	self:setVisible(true)

	self.m_CurveIndex = self.m_CurveIndex + 1.2
	if self.m_CurveIndex >= self.m_nPosNum then
		self.fish_state = GameData.Fish_Die
		return 
	end

	if self.m_CurveIndex >= self.m_StopCurveIndex then
		self.fish_state = GameData.Fish_Stop
	else
		local posidx = math.floor(self.m_CurveIndex) + 1
		local curPos = self.m_tagPosArr[posidx]
		local curRol = self.m_tagRolArr[posidx]
		-- self._target:runAction(cc.MoveTo:create(0.1, cc.p(curPos.x, curPos.y)))
		self._target:setPosition(cc.p(curPos.x, curPos.y))
		self._target:setRotation(math.deg(curRol+self.m_fDifRol))
	end
end

-- function GameFish:LineFishMove(_start_pos, _end_pos, stoppos, line_count, update_tag)
	-- log("curpos", _start_pos.x, self._idpos.curpos)
	-- self.fish_state = GameData.Fish_Move
	-- local x = _start_pos.x
	-- local speed = 90
	-- local dis = math.sqrt( math.pow((x-_end_pos.x),2) + math.pow((self:changePos(_start_pos.y)-self:changePos(_end_pos.y)),2) )
	-- --	
	-- if self._idpos.curpos == stoppos then --中间过程进入
	-- 	local t_y = stoppos*(_end_pos.y - _start_pos.y) / (1000+360)
	-- 	if t_y < 0 then
	-- 		t_y = winSize.height + t_y
	-- 	end	
	-- 	self._target:setPosition(cc.p( x,self:changePos(t_y) ))
	-- else
	-- 	local m_offset = 0
	-- 	if update_tag == true then
	-- 		m_offset = 880
	-- 	end
	-- 	--大鱼坐标处理
	-- 	if self._kind > 14 and stoppos then
	-- 		if _start_pos.x < 0 then
	-- 			x = _start_pos.x + self._idpos.curpos - line_count * 100 + m_offset
	-- 		else
	-- 			x = _start_pos.x - self._idpos.curpos + line_count * 100 - m_offset
	-- 		end	
	-- 		speed = 102
	-- 	end
	-- 	self._target:setPosition(cc.p( x,self:changePos(_start_pos.y) ))	
	
	-- 	dis = math.sqrt( math.pow((x-_end_pos.x),2) + math.pow((self:changePos(_start_pos.y)-self:changePos(_end_pos.y)),2) )
		
	-- 	self.move_act = cc.MoveTo:create(dis / speed,cc.p(_end_pos.x,self:changePos(_end_pos.y)))
	-- 	self._target:runAction( self.move_act )
	-- end
	--	

-- 	if _start_pos.x < 0 then

-- 	elseif _start_pos.x > winSize.width then
-- 		self._target:setRotation(180)
-- 	elseif _start_pos.y < 0 then
-- 		self._target:setRotation(-90)
-- 	elseif _start_pos.y > winSize.height then
-- 		self._target:setRotation(90)
-- 	end	

-- 	--if G_bViewTurn and self._kind < 10 then
-- 	if self._kind < 10 then
-- 		self._target:setRotation(self._target:getRotation() + 180)
-- 	end	

-- 	self.stoppos = stoppos
-- 	self.line_start_p = {x = _start_pos.x,y = self:changePos(_start_pos.y)}
-- 	self.line_end_p = {x = _end_pos.x,y = self:changePos(_end_pos.y)}
-- 	self.line_dis = dis	
-- 	self.line_count = line_count
-- end

function GameFish:CircleFishMove()
	--self.fish_state = GameData.Fish_Move
	self:setVisible(true)

	self.m_CurveIndex = self.m_CurveIndex + 1.2
	local posidx = math.floor(self.m_CurveIndex) % self.m_nPosNum + 1
	local curPos = self.m_tagPosArr[posidx]
	local curRol = self.m_tagRolArr[posidx]
	-- self._target:runAction(cc.MoveTo:create(0.1, cc.p(curPos.x, curPos.y)))
	self._target:setPosition(cc.p(curPos.x, curPos.y))
	self._target:setRotation(math.deg(curRol+self.m_fDifRol))
	self.m_tagCurRol = curRol + self.m_fDifRol
	
	-- local now_index = self.count_point * point_num 
	
	-- if now_index > #self.m_tagPosArr then
	-- 	local more = math.floor(now_index / #self.m_tagPosArr)
	
	-- 	now_index = now_index - more * #self.m_tagPosArr

	-- 	if now_index == 0 then
	-- 		now_index = #self.m_tagPosArr
	-- 	end	
	-- end	
	
	-- local point = self.m_tagPosArr[self.m_CurveIndex+1]
	--self._target:setPosition(cc.p(point.x,point.y))
	-- self._target:runAction(cc.MoveTo:create(0.1,cc.p(point.x,point.y)))
	-- local _fAddRol = point_num * 6.28/self.m_nPosNum--nPosNum

	--self._target:setRotation(self.m_fAngle-_fAddRol ) 
	--self.m_fAngle = self.m_fAngle-_fAddRol
	--反向
	-- self.m_fAngle = (self.m_fAngle+math.deg(_fAddRol))%360
	-- self._target:setRotation(self.m_fAngle)
end

function GameFish:CreateCurveFish(_path)

	self:setVisible(false)

	self.m_CurveIndex = self._idpos.curpos
	self.m_nPosNum = table.getn(_path)

	-- calculate pos array
	for i,v in ipairs(_path) do
		local _tagPos = {}
		_tagPos.x = v[2] - self.offset.x
		_tagPos.y = display.height - (v[1]-self.offset.y)
		table.insert(self.m_tagPosArr, _tagPos)

		local _fRol = 90 - v[3]
		table.insert(self.m_tagRolArr, math.rad(_fRol))
	end

	-- show start pos and rol
	local posidx = self.m_CurveIndex + 1
	if posidx < 1 then
		posidx = 1
	end
	local curPos = self.m_tagPosArr[posidx]
	local curRol = self.m_tagRolArr[posidx]

	self._target:setPosition(cc.p(curPos.x, curPos.y))
	self._target:setRotation(math.deg(curRol))
end

function GameFish:CreateLineFish(start_pos, end_pos, stop_pos, nPosNum)
	self:setVisible(false)

	self.m_CurveIndex = self._idpos.curpos
	self.m_StopCurveIndex = stop_pos
	self.m_nPosNum = nPosNum
	self.m_fDifRol = 1.57

	-- calculate pos array
	start_pos = utils.getCocosPos(start_pos)	-- cocos2dx的原点在左下角
	end_pos = utils.getCocosPos(end_pos)		-- cocos2dx的原点在左下角
	local _tagDisPos = cc.pSub(end_pos, start_pos)
	local x = _tagDisPos.x/nPosNum
	local y = _tagDisPos.y/nPosNum
	
	for i=1,nPosNum do
		local _tagPos = cc.p(start_pos.x, start_pos.y)
		_tagPos.x = start_pos.x + x*(i-1)
		_tagPos.y = start_pos.y + y*(i-1)
		table.insert(self.m_tagPosArr, _tagPos)
	end

	-- calculate rol array
	for i=1,nPosNum do
		local _tagDir = {}
		if i == nPosNum then
			_tagDir = cc.pSub(self.m_tagPosArr[1], self.m_tagPosArr[i])
		else
			_tagDir = cc.pSub(self.m_tagPosArr[i+1], self.m_tagPosArr[i])
		end
		local _fRol = utils.GetRol(_tagDir)
		table.insert(self.m_tagRolArr, _fRol)
	end

	-- show start pos and rol
	local posidx = self.m_CurveIndex + 1
	if posidx < 1 then
		posidx = 1
	end
	local curPos = self.m_tagPosArr[posidx]
	local curRol = self.m_tagRolArr[posidx]

	self._target:setPosition(cc.p(curPos.x, curPos.y))
	self._target:setRotation(math.deg(curRol+self.m_fDifRol))
end

function GameFish:CreateCircle(_center_pos, fInitRol, _radius, nPosNum)
	self:setVisible(false)

	self.m_CurveIndex = self._idpos.curpos
	self.m_nPosNum = nPosNum
	self.m_fDifRol = 1.57

	-- calculate pos array
	local _fRol = fInitRol
	local _fAddRol = 6.28/nPosNum
	for i=1,nPosNum do
		local _tagPos = {}
		_fRol = _fRol + _fAddRol
		_tagPos.x = _center_pos.x+math.cos(_fRol)*_radius
		_tagPos.y = _center_pos.y-math.sin(_fRol)*_radius -- cocos2dx的原点在左下角
		table.insert(self.m_tagPosArr, _tagPos)

		table.insert(self.m_tagRolArr, _fRol)
	end

	-- calculate rol array
	-- for i=1,nPosNum do
	-- 	local _tagDir = {}
	-- 	if i == nPosNum then
	-- 		_tagDir = cc.pSub(self.m_tagPosArr[1], self.m_tagPosArr[i])
	-- 	else
	-- 		_tagDir = cc.pSub(self.m_tagPosArr[i+1], self.m_tagPosArr[i])
	-- 	end
	-- 	local _fRol = utils.GetRol(_tagDir)
	-- 	table.insert(self.m_tagRolArr, _fRol)
	-- end

	-- show start pos and rol
	local posidx = self.m_CurveIndex + 1
	if posidx < 1 then
		posidx = 1
	elseif posidx > nPosNum then
		posidx = posidx % nPosNum
	end
	local curPos = self.m_tagPosArr[posidx]
	local curRol = self.m_tagRolArr[posidx]

	self._target:setPosition(cc.p(curPos.x, curPos.y))
	self._target:setRotation(math.deg(curRol+self.m_fDifRol))
end
--[[function GameFish:CreateCircle(_start_pos, fInitRol, _radius,nPosNum,update_tag,dif_time)
	--_start_pos:640,384
	--_radius:365,320,270,220,1
	--log("init circle",self._id, self._kind, self._idpos.curpos, _circle)

	local _update = update_tag or false

	-- local _fRol= 0
	-- if _circle == 0 then 
	-- 	_fRol = 31.5
	-- 	self.m_fAngle = - 180-95
	-- elseif _circle == 45 then 
	-- 	_fRol = 37
	-- 	self.m_fAngle = 140
	-- elseif _circle == 90 then 
	-- 	_fRol = 30
	-- 	self.m_fAngle = -180
	-- elseif _circle == 135 then 
	-- 	_fRol = 35
	-- 	self.m_fAngle = -120
	-- elseif _circle == -135 then 
	-- 	_fRol = 34
	-- 	self.m_fAngle = -50
	-- elseif _circle == -90 then
	-- 	_fRol = 33
	-- 	self.m_fAngle = 0
	-- elseif _circle == -45 then 
	-- 	_fRol = 32
	-- 	self.m_fAngle = 62	
	-- end	

	--111
	-- local _fAddRol=6.28/nPosNum
	-- self._target:setPosition(cc.p(_start_pos.x ,_start_pos.y ))
	-- local pos_array = {}
	-- for i = 1 , nPosNum do
	-- 	local temp = {}
	-- 	_fRol = _fRol + _fAddRol
	-- 	temp.x = _start_pos.x + _radius*math.cos(_fRol)
	-- 	temp.y = _start_pos.y + _radius*math.sin(_fRol)
	-- 	table.insert(pos_array,temp)		
	-- end
	-- self.m_tagPosArr = pos_array
	--222放G_client
	-- for k,v in pairs(Layer_LuaClient.circle_path) do
	-- 	if v.rol == _fRol and v.radius == _radius then
	-- 		self.m_tagPosArr = v.array
	-- 		break
	-- 	end	
	-- end
	--333
	-- fInitRol = math.rad(-180)
	local _fRol = fInitRol
	local _fAddRol = 6.28/nPosNum
	self.m_tagPosArr = {}
	for i=1,nPosNum do
		local _tagPos = cc.p(0,0)
		_fRol = _fRol + _fAddRol
		_tagPos.x = _start_pos.x+math.cos(_fRol)*_radius
		_tagPos.y = _start_pos.y-math.sin(_fRol)*_radius -- cocos2dx的原点在左下角
		table.insert(self.m_tagPosArr, _tagPos)
		-- log(_radius, _tagPos.x, _tagPos.y)
	end
	-- for i=1,nPosNum do
	-- 	local _tagDir = {}
	-- 	if i == nPosNum then
	-- 		_tagDir.x = self.m_tagPosArr[1].x - self.m_tagPosArr[i].x
	-- 		_tagDir.y = self.m_tagPosArr[1].y - self.m_tagPosArr[i].y
	-- 	else
	-- 		_tagDir.x = self.m_tagPosArr[i+1].x - self.m_tagPosArr[i].x
	-- 		_tagDir.y = self.m_tagPosArr[i+1].y - self.m_tagPosArr[i].y
	-- 	end
	-- 	local _fRol = utils.GetRol(_tagDir)
	-- 	-- log("======>", _fRol)
	-- 	table.insert(self.m_pRadianArr, _fRol)
	-- 	-- _tagPos.fRol = _fRol
	-- 	--self.m_tagPosArr[i].fRol = _fRol
	-- end

    -- self.m_tagPosArr = utils.reverseTable(self.m_tagPosArr) 
	-- self.m_fAngle = math.deg(fInitRol)+90
	-- self.m_fAngle = math.deg(fInitRol)

	-- self.m_tagPosArr1 = Layer_LuaClient.circle_path[_fRol.._radius]

	-- if self._kind == 0 then
	-- 	log("add rol", self.m_fAngle, self.m_fAngle1)
	-- 	for i=1, 50 do
	-- 		log("1========>", self.m_tagPosArr[i].x, self.m_tagPosArr[i].y, self.m_tagPosArr1[i].x, self.m_tagPosArr1[i].y)
	-- 		-- log("2========>", self.m_tagPosArr1[i].x, self.m_tagPosArr1[i].y)
	-- 	end
	-- end

	--local _fRol= 30 + 2 --
	--self.m_fAngle = 0 + 72 
	--self.m_fAngle = - 180 + 62 + 180
	self.m_nPosNum = nPosNum
	self.m_CurveIndex = self._idpos.curpos
	-- self.count_point = self._idpos.curpos
	if self.m_CurveIndex >= nPosNum then
		self.m_CurveIndex = self.m_CurveIndex % nPosNum	
	elseif self.m_CurveIndex < 0 then
		self.m_CurveIndex = 0
	end

	local curPos = self.m_tagPosArr[self.m_CurveIndex+1]
	self.m_fAngle = math.deg(fInitRol + _fAddRol*self.m_CurveIndex)
	if self._kind <= 10 then
		self.m_fAngle = self.m_fAngle + 90
	else
		self.m_fAngle = self.m_fAngle + 45
	end

	--反向
	--self.m_tagPosArr = utils.reverseTable(self.m_tagPosArr)  --放G_client
	--反向
	self._target:setRotation(self.m_fAngle)
	self._target:setPosition(cc.p(curPos.x, curPos.y))
	-- self._target:setPosition(cc.p(self.m_tagPosArr[self.count_point].x, self.m_tagPosArr[self.count_point].y ))
	-- if _update then
	-- 	if self._idpos.curpos > 0 then
	-- 		self.count_point = self._idpos.curpos 
	-- 		local now_index = self.count_point * 6
	-- 		if now_index > #self.m_tagPosArr then
	-- 			local more = math.floor(now_index / #self.m_tagPosArr)
	
	-- 			now_index = now_index - more * #self.m_tagPosArr
	-- 		end	
	-- 		log("update",now_index)
	-- 		self._target:setPosition(cc.p(self.m_tagPosArr[now_index].x ,self.m_tagPosArr[now_index].y ))
	-- 		self.update_tag = true
	-- 	else
	-- 		self.count_point = 1	
	-- 	end
	-- end	
	-- if _update and dif_time then
	-- 	--log("dif_time",dif_time)
	-- 	self.count_point = math.floor(dif_time / 0.1 + 0.5)
	-- 	local _fDiffRol = self.count_point * (180 / math.pi) * 6 * 6.28/900
	-- 	self.m_fAngle = self.m_fAngle + _fDiffRol
	-- 	local now_index = self.count_point * 6
	-- 	if now_index > #self.m_tagPosArr then
	-- 		local more = math.floor(now_index / #self.m_tagPosArr)
	-- 		now_index = now_index - more * #self.m_tagPosArr
	-- 	end	
	-- 	self._target:setPosition(cc.p(self.m_tagPosArr[now_index].x ,self.m_tagPosArr[now_index].y ))
	-- end	
	
end--]]

function GameFish:isDie()
	return self.die_tag
end

function GameFish:struggle(score,val,viewid)
	self.die_tag = true
	local function act_end()
		if self.stru_sp then
			utils.cleanChildAndEffect(self.stru_sp)
		end	
		self.fish_state = GameData.Fish_Die
    	local event = cc.EventCustom:new(GameData.CATCH_FISH)
    	event._usedata = { self , score , val , viewid }
    	eventDispatcher:dispatchEvent(event)
	end
	-- self.no_move = false
	-- if self.fish_state == GameData.Fish_Stop then
	-- 	self.no_move = true
	-- end	
	-- self.fish_state = GameData.Fish_Stru
	-- if self._prop == NO_Prop then
	-- 	local name = "FISHDIE"..self._id
	-- 	local res = GameData.MYRES[name]

	-- 	self.stru_sp = utils.getAnimSprite(create_uipath("fish/die"..self._id..".png"),res,2,act_end):addTo(self)
	-- 		:setPosition(self._target:getPositionX(),self._target:getPositionY())
	-- 	self._target:pause()
	-- 	self._target:setVisible(false)
	-- 	local angle = self._target:getRotation()
	-- 	self.stru_sp:setRotation(angle)
	-- else
	-- 	self:isCatch()
	-- end	

	self.fish_state = GameData.Fish_Stru
	if self._prop == NO_Prop then
		local name = "FISHDIE"..self._kind
		local res = GameData.MYRES[name]
		if res then
			self.stru_sp = utils.plistAnimation("die",self._kind,1,act_end,0.1):addTo(self)
				:setPosition(self._target:getPositionX(),self._target:getPositionY())
			self._target:pause()
			self._target:setVisible(false)
			local angle = self._target:getRotation()
			self.stru_sp:setRotation(angle)
			--鱼尺寸处理
			-- if self._kind==FISH_DRAGON then
			-- 	self.stru_sp:setScale(1.5)
			-- end
			self:adjustScale(self.stru_sp,self._kind)		
		else
			if self._kind == FISH_ZONGYITANG then
				self._target:runAction(cc.Sequence:create(cc.ScaleTo:create(1.0,2.0),
					cc.CallFunc:create(function ()
						act_end()
					end)))
			elseif self._kind == FISH_QQ then	
				-- local sp = self:getChildByTag(1000)
				Layer_LuaClient.m_pGameLayer:QQFly(self._target,viewid,act_end)
				-- Game_Layer:qqFly(sp,viewid,act_end)
			else
				act_end()
			end			
		end		
	else
		--log("==============prop id",self._prop)
		act_end()
	end	
	-- if self.m_tMarkPlayer[MY_VIEWID] == true then
	-- 	log("change mark")
	-- 	local event = cc.EventCustom:new("change_mark")
 --    	eventDispatcher:dispatchEvent(event)
	-- end	
end

function GameFish:changeColor()
	self._target:runAction(cc.Sequence:create(
			cc.CallFunc:create(function ()
				self._target:setColor(cc.c3b(255,0,0))
			end),
			cc.DelayTime:create(0.1),
			cc.CallFunc:create(function ()
				self._target:setColor(cc.c3b(255,255,255))
			end)
		))	
end

function GameFish:addMark(viewid)
	self.m_tMarkPlayer[viewid] = true
	-- table.insert(self.m_tMarkPlayer, viewid)
end
function GameFish:subMark(viewid)
	if self.m_tMarkPlayer then
		self.m_tMarkPlayer[viewid] = nil
	end
	-- utils.removeValue(self.m_tMarkPlayer,viewid)
end
function GameFish:getMark(viewid)
	if self.m_tMarkPlayer[viewid] then
		return true
	end
	return false
end

function GameFish:clearFish()
	--log("clear fish",self._kind)
	-- local body = self._target:getPhysicsBody() --?????????Physics
	-- body:removeFromWorld()

	self._target = nil

	self._idpos = nil
	self._id = nil
	self._kind = nil
	self._prop = nil
	self.offset = nil
	self.die_tag = nil
	-- self.update_tag = nil
	-- self.count_point = nil
	self.m_CurveIndex = nil
	self._move_type = nil	
	self.fish_state = nil
	-- self.first_game = nil
	-- self.bMark = nil
	-- self.cur_point = nil

	-- self._path = nil
	self.m_tagPosArr = nil
	-- self.m_fAngle = nil

	-- self.move_act = nil
	-- self.line_start_p = nil
	-- self.line_end_p = nil
	-- self.stoppos = nil
	-- self.line_dis = nil	
	-- self.line_count = nil

	--utils.cleanAllChildAndEffect(self:getChildren())
	self:removeFromParent()
end

function GameFish:onExit()
	self.m_tMarkPlayer = nil
end

return GameFish