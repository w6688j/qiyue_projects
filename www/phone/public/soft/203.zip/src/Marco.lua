--游戏中使用系统头像
USE_SYSTEM_HEAD		=false

--在游戏房间中显示C++层用户信息框
SHOW_USERINFO_CPP	=true

_DEBUG_				=true

GAME_PLAYER			=6			--游戏人数