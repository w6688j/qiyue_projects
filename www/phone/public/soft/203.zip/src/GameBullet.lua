
-- local GameBullet = class("GameBullet", function (...)

-- 	o = {};

-- 	o.m_type = 0;

-- 	o.m_money = 0;
-- 	o.m_state = Bullet_Ready;
-- 	o.m_rol = 0;
	
-- 	o.m_pos = POS.new();
-- 	o.m_dir = POS.new();
	
-- 	o.m_mark = 0;
-- 	o.m_markpos = POS.new();

-- 	o.m_collidepos = {};
-- 	o.m_collidepos[1] = POS.new();
-- 	o.m_collidepos[2] = POS.new();
-- 	o.m_collidepos[3] = POS.new();
-- 	o.m_collidepos[4] = POS.new();
-- 	o.m_collidepos[5] = POS.new();

-- 	return o;
-- end)

local GameBullet = class("GameBullet", function (...)
	return display.newSprite()
end)

function GameBullet:init()
	self.m_type = 0;

	self.m_money = 0;
	self.m_state = Bullet_Ready;
	self.m_rol = 0;
	
	self.m_tagPos = POS.new();
	self.m_dir = cc.p(0,0)
	
	self.m_mark = false
	self.m_markpos = POS.new();

	self.m_tagCollidePosArr = {}
	self.m_last_pos = cc.p(-1,-1)

end

function GameBullet:ctor(money,nViewID,_type,tagPos,tagDir,rol,add_rol,idx)
	
	self:init()
	self.nViewID = nViewID

	if self.nViewID == MY_VIEWID then
		_type = _type;
	else
		_type = _type + 4
	end	
	self.m_type = _type

	self.m_money = money
	self.m_tagPos = tagPos
	-- self.m_dir = cc.p(tagDir.x, tagDir.y)
	self.m_idx = idx

   	if rol > 2*BULLET_MAX_ROL then    
		rol = -BULLET_MAX_ROL 	
	elseif rol > BULLET_MAX_ROL then
   		rol = BULLET_MAX_ROL 	   		
   	end	
   	if rol < -2*BULLET_MAX_ROL then
   		rol = BULLET_MAX_ROL
   	elseif rol < -BULLET_MAX_ROL then	
   		rol = -BULLET_MAX_ROL
   	end	

	self.m_rol = rol

	local name = "BULLET"..self.m_type
	local sp = utils.getAnimSprite(create_uipath("Player/bullet".._type..".png"),GameData.MYRES[name]):addTo(self)
	-- if add_rol == 180 then
	-- 	sp:setPosition(cc.p(tagPos.x - 90*math.sin(math.rad(self.m_rol)) - 6 ,tagPos.y - 80*math.cos(math.rad(self.m_rol))))
	-- else
	-- 	sp:setPosition(cc.p(tagPos.x + 80*math.sin(math.rad(self.m_rol)) +4 + 6,tagPos.y + 80*math.cos(math.rad(self.m_rol))))
	-- end	
	sp:setPosition(cc.p(tagPos))
	
	sp:setRotation(self.m_rol + add_rol)
	-- self:addHitBox(sp) --?????????Physics
	self.m_bullet = sp
	self:move(self.m_rol + add_rol)
	self.before_x = sp:getPositionX()
	self.before_y = sp:getPositionY()
end

function GameBullet:addHitBox(sp)
	--sp:getContentSize()
	local box = cc.PhysicsBody:createBox(cc.size(31,35))
	box:setDynamic(true)  --设置动态刚体
	box:setCategoryBitmask(1)    
	box:setContactTestBitmask(1)    
	box:setCollisionBitmask(2)  
	sp:setPhysicsBody(box)  
	sp:setTag(GameData.BULLET_TAG)
end

function GameBullet:move(move_rol)

	local distance = 2000

	local x = math.sin(math.rad(move_rol))
	local y = math.cos(math.rad(move_rol))
	self.m_dir = cc.p(x,y)

	--local act = cc.MoveTo:create(900/BULLET_SPEED,cc.p(x,y))--900
	local move_act = cc.MoveBy:create(900/BULLET_SPEED,cc.p(distance * math.sin(math.rad(move_rol)),distance * math.cos(math.rad(move_rol)) ))--900
	local act = cc.Sequence:create(
			move_act,
			cc.CallFunc:create(function ()
				-- local target = self:getParent().m_pGameCannon
				-- target:removeBullet(self)
			end)
		)
	act:setTag(100)
	self.m_bullet:runAction(act)
end

function GameBullet:changeDirection()
	--local is_border = 0
	local cur_x,cur_y = self.m_bullet:getPosition()

	local dif1 = cur_x - (display.width-self.m_bullet:getContentSize().width) 
	local dif2 = cur_y - (display.height-self.m_bullet:getContentSize().height)
	--log(dif1,dif2)
	local dif3 = self.m_bullet:getContentSize().width - cur_x
	local dif4 = self.m_bullet:getContentSize().height - cur_y
	--log(dif3,dif4)
	if dif1 > 0 and dif2 > 0 then --碰了两边(右上)
		if dif1 > dif2 then
			move_rol = -math.abs(self.m_rol)
		else
			move_rol = math.abs(self.m_rol) + 180
		end	
		--log("1,2")
	elseif dif3 > 0 and dif2 > 0 then --碰了两边(左上)
		if dif3 > dif2 then
			move_rol = math.abs(self.m_rol)
		else
			move_rol = 180-math.abs(self.m_rol)
		end	
		--log("3,2")
	elseif dif3 > 0 and dif4 > 0 then
		if dif3 > dif4 then
			move_rol = math.abs(self.m_rol)
		else
			move_rol = -math.abs(self.m_rol) 
		end
		--log("3,4")
	elseif dif1 > 0 and dif4 > 0 then
		if dif1 > dif4 then
			move_rol = math.abs(self.m_rol) - 180
		else
			move_rol = -math.abs(self.m_rol)
		end
		--log("1,4")
	elseif cur_x <= self.m_bullet:getContentSize().width then
		if self.before_y < cur_y then --<=
			move_rol = math.abs(self.m_rol)
		elseif self.before_y >= cur_y then
			move_rol = 180 - math.abs(self.m_rol)	
		end	
		
	elseif cur_x >= winSize.width-self.m_bullet:getContentSize().width then
		if self.before_y < cur_y then --<=		
			move_rol = -math.abs(self.m_rol)
		elseif self.before_y >= cur_y then
			move_rol = math.abs(self.m_rol) - 180	
		end	
	elseif cur_y <= self.m_bullet:getContentSize().height then
		if self.before_x < cur_x then --<=
			move_rol = math.abs(self.m_rol)
		elseif self.before_x >= cur_x then
			move_rol = -math.abs(self.m_rol) 	
		end	
		
	elseif cur_y >= winSize.height-self.m_bullet:getContentSize().height then
		if self.before_x < cur_x then --<=
			move_rol = 180-math.abs(self.m_rol)
		elseif self.before_x >= cur_x then
			move_rol = math.abs(self.m_rol) + 180	
		end	
	end	
	self.before_x = cur_x
	self.before_y = cur_y

	self.m_bullet:stopActionByTag(100)
	self.m_tagPos.x = cur_x
	self.m_tagPos.y = cur_y
	-- self.m_bullet:runAction(cc.RotateTo:create(0,move_rol))
	self.m_bullet:setRotation(move_rol)
	self:move(move_rol)

	-- local _fRol = nil
	-- if cur_x <= 100 then
	-- 	self.m_dir.x = -self.m_dir.x
	-- 	_fRol = utils.GetRol(self.m_dir)
	-- elseif cur_x >= display.width - 100 then
	-- 	self.m_dir.x = -self.m_dir.x
	-- 	_fRol = utils.GetRol(self.m_dir)
	-- elseif cur_y <= 0 then
	-- 	self.m_dir.y = -self.m_dir.y
	-- 	_fRol = utils.GetRol(self.m_dir)
	-- elseif cur_y >= display.height - 100 then
	-- 	self.m_dir.y = -self.m_dir.y
	-- 	_fRol = utils.GetRol(self.m_dir)
	-- end

	-- if _fRol ~= nil then
	-- 	print("1------------", self.m_dir.x, self.m_dir.y)
	-- 	-- print("2------------", math.deg(utils.GetRol(self.m_dir)))
	-- 	print("3------------", math.deg(_fRol))
	-- 	_fRol = -_fRol + math.pi/2
	-- 	print("4------------", math.deg(_fRol))

	-- 	self.m_bullet:stopActionByTag(100)
	-- 	self.m_tagPos.x = cur_x
	-- 	self.m_tagPos.y = cur_y
	-- 	-- self.m_bullet:runAction(cc.RotateTo:create(0,move_rol))
	-- 	self.m_bullet:setRotation(math.deg(_fRol))
	-- 	-- self:move(_fRol)
	-- 	return true
	-- end
	-- return false
end

function GameBullet:updateScheduler()
	local x,y = self.m_bullet:getPosition()
	if x <= 0 or x >= display.width or y <= 0 or y >= display.height then
		if self.m_last_pos.x ~= x or self.m_last_pos.y ~= y then
			self.m_last_pos = cc.p(x,y)
			self:changeDirection()
		end
	end
	self:SetCollidePos()
end

function GameBullet:SetCollidePos()
	local _rotate = self.m_bullet:getRotation()
	local x, y = self.m_bullet:getPosition()
	local _fWidth = self.m_bullet:getContentSize().width/2
	local _fDifx = math.cos(math.rad(_rotate))*_fWidth
	local _fDify = math.sin(math.rad(_rotate))*_fWidth
	
	self.m_tagCollidePosArr[1] = cc.p(x+_fDifx, y+_fDify)
	self.m_tagCollidePosArr[2] = cc.p(x, y)
	self.m_tagCollidePosArr[3] = cc.p(x-_fDifx, y-_fDify)
end

function GameBullet:judgeborder()
	if self.m_bullet then
		local cur_x,cur_y = self.m_bullet:getPosition()
		self.before_x = cur_x
		self.before_y = cur_y
	end		

	-- local is_border = 0
	-- local move_rol = 0
	-- if cur_x <= 0 then
	-- 	if self.before_y <= cur_y then
	-- 		move_rol = math.abs(self.m_rol)
	-- 		is_border = 1
	-- 	else
	-- 		move_rol = 180 - math.abs(self.m_rol)
	-- 		is_border = 1
	-- 	end	
		
	-- elseif cur_x >= WIN_WIDTH then
	-- 	if self.before_y <= cur_y then		
	-- 		move_rol = -math.abs(self.m_rol)
	-- 		is_border = 1
	-- 	else
	-- 		move_rol = math.abs(self.m_rol) - 180
	-- 		is_border = 1
	-- 	end	
	-- elseif cur_y <= 0 then--
	-- 	if self.before_x <= cur_x then
	-- 		move_rol = math.abs(self.m_rol)
	-- 		is_border = 1
	-- 	elseif self.before_x > cur_x then
	-- 		move_rol = -math.abs(self.m_rol) 
	-- 		is_border = 1
	-- 	end	
		
	-- elseif cur_y >= WIN_HEIGHT then
	-- 	if self.before_x <= cur_x then
	-- 		move_rol = 180-math.abs(self.m_rol)
	-- 		is_border = 1
	-- 	elseif self.before_x > cur_x then
	-- 		move_rol = math.abs(self.m_rol) + 180
	-- 		is_border = 1
	-- 	end	
	-- end	

	
	-- if is_border == 1 then
	-- 	scheduler:unscheduleScriptEntry(self.move_update) 
	-- 	self.m_bullet:stopActionByTag(MOVE_TAG)
	-- 	self.m_tagPos.x = cur_x
	-- 	self.m_tagPos.y = cur_y
	-- 	self.m_bullet:setRotation(move_rol)
	-- 	self:move(move_rol)
	-- end	
end

function GameBullet:changeLock( x,y )
	
end

function GameBullet:addFishNet()
	local net_sp = nil
	local function endFun()
		--utils.cleanChildAndEffect(net_sp)
		self:clearBullet()
	end
	net_sp = utils.plistAnimation("net",self.m_type,1,endFun,0.04):addTo(self)
		:setPosition(self.m_bullet:getPositionX(),self.m_bullet:getPositionY())	

	GAMESOUND.playEffect(Net_Sound_0)
	net_sp:setRotation(90)

	-- local body = self.m_bullet:getPhysicsBody() --?????????Physics
	-- body:removeFromWorld()

	utils.cleanChildAndEffect(self.m_bullet)
	-- self.m_bullet:removeFromParent()
	-- self.m_bullet = nil
end

function GameBullet:clearBullet()
	self.m_tagPos = nil
	self.m_dir = nil
	self.m_markpos = nil

	self.m_type = nil
	self.m_money = nil
	self.m_state = nil
	self.m_rol = nil
	self.m_mark = nil

	-- self.before_x = nil
	-- self.before_y = nil

	--utils.cleanAllChildAndEffect(self:getChildren())
	self:removeFromParent()
end
--无用
function GameBullet:setstate(stat)
	self.m_state = stat;
	if self.m_state == Bullet_Blast then
		--need stop
		local actionnet = cc.Animate:create(animationnet);
		local spritenet = display.newSprite()
			:addTo(self)
			:setPosition(cc.p(200,200))
		spritenet:runAction(cc.RepeatForever:create(cc.Sequence:create(actionnet)));
	end
end

function GameBullet:getstate()
	return self.m_state;
end
--无用
-- function GameBullet:setOtherLock( fishid )
-- 	self.lock_fishid = fishid
-- end

-- function GameBullet:getOtherLock()
-- 	return self.lock_fishid
-- end

-- function GameBullet:setmarkpos(pos)
-- 	self.m_markpos:setpos(pos);
-- end
--锁定标记1
function GameBullet:setMark(mark)
	self.m_mark = mark;
end

function GameBullet:getMark()
	return self.m_mark;
end

return GameBullet;
