---------------------------------------------------------------------------------
------------------------------- 游戏相关宏 ---------------------------------------
---------------------------------------------------------------------------------	
GAME_PLAYER				=6			--游戏人数
MY_VIEWID				=1
MAX_BULLET              =30
G_bViewTurn				=false 		-- 是否需要旋转坐标
USER_POS_TABLE			={}			-- 用户座位转换对应位置

winSize                 = cc.Director:getInstance():getWinSize()
eventDispatcher 		= cc.Director:getInstance():getEventDispatcher()
BULLET_MAX_ROL 			= 90
BULLET_SPEED			= 350
Line_Point 				= 1000
max_gold          		= {1,1,4,4,7,7,7,7,10,10,15,15,15,20,20,24,28,30,45,45,45}
-----game command
GAME_ENTER					=2100
GAME_SCENE					=2101

GAME_FISH					=2102

GAME_USERFIRE				=2103      --发射子弹

GAME_FISHSTOP				=2104	  	

GAME_FISHAIMOVE				=2105      --鱼阵停止后继续移动的通知

GAME_FISHMAPSTATE			=2106

GAME_USERCOLLIDE			=2110      --子弹碰撞

GAME_FISHDIE				=2111

GAME_ADDSCORE				=2112
GAME_BOSSVALCHG				=2113      --boss倍数改变
GAME_CARDISAPEAR			=2114

GAME_USERENERGY				=2115
GAME_ACTIVEENERGY			=2116--//c->s

GAME_ENERGYCOLLIDE			=2117

GAME_BOMB					=2118

GAME_STOP					=2119
--//GAME_BOXDROP			=(2120)

GAME_FISHLEAVE				=2130

GAME_TIPS					=2140
GAME_MONEYCHG				=2141

GAME_SHOWKU					=2142      --显示参数
GAME_MASTER					=2143
--//GAME_TASKTIP			=(2144)
GAME_LOCK					=2145
GAME_MONEYDROP				=2146      --打李逵掉落金币
------------------


NO_Prop       		= 0			--不是道具
Star_Prop			= 1			--大三元道具
Kind_Kill_Prop		= 2			--一网打尽道具
Topo_Bomb_Prop		= 3			--炸弹道具
Box_Prop			= 4			--宝箱道具

--map state
Map_Comon			=0
Map_Buffer			=1
Map_Move			=2
Map_Waite			=3
Map_FishList		=4

TIPSTIME            = 5000 --5's
g_tips              = {
	"",
	"当前游戏正在休渔期，请稍等片刻……",
	"系统将在 10 秒后进入特殊鱼阵……",
	"由于您在一分钟内未发射子弹系统将在  ==  秒后离开游戏",
	"系统正在进入特殊鱼阵，暂停发射炮弹！",
	"您的积分已超过当前房间的最大积分，请去更高级的房间进行体验！",
	"锁定功能需要vip",
}
TIPS_NONE           =1
TIPS_IDLE			=2
TIPS_STYLE10S		=3
TIPS_NOBULLET		=4
TIPS_READYSTYLE		=5
TIPS_MAXMONEY		=6
TIPS_VIP            =7

WHITE_SHARK 	    =15
GOLD_SHARK 		    =16
BIG_SHARK 			=17
FROG_KIND			=18
CROCODILE_KIND		=19
LI_KIND         	=20
STOPFISHID			=21
AREABOMBID			=22  --只炸20倍及以下的鱼(kind<13),以及range=400(半径)
FULLWINDOWBOMBID	=23  --全部

FISH_QQ				=24
FISH_ZONGYITANG		=25  --只炸20倍及以下的鱼(kind<13)
FISH_DRAGON	    	=26
FISH_LI1	    	=27


--FishMoveType
THOUGHT_MOVE		=0	--AI鱼移动
CURVE_MOVE			=1	--曲线鱼移动						
LINE_MOVE			=2	--直线鱼移动
PARALLEL_MOVE		=3	--并排鱼移动
CIRCLE_MOVE			=4	--圆形鱼移动
NOTYP_MOVE			=5	--无规则移动

cardseq        		={
	WHITE_SHARK,
	GOLD_SHARK,
	BIG_SHARK,
	FROG_KIND,
	LI_KIND,
	STOPFISHID,
	AREABOMBID,
	FULLWINDOWBOMBID,
	FISH_QQ,
	FISH_ZONGYITANG,
	FISH_DRAGON,
	FISH_LI1
}

fishshake        		={
	WHITE_SHARK,
	GOLD_SHARK,
	BIG_SHARK,
	FROG_KIND,
	LI_KIND,
	AREABOMBID,
	FULLWINDOWBOMBID,
	FISH_ZONGYITANG,
	FISH_DRAGON,
	FISH_LI1
}


Back_Sound_0	= "sound/Back0.mp3";
Back_Sound_1	= "sound/Back1.mp3";
Back_Sound_2	= "sound/Back2.mp3";
Back_Sound_3	= "sound/Back3.mp3";
Bom_Sound		= "sound/Bomb.mp3";
Add_Gold_Sound	= "sound/AddGold.mp3";
Add_YB_Sound	= "sound/AddYB.mp3";
Click_Sound		= "sound/Click.mp3";
Die_Sound_0		= "sound/Die0.mp3";
Die_Sound_1		= "sound/Die1.mp3";
Die_Sound_2		= "sound/Die2.mp3";
Die_Sound_3		= "sound/Die3.mp3";
Die_Sound_4		= "sound/Die4.mp3";
Gold_Show_Sound	= "sound/GoldShow.mp3";
Net_Sound_0		= "sound/Net0.mp3";
Shot_Sound_0	= "sound/Shot0.mp3";
Shot_Sound_1	= "sound/Shot1.mp3";
Shot_Sound_2	= "sound/Shot2.mp3";
Shot_Sound_3	= "sound/Shot3.mp3";
Wave_Enter_Sound= "sound/WaveEnter.mp3";
val30_Sound		= "sound/val30.mp3";
--toenergycannon_Sound= "sound/Shot3.mp3";
die_li_Sound	= "sound/die_li.mp3";
die_shark_Sound	= "sound/die_shark.mp3";
die30_Sound		= "sound/die30.mp3";
die15_Sound		= "sound/die15.mp3";
die18_Sound		= "sound/die18.mp3";
die20_Sound		= "sound/die20.mp3";
die25_Sound		= "sound/die25.mp3";

-- animate_path = "games/"..G_GameID.."/game"..G_GameID.."/res/ui"
-- src_path = "games/"..G_GameID.."/game"..G_GameID.."/src/path/"
animate_path = "games/"..G_GameID.."/res/ui"
src_path = "src/path/"
function create_pp_anim(_name)
    return "pp/res/animation/".._name  
end

function create_pp_res(_name)
    return "pp/res/lobby/".._name  
end


