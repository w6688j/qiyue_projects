
local LockCard= class("LockCard", function ( ... )
    return display.newLayer()   
end)

function LockCard:ctor()
    self:initCard()
end

function LockCard:initCard()
	local res = GameData.MYRES["lockcard"]
	local num =res[GameData.MYRES_FRAMES]
	local w = res[GameData.MYRES_WIDTH]
	local h = res[GameData.MYRES_HEIGHT]

	local per = per or 0.05

	local texture = cc.Director:getInstance():getTextureCache():addImage(create_uipath("Player/lockcard_li.png"))
	local frame_array = {}
	for i=1,num do
		local frame = cc.SpriteFrame:createWithTexture(texture,cc.rect(w*(i-1),0,w,h))
		table.insert(frame_array,frame)
	end
	self.frame_array = frame_array
end

function LockCard:show(fish,_player)
	local index = 0
	for i,v in ipairs(cardseq) do
		if v == fish._kind then
			index = i
			break
		end	
	end
	self._card = cc.Sprite:createWithSpriteFrame(self.frame_array[index])
	self._card:addTo(self)

	local startPos = cc.p(fish._target:getPositionX(), fish._target:getPositionY())
	
	if G_bViewTurn then
		startPos.x = display.width - startPos.x
		startPos.y = display.height - startPos.y
	end

	local pos = cc.p(130, 50)
	if GamePlayer.isTopUser(_player.nViewID) then
		pos = cc.pMul(pos, -1)
    end
    local targetPos = cc.pAdd(_player.m_tagPos, pos)

    self._card:setPosition(startPos.x, startPos.y)
    -- local t = math.sqrt( math.pow((startPos.x-targetPos.x),2) + math.pow((startPos.y-targetPos.y),2) ) / 800
    local t = cc.pGetDistance(startPos, targetPos) / 800
     
    self._card:runAction(cc.Sequence:create(
    		cc.MoveTo:create(t,targetPos),
    		cc.CallFunc:create(function ()
    			self:repeatAct()
    		end)
    	))
end

function LockCard:repeatAct()
	self._card:stopAllActions()
	local seq = cc.Sequence:create(
    	cc.MoveBy:create(0.2,cc.p(0,8)),
    	cc.DelayTime:create(0.1),
    	cc.MoveBy:create(0.2,cc.p(0,-8)),
    	cc.DelayTime:create(0.1)
    )
    self._card:runAction(cc.RepeatForever:create(seq)) 
end

function LockCard:clear()
	self.frame_array = nil
	self._card = nil
	--utils.cleanAllChildAndEffect(self:getChildren())
	self:removeFromParent()
end

return LockCard


