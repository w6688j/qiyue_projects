local PM = class("PM", function ( ... )
    return display.newLayer()   
end)

function PM:stopTime()
	local function addParticles()
		self.mParticles = cc.ParticleSystemQuad:create(create_uipath("particles/stoptime.plist")):addTo(self)
            :setAutoRemoveOnFinish(false) 
            :setScale(2.0)
	end
	local function stopParticles( ... )
		self.mParticles:pause()
	end
	local function removeParticles( ... )
		self.mParticles:resume()
        --utils.cleanChildAndEffect(self.mParticles)
        self:clear()
	end
    local add_particle = cc.CallFunc:create(addParticles)
    local delay = cc.DelayTime:create(0.7)
    local stop_article = cc.CallFunc:create(stopParticles)
    local delay1 = cc.DelayTime:create(0.5)
    local remove = cc.CallFunc:create(removeParticles)
        
    local sequence = cc.Sequence:create(add_particle, delay, stop_article, delay1, remove)
    self:runAction(sequence)
end

function PM:moreGold()
    -- self.mParticles = cc.ParticleSystemQuad:create(create_uipath("particles/particle5_yqs.plist")):addTo(self)

    cc.ParticleSystemQuad:create(create_uipath("particles/gold_bomb.plist")):addTo(self)
        :setAutoRemoveOnFinish(true) 
    cc.ParticleSystemQuad:create(create_uipath("particles/gold_bomb1.plist")):addTo(self)
        :setAutoRemoveOnFinish(true) 
    cc.ParticleSystemQuad:create(create_uipath("particles/gold_bomb2.plist")):addTo(self)
        :setAutoRemoveOnFinish(true) 
    local delay = cc.DelayTime:create(2.5)
    local sequence = cc.Sequence:create(delay, cc.CallFunc:create(function ()
        self:clear()
    end))
    self:runAction(sequence)    
end

function PM:clear()
    --utils.cleanAllChildAndEffect(self:getChildren())
    self.mParticles = nil
    self:removeFromParent()
end

return PM