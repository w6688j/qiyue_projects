local GamePos={}

GamePos.pt_head = {

  cc.p(350,100+40),

  cc.p(110,220+40),
  cc.p(110,410+40),
  cc.p(350,515+40),
  cc.p(780,515+40),

  cc.p(1030,410+40),
  cc.p(1030,220+40),
  cc.p(780,100+40)

}


GamePos.pt_D = {

  cc.p(440,215),

  cc.p(190,280),
  cc.p(190,410),
  cc.p(430,505),
  cc.p(705,505),

  cc.p(940,400),
  cc.p(940,280),
  cc.p(695,215)

}

GamePos.pt_CenterCard = {

  cc.p(display.center.x-(82+10)*2,display.center.y+20),
  cc.p(display.center.x-(82+10),display.center.y+20),
  cc.p(display.center.x,display.center.y+20),
  cc.p(display.center.x+(82+10),display.center.y+20),
  cc.p(display.center.x+(82+10)*2,display.center.y+20)

}

GamePos.pt_HandCard = {

	{cc.p(120,0),cc.p(150,0)},
	{cc.p(-60,-20),cc.p(-40,-20)},
	{cc.p(-60,-20),cc.p(-40,-20)},
	{cc.p(-60,-20),cc.p(-40,-20)},
	{cc.p(40,-20),cc.p(60,-20)},
	{cc.p(40,-20),cc.p(60,-20)},
	{cc.p(40,-20),cc.p(60,-20)},
	{cc.p(40,-20),cc.p(60,-20)}

}

GamePos.pt_ChipTable = {

  cc.p(350,255),

  cc.p(230,300),
  cc.p(230,380),
  cc.p(350,415),
  cc.p(780,415),

  cc.p(840,380),
  cc.p(840,300),
  cc.p(780,255)

}

GamePos.pt_ChipCenter = {

    cc.p(display.cx,display.cy+105),
    cc.p(display.cx-140,display.cy+105),
    cc.p(display.cx+140,display.cy+105),
    cc.p(display.cx+280,display.cy+105),

    cc.p(display.cx-140,display.cy+105-40),
    cc.p(display.cx,display.cy+105-40),
    cc.p(display.cx+140,display.cy+105-40),
    cc.p(display.cx+280,display.cy+105-40),

}

GamePos.pt_Center={x=560,y=500}



return GamePos

