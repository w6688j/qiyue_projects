
-- G_player = {}

-- -- 是否属于屏幕上方玩家
-- function GamePlayer.isTopUser(nViewID)
--     return nViewID <= 3
-- end

local GamePlayer = class("GamePlayer", function ( ... )
    return display.newNode()
end)

-- 是否属于屏幕上方玩家
function GamePlayer.isTopUser(nViewID)
    return nViewID <= 3
end
GamePlayer.ADDSCORE = 1

function GamePlayer:init()
	self.m_info 	= nil
	self.nViewID 	= 0
	self.card_sp 	= nil
	self.cardPos 	= cc.p(0,0)
	self.m_pGameCannon = nil
    self.m_pMarkFish   = nil

    self.floor_glods = {}
end

function GamePlayer:ctor(nViewID,info)
	self:init()

	self.nViewID = nViewID
	self.m_info = info
	--self.base_score = base_score

	local index = (self.nViewID-1) % 3
	self.m_tagPos = cc.p(index * (display.width/3) + display.width/6, 0)
	if GamePlayer.isTopUser(nViewID) then
		self.m_fRol = 180					-- 角度
		self.m_tagDir = cc.p(0,-1)		-- 方向(上下)
        self.m_tagDir1 = cc.p(1,0)		-- 方向(左右)
		self.m_tagPos.y = display.height - 30
	else
        self.m_fRol = 0
        self.m_tagDir = cc.p(0,1)
        self.m_tagDir1 = cc.p(-1,0)
		self.m_tagPos.y = 35 + 30
	end
	-- dump(self.m_tagPos)
	-- self:setPosition(self.m_tagPos)

	self:initUI()

    local function onNodeEvent(event)
        if event == "enter" then
            self:onEnter()
        elseif event == "exit" then
            self:onExit()
        end
    end
    self:registerScriptHandler(onNodeEvent)
end

function GamePlayer:initUI()
	-- 设置炮塔
    self.m_pGameCannon = GameCannon.new(self.m_tagPos,self.m_fRol,self.m_tagDir,self.m_tagDir1,self.nViewID, "TEST"):addTo(self)
    self.m_pGameCannon:setPosition(self.m_tagPos)

    -- 显示昵称
    if self.nViewID ~= MY_VIEWID then

    	local rotation = 0
    	local pos = cc.p(150, 0)
		if GamePlayer.isTopUser(self.nViewID) then
			rotation = 180
			pos = cc.pMul(pos, -1)
		end
		display.newSprite(create_uipath("cannon/namebg.png")):addTo(self)
			:setPosition(cc.pSub(self.m_tagPos, pos))
		local namelabel = utils.label( iconv.TCNTCP(self.m_info.user.name) ):addTo(self)
		    :setPosition(cc.pSub(self.m_tagPos, pos)):setRotation(rotation)
	end
end

function GamePlayer:onEnter()
	
end
function GamePlayer:onExit()
	
end

function GamePlayer:updateScheduler()
    for k, v in ipairs(self.m_pGameCannon.m_bulletvec) do
        v:updateScheduler()
    end
end

function GamePlayer:setUserInfo(info)
	self.m_info = info
end

function GamePlayer:checkNoMoney()
	if self.m_info.umoney.money - self.m_pGameCannon:getMoney() >= 0 then
		return false
	end
	return true
end

function GamePlayer:getMoney()
	return self.m_info.umoney.money
end
function GamePlayer:addMoney(add_money)
	if self.nViewID == MY_VIEWID then
		self.m_info.umoney.money = self.m_info.umoney.money + add_money
	end
end
function GamePlayer:subMoney()
	self.m_info.umoney.money = self.m_info.umoney.money - self.m_pGameCannon:getMoney()
end
function GamePlayer:updateMoney(nMoney)
	self.m_info.umoney.money = nMoney
end

-- 创建能量炮 分数翻倍
function GamePlayer:createCard(eneryPos)
	if self.card_sp then
		self.card_sp:setVisible(true)
		self.card_sp:stopAllActions()
	else	
		local card_sp = display.newSprite(create_uipath("Player/card.png")):addTo(self)
		if card_sp == nil then
			return
		end	

		local targetPos = cc.p(-130, 50)
		if GamePlayer.isTopUser(self.nViewID) then
			targetPos = cc.pMul(targetPos, -1)
			card_sp:setRotation(180)
    	end

    	self.cardPos = cc.pAdd(self.m_tagPos, targetPos)
    	self.card_sp = card_sp	
    end	

    -- start position 
	self.card_sp:setPosition(eneryPos.x,eneryPos.y)
	-- local t = math.sqrt( math.pow((eneryPos.x-self.cardPos.x),2) + math.pow((eneryPos.y-self.cardPos.y),2) ) / 800
	local t = cc.pGetDistance(eneryPos, self.cardPos) / 800
 
 	-- run fly action
	self.card_sp:runAction(cc.Sequence:create(
			cc.MoveTo:create(t,self.cardPos),
			cc.CallFunc:create(function ()
				self:repeatAct()
			end)
		))
end

function GamePlayer:repeatAct()
	self.card_sp:stopAllActions()
	local seq = cc.Sequence:create(
    	cc.MoveBy:create(0.2,cc.p(0,8)),
    	cc.DelayTime:create(0.1),
    	cc.MoveBy:create(0.2,cc.p(0,-8)),
    	cc.DelayTime:create(0.1)
    )
    self.card_sp:runAction(cc.RepeatForever:create(seq)) 
end

function GamePlayer:removeEnergy()
	if self.card_sp then
		self.card_sp:setVisible(false)
	end
	self.m_pGameCannon:resetCannon()
	-- self:setMoney(self.m_nMoney)
end

function GamePlayer:AddGameGold(fishPos,get_money,kind,prop)
	self:addMoney(get_money)

	local goldPos = cc.p(fishPos.x, fishPos.y)
    if G_bViewTurn then
        goldPos.x = display.width - goldPos.x
        goldPos.y = display.height - goldPos.y
    end

    -- show fly score number
    local add_money = cc.LabelAtlas:_create(get_money,create_uipath("Player/FLYSCORE.png"),14,20,string.byte('0'))
    add_money:setPosition(goldPos):setScale(2.0):addTo(self)
    local move_y = 100
    if GamePlayer.isTopUser(self.nViewID) then
        add_money:setRotation(180)
        move_y = -100
    end
    local act = cc.Sequence:create( cc.MoveBy:create(1,cc.p(0,move_y)),cc.RemoveSelf:create() )
    add_money:runAction(act)

    -- show fly gold
    local gold_num = 1
    local gold_width = 78
    if prop > 0 then
        gold_num = 5
    else
        if kind < 3 then
        elseif kind < 10 then
            gold_num = 2
        elseif kind < 14 then
            gold_num = 4
        elseif kind < 18 then
            gold_num = 6
        else
            gold_num = 8
        end            
    end 
    local g_speed = 400

    for i=1,gold_num do 
        local _tagPos_x = goldPos.x + (gold_num/2-i)*gold_width
        local res = GameData.MYRES["GOLD2"]
        local gold_sp = utils.getAnimSprite(create_uipath("Player/GOLD2.png"),res)
        gold_sp:setPosition(_tagPos_x,goldPos.y):addTo(self,-1)
        
        local dis = math.sqrt( math.pow((_tagPos_x-self.m_tagPos.x),2) + math.pow((goldPos.y-self.m_tagPos.y),2) )    
        gold_sp:runAction(cc.Sequence:create(
                cc.MoveTo:create(dis/g_speed,cc.p(self.m_tagPos.x,self.m_tagPos.y)),
                cc.RemoveSelf:create(),
                cc.CallFunc:create(function ()
                    if i == gold_num then
                        self:showFloorGold(get_money,kind) 
                    end      
                end)    
            ))
    end 
end

function GamePlayer:PropFly(sp,act_end)
    local x = sp:getPositionX()
    local y = sp:getPositionY()
    local move_y = self.m_tagPos.y-100    
    if GamePlayer.isTopUser(self.nViewID) then
        move_y = self.m_tagPos.y+100   
    end    
    local _speed = 400
    local dis = math.sqrt( math.pow((x-self.m_tagPos.x),2) + math.pow((y-move_y),2) )    
    sp:runAction(cc.Sequence:create(
            cc.MoveTo:create(dis/_speed,cc.p(self.m_tagPos.x,move_y)),
            cc.RemoveSelf:create(),
            cc.CallFunc:create(function ()
                act_end()      
            end)    
        ))
end

function GamePlayer:showFloorGold(get_money,f_kind)
    local index = #self.floor_glods
    local m_floorgold = GameFloorGold.new( f_kind ):addTo(self) 
    table.insert(self.floor_glods,m_floorgold)
    m_floorgold:initData( get_money,self.m_tagPos,self.m_fRol,index,self.nViewID )
    GAMESOUND.playEffect(Gold_Show_Sound)
    -- if self.nViewID == MY_VIEWID then
    --     m_floorgold:setPosition(40,0)
    -- end    
end

function GamePlayer:removeFloorGold(floor_glod)
    utils.removeValue(self.floor_glods,floor_glod)
	for k,v in pairs(self.floor_glods) do
	    v.move_state = 1
	end
end

function GamePlayer:removeEnergyCannon()
	if self.card_sp then
		self.card_sp:setVisible(false)
	end
	self.m_pGameCannon:resetCannon()
end

function GamePlayer:removePlayer()
    -- for i,v in ipairs(self.floor_glods) do
    --     v:onExit()
    -- end 

	self:removeFromParent()
end

return GamePlayer


