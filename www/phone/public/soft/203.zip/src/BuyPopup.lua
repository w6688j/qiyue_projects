

local BuyPopup= class("BuyPopup", function ( ... )
    return display.newLayer()   
end)

function BuyPopup:ctor()
	cc.LayerColor:create(cc.c4b( 0,0,0,160))
        :addTo(self)
    local m_listener = cc.EventListenerTouchOneByOne:create()
    local function onTouchBegan(touch,event)
        local s = self.bg:getBoundingBox()
        local rect = cc.rect(s.x,s.y,s.width,s.height)

        if not cc.rectContainsPoint(rect,touch:getLocation()) then
            self:closeFun()
        end           
        return true
    end
    m_listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    local eventDispather = self:getEventDispatcher()
    eventDispather:addEventListenerWithSceneGraphPriority(m_listener,self)
    m_listener:setSwallowTouches(true) 
    self.m_listener = m_listener    

	local bg = display.newSprite(create_uipath("popup/bg.png")):addTo(self)
    	:setPosition(display.cx,display.cy)
    utils.button(create_uipath("ui/btn_close.png"),create_uipath("ui/btn_close.png"),nil,handler(self,self.closeFun))
    	:addTo(bg)
    	:setPosition(bg:getContentSize().width-30,bg:getContentSize().height-36)
    self.bg = bg
    bg:setScale(1.2)
    local act = cc.EaseElasticOut:create(cc.ScaleTo:create(0.3, 1.0), 0.5)
    bg:runAction(act) 
    self.bg = bg
    
    self:initUI()
end

function BuyPopup:initUI()
	utils.label("VIP等级不足",30):addTo(self.bg)
		:setPosition(self.bg:getContentSize().width/2,self.bg:getContentSize().height-36)
	--优化
	utils.richlabel("您当前vip等级为<{255, 252, 0}VIP0>,锁定功能需要达到<{255, 252, 0}VIP1>以上",28):addTo(self.bg)
		:setPosition(self.bg:getContentSize().width/2,self.bg:getContentSize().height-130)

	-- local richlabel = ccui.RichText:create():addTo(self.bg)
	-- richlabel:setPosition(self.bg:getContentSize().width/2,self.bg:getContentSize().height-130)
	-- local element = ccui.RichElementText:create(0, cc.c3b(255,255,255), 255, "您当前vip等级为", "arial", 28)
	-- richlabel:pushBackElement(element)
	-- local element = ccui.RichElementText:create(0, cc.c3b(255,252,0), 255, "VIP0", "arial", 28)
	-- richlabel:pushBackElement(element)
	-- local element = ccui.RichElementText:create(0, cc.c3b(255,255,255), 255, ",锁定功能需要达到", "arial", 28)
	-- richlabel:pushBackElement(element)
	-- local element = ccui.RichElementText:create(0, cc.c3b(255,252,0), 255, "VIP1", "arial", 28)
	-- richlabel:pushBackElement(element)
	-- local element = ccui.RichElementText:create(0, cc.c3b(255,255,255), 255, "以上", "arial", 28)
	-- richlabel:pushBackElement(element)
	
	local contentbg = display.newSprite(create_uipath("popup/content.png")):addTo(self.bg)
		:setPosition(self.bg:getContentSize().width/2,self.bg:getContentSize().height/2-20)	

	local vip_sp = cc.CSLoader:createNode("vip1.csb")--(create_pp_anim("vip1.csb"))
        :addTo(contentbg)
        :setPosition(225,270)
    local act = cc.CSLoader:createTimeline("vip1.csb")--(create_pp_anim("vip1.csb"))
    act:gotoFrameAndPlay(0,true)
    vip_sp:runAction(act)
        
	local str1 = {"商品:","赠送:","价格:"}
	local str2 = {"30万金币","20元"}
	for i=1,3 do
		utils.label(str1[i],32,cc.c3b(65, 74, 86)):addTo(contentbg)
			:setPosition(400,400-80*i)
		if i == 1 then
			display.newSprite(create_uipath("vip/icon_VIP.png")):addTo(contentbg)
				:setPosition(510,400-80*i)	
			cc.LabelAtlas:_create("1",create_pp_res("info_num.png"),20,32,string.byte('+')):addTo(contentbg)	
    			:setPosition(540,400-80*i - 19):setScale(1.1)
    		utils.label("(1个月)",32,cc.c3b(65, 74, 86)):addTo(contentbg)
				:setPosition(620,400-80*i)	
		else
			utils.label(str2[i-1],32,cc.c3b(65, 74, 86)):addTo(contentbg)
				:setPosition(475,400-80*i)
				:setAnchorPoint(cc.p(0,0.5))	
		end	
	end	

	utils.button(create_uipath("popup/btn_buy.png"),create_uipath("popup/btn_buy.png"),nil,handler(self,self.buyFun))
    	:addTo(self.bg)
    	:setPosition(self.bg:getContentSize().width/2,130)
  --   utils.label("(温馨提示:每日充值限额500，每日限冲6次，每月充值限额2000元，合理游戏，健康生活)",22):addTo(self.bg)
		-- :setPosition(self.bg:getContentSize().width/2,50)	
end

function BuyPopup:buyFun()
	OpenUICharge(2)
end

function BuyPopup:closeFun()
	utils.setTimeout(0,function ()
        self.m_listener:setSwallowTouches(false) 
        eventDispatcher:removeEventListener(self.m_listener)
        self:removeFromParent()
    end)	
end

return BuyPopup


