

local GameHelp= class("GameHelp", function ( ... )
    return display.newLayer()   
end)

local ALL_FISH = 31
local help_des = {
	"2倍",
	"2倍",
	"3倍",
	"4倍",
	"5倍",
	"6倍",
	"7倍",
	"8倍",
	"9倍",
	"10倍",
	"12倍",
	"15倍",
	"18倍",
	"20倍",
	"25倍",
	"30倍",
	"35倍",
	"100倍",
	"150倍",
	"200倍",
	"400倍",
	"60-300倍",
	"60-300倍",
	"60-300倍",
	"12-30倍",
	"16-40倍",
	"定屏炸弹",
	"同类炸弹",
	"    局部炸弹\n限20倍以下鱼",
	"    全屏炸弹\n限20倍以下鱼",
	"全屏炸弹",
}

function GameHelp:ctor()
	cc.LayerColor:create(cc.c4b( 0,0,0,160))
        :addTo(self)
    local m_listener = cc.EventListenerTouchOneByOne:create()
    local function onTouchBegan(touch,event)
        local s = self.bg:getBoundingBox()
        local rect = cc.rect(s.x,s.y,s.width,s.height)

        if not cc.rectContainsPoint(rect,touch:getLocation()) then
            self:closeFun()
        end           
        return true
    end
    m_listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN)
    local eventDispather = self:getEventDispatcher()
    eventDispather:addEventListenerWithSceneGraphPriority(m_listener,self)
    m_listener:setSwallowTouches(true) 
    self.m_listener = m_listener 
        
    local bg = display.newSprite(create_uipath("help/helpbg.png")):addTo(self)
    	:setPosition(display.cx,display.cy)
    utils.button(create_uipath("ui/btn_close.png"),create_uipath("ui/btn_close.png"),nil,handler(self,self.closeFun))
    	:addTo(bg)
    	:setPosition(bg:getContentSize().width-10,bg:getContentSize().height-36)
    self.bg = bg
    bg:setScale(1.2)
    local act = cc.EaseElasticOut:create(cc.ScaleTo:create(0.3, 1.0), 0.5)
    bg:runAction(act) 
    self.bg = bg
    display.newSprite(create_uipath("help/tipword.png")):addTo(bg)
    	:setPosition(bg:getContentSize().width/2,48)			

    self:initScroll()
end

function GameHelp:initScroll()
	local size_w = 1020
	local size_h = 500
	local content_height = 1000
	self.scrollView = cc.ScrollView:create(cc.size(size_w,size_h)) 
    self.scrollView:setPosition(cc.p(0,70))
    self.scrollView:setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL) 	 
    self.scrollView:setContentSize( cc.size(size_w,content_height) )   
    self.scrollView:addTo(self.bg)
    self.scrollView:setBounceable(true)
    self.scrollView:setDelegate()
    self.scrollView:setContentOffset(cc.p(0,size_h-content_height),false)	

	self:setData()
end

function GameHelp:setData()
	local h = math.ceil( ALL_FISH / 7 )
	for j=1,h do
		for i=1,7 do
			self:createItem(i,j)
		end		
	end
end

function GameHelp:createItem( i , j )
	local index = 7*(j-1)+i
	if index > ALL_FISH then
		return
	end	
	local item =display.newSprite(create_uipath("help/itembg.png")):addTo(self.scrollView)
		:setPosition(132*i-14,1088-168*j)
	display.newSprite(create_uipath("help/fish"..index..".png")):addTo(item)
		:setPosition(item:getContentSize().width/2,item:getContentSize().height/2+25)
	local text_size = 27	
	if index == 29 or index == 30 then
		text_size = 18
	end	
	local text = utils.label(help_des[index],text_size,cc.c3b(214, 230, 246)):addTo(item)	
		:setPosition(item:getContentSize().width/2,item:getContentSize().height/2-50)

	-- local text = cc.LabelTTF:create(help_des[index],"Arial",text_size):addTo(item)
	-- 	:setPosition(item:getContentSize().width/2,item:getContentSize().height/2-40) 
	-- text:enableOutline(cc.c4b(0,0,0,255),2)
end

function GameHelp:closeFun()
	utils.setTimeout(0,function ()
        self.m_listener:setSwallowTouches(false) 
        eventDispatcher:removeEventListener(self.m_listener)
        self:removeFromParent()
    end)
	
end

return GameHelp


