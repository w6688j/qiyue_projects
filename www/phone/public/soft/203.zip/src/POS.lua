
local POS=class("POS", function (...)
	o={x=0,y=0}
	return o
end)

function POS:ctor( x, y )
	if nil == x then
		self.x=0
		self.y=0
	elseif nil == y then
		self.x=x.x
		self.y=x.y
	else
		self.x=x
		self.y=y
	end
end

function POS:set( x, y )
	self.x=x
	self.y=y
end

function POS:setpos( p )
	self.x=p.x
	self.y=p.y
end

function POS:add( p )
	self.x=self.x+p.x
	self.y=self.y+p.y
end

function POS:sub( p )
	self.x=self.x-p.x
	self.y=self.y-p.y
end

function POS:mul( u )
	self.x=self.x*u
	self.y=self.y*u
end

function POS:mulpos( p )
	self.x=self.x*p.x
	self.y=self.y*p.y
end

return POS