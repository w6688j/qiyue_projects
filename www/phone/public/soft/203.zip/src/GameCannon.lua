
local MIN_TRUN_ROL		= 0.1;
local MAX_ROL			= 1.57;

local Cannon = {CANNON_0 = 0, CANNON_1 = 1, CANNON_2 = 2, CANNON_3 = 3}


local GameCannon = class("GameCannon", function( ... )
	return display.newSprite()
end)

function GameCannon:ctor(tagPos,playerRol,tagDir,tagDir1,nViewID,other_name)
	-- initialize
	self.m_firetime = 0
	self.m_nMoney = 0
	self.m_cannon = 0
    self.rotate = 0
    self.m_fRol = 0
	self._lockFishid = nil
    self.cur_cannon = nil
	self.m_tagDir = POS.new()
	self.m_tagDir1 = POS.new()
	self.m_bulletvec = {}

	-- self:initData()

	self.m_tagPos = tagPos
	self.m_fPlayerAngle = playerRol
	self.m_tagDir = tagDir
	self.m_tagDir1 = tagDir1
	-- self.base_score = base_score
	self.nViewID = nViewID

	self._reverse = 1
	if GamePlayer.isTopUser(self.nViewID) then
		self.reverse = -1
	end	

	-- init ui
    self:initUI()
	-- self._reverse = _reverse

	-- local dir = POS.new();
	-- dir:setpos(self.m_tagDir);

	-- self.m_fireboardpos:setpos(self.m_tagPos);
	-- dir:mul(2)
	-- self.m_fireboardpos:sub(dir);

    -- local rotate = cc.RotateBy:create(0,math.deg(self.m_fPlayerAngle))
    -- self.m_fireboard:setPosition(self.m_fireboardpos.x, self.m_fireboardpos.y)
    -- self.m_fireboard:runAction(rotate)

	-- dir:setpos(self.m_tagDir);
	-- local dir1 = POS.new();
	-- dir1:setpos(self.m_tagDir1);

	-- self.m_fireseatpos:setpos(self.m_tagPos);
	--dir:mul(28)
	-- dir:mul(12)
	-- self.m_fireseatpos:sub(dir);
	-- dir1:mul(1)
	-- self.m_fireseatpos:add(dir1);

	-- self.m_fireseat:setPosition(self.m_fireseatpos.x, self.m_fireseatpos.y - 30*self._reverse)
	-- 	:runAction(rotate)
	--self.m_fireseat:setVisible(true)
end

-- function GameCannon:initData()
	-- self.m_fPlayerAngle = 0;
	-- self.m_firetime = 0;
	-- self.m_nMoney = 0;
	-- self.base_score = 0
	-- self.m_state = Cannon_Ready;

	-- self.m_fRol = 0;
	-- self.m_tagDir = POS.new();
	-- self.m_tagDir1 = POS.new();

	-- self.m_cannonpos = POS.new();
	
	-- self.m_fireboardpos = POS.new();
	-- self.m_fireseatpos = POS.new();

	-- self.m_tagMarPpos = POS.new();
	-- self.m_mark = 0;

	-- self.m_bulletvec = {};

	
    -- self.cur_cannon = nil
    -- self.rotate = 0
    -- self.energy_card = false
-- end

function GameCannon:initUI()
	self.m_fireboard = display.newSprite(create_uipath("cannon/fireboard.png"))
		:setAnchorPoint(display.CENTER_BOTTOM):setPosition(cc.p(0,-30*self.m_tagDir.y)):addTo(self)

    self.m_cannonspr = display.newSprite(create_uipath("cannon/cannon.png"))
        :setAnchorPoint(0.5,0.26):addTo(self)
        -- :setVisible(false)
        
	self.m_cannonspr1 = display.newSprite(create_uipath("cannon/cannon1.png"))
        :setAnchorPoint(0.5,0.24):addTo(self)
        :setVisible(false)
        
	self.m_cannonspr2 = display.newSprite(create_uipath("cannon/cannon2.png"))
        :setAnchorPoint(0.5,0.35):addTo(self)
        :setVisible(false)
        
    self.m_cannonspr3 = display.newSprite(create_uipath("Player/cardcannon.png"))
        :setAnchorPoint(0.5,0.2):addTo(self)
        :setVisible(false)
        
    self.cur_cannon = self.m_cannonspr

    -- self.m_fireseat = display.newSprite(create_uipath("cannon/firescore.png"))--display.newSprite(create_uipath("Player/fireseat.png"))
    --     :addTo(self,2)
    --     :setRotation(180)
    --     :setVisible(false)


	local base_label = cc.LabelAtlas:_create("0",create_uipath("Player/FLYSCORE.png"),14,20,string.byte('0')):addTo(self)  
	base_label:setAnchorPoint(cc.p(0.5,0.5))
    -- base_label:setPosition(0, 33*self._reverse)  
    self.base_label = base_label    

 	if self.nViewID == MY_VIEWID then

 		self:addOwnTip()

		self.score_btn1 = utils.button(create_uipath("cannon/up_score.png"),create_uipath("cannon/up_score.png"),nil,handler(self,self.onClickAddScore))
		self.score_btn1:setPosition(80*self._reverse, -5*self._reverse):setTag(1):addTo(self)
	    self.score_btn2 = utils.button(create_uipath("cannon/down_score.png"),create_uipath("cannon/down_score.png"),nil,handler(self,self.onClickAddScore))
	    self.score_btn2:setPosition(-70*self._reverse, -5*self._reverse):setTag(2):addTo(self)
	end

 --    if self.nViewID ~= MY_VIEWID then
 --    	display.newSprite(create_uipath("cannon/namebg.png")):addTo(self)
 --    		:setPosition(- 155*self._reverse,-40*self._reverse)
 --    	local namelabel = utils.label( iconv.TCNTCP(other_name) ):addTo(self)
 --    	    :setPosition(- 155*self._reverse,-40*self._reverse)  
    	
 --    	if GamePlayer.isTopUser(self.nViewID) then
 --    		namelabel:setRotation(180)
 --    	end
 --    	self.score_btn1:setVisible(false)
	-- 	self.score_btn2:setVisible(false)  
	-- else
	-- 	self:addOwnTip()
 --    end
    
    if GamePlayer.isTopUser(self.nViewID) then
		self.m_fireboard:setRotation(180)
		-- self.m_fireseat:setRotation(180)
		self.m_cannonspr:setRotation(180)
		self.m_cannonspr1:setRotation(180)
		self.m_cannonspr2:setRotation(180)
		self.base_label:setRotation(180)
		-- self.score_btn1:setRotation(180)
		-- self.score_btn2:setRotation(180)
	end
end

function GameCannon:addOwnTip()
	local m_tagPos = self.m_tagPos
	-- local m_fRol = self.m_fPlayerAngle
	
	self.tip_sp1 = display.newSprite(create_uipath("ui/own_tip.png")):addTo(self):setScale(0.75)
		:setPosition(0, 60)
	self.tip_sp2 = display.newSprite(create_uipath("ui/own_tip_word.png")):addTo(self)
		:setPosition(0, 180)
	-- if m_fRol == 0 then
	-- 	self.tip_sp1:setRotation(180)
	-- 	self.tip_sp2:setRotation(180)
	-- 	self.tip_sp1:setPosition(0,m_tagPos.y-20)
	-- 	self.tip_sp2:setPosition(0,m_tagPos.y-120)
	-- end		
	local seq1 = cc.Sequence:create(cc.ScaleTo:create(0.2,0.8*0.75),cc.ScaleTo:create(0.4,1.2*0.75),cc.ScaleTo:create(0.2,1*0.75))
	local act1 = cc.RepeatForever:create(seq1)
	self.tip_sp1:runAction(act1)	

	local seq2 = cc.Sequence:create(cc.MoveBy:create(0.2,cc.p(0,-10*self._reverse)),cc.MoveBy:create(0.4,cc.p(0,20*self._reverse))
			,cc.MoveBy:create(0.2,cc.p(0,-10*self._reverse)))
	local act2 = cc.RepeatForever:create(seq2)
	self.tip_sp2:runAction(act2)
end

function GameCannon:removeOwnTip()
	if self.tip_sp1 then
		utils.cleanChildAndEffect(self.tip_sp1)
		utils.cleanChildAndEffect(self.tip_sp2)
		self.tip_sp1 = nil
		self.tip_sp2 = nil
	end	
end

function GameCannon:onClickAddScore( sender )
	local tag = sender:getTag()
	local score = 0
    if tag == 1 then
        --log("加炮")
        score = GamePlayer.ADDSCORE

        --Layer_LuaClient:sendAddScore(self.base_score)
    elseif tag == 2 then
        --log("减炮")
        score = -GamePlayer.ADDSCORE
        if self.m_nMoney <= Layer_LuaClient.m_basescore then
        	return
        end
        --Layer_LuaClient:sendAddScore(-self.base_score)
    end
    local event = cc.EventCustom:new(GameData.CHANGE_CANNON)
    event._usedata = score
    eventDispatcher:dispatchEvent(event) 
end

function GameCannon:fire(fRol, idx)
    self:setCannonRotate(math.deg(fRol))

    self:addbullet(idx)
end

-- function GameCannon:setstate(stat)
-- 	self.m_state = stat;
-- end

-- function GameCannon:getstate()
-- 	return self.m_state;
-- end

-- function GameCannon:setrol(rol)
-- 	self.m_fRol = rol;
-- 	if self.m_fRol < -MAX_ROL then
-- 		self.m_fRol = -MAX_ROL;
-- 	elseif self.m_fRol > MAX_ROL then
-- 		self.m_fRol = MAX_ROL;
-- 	end
-- end

-- function GameCannon:turnrol(rol)
-- 	self.m_fRol = self.m_fRol + rol;
-- 	if self.m_fRol < -MAX_ROL then
-- 		self.m_fRol = -MAX_ROL;
-- 	elseif self.m_fRol > MAX_ROL then
-- 		self.m_fRol = MAX_ROL;
-- 	end
-- end

-- function GameCannon:getrol()
-- 	return self.m_fRol;
-- end

-- function GameCannon:setcannonpos()
	-- self.m_cannonpos:set(self.m_tagPos.x, self.m_tagPos.y - 20 * self._reverse);
	-- self.m_cannonpos:setpos(self.m_tagPos)

	-- local _pos = POS.new();
	-- _pos:setpos(self.m_tagDir);
	-- _pos:mul(-25+5 +30)
	-- self.m_cannonpos:sub(_pos);
	-- _pos:setpos(self.m_tagDir1);
	-- if self.m_nMoney >= GameData.CANNON_MONEY_2 * self.base_score then
	-- 	-- _pos:mul(9-7)
	-- 	-- self.m_cannonpos:add(_pos);
	-- 	-- self.m_cannonspr2:setPosition(cc.p(self.m_cannonpos.x+7*self._reverse,self.m_cannonpos.y));   
	-- 	self.cur_cannon = self.m_cannonspr2
	-- elseif self.m_nMoney >= GameData.CANNON_MONEY_1 * self.base_score then
	-- 	-- _pos:mul(8-6)
	-- 	-- self.m_cannonpos:add(_pos);
	-- 	-- self.m_cannonspr1:setPosition(cc.p(self.m_cannonpos.x+5*self._reverse,self.m_cannonpos.y));
	-- 	self.cur_cannon = self.m_cannonspr1
	-- else
	-- 	--_pos:mul(6)
	-- 	-- _pos:mul(2)
	-- 	-- self.m_cannonpos:add(_pos);
	-- 	-- self.m_cannonspr:setPosition(cc.p(self.m_cannonpos.x+4*self._reverse,self.m_cannonpos.y));
	-- 	self.cur_cannon = self.m_cannonspr
	-- end
	-- --energy card
	-- if self.energy_card then
	-- 	-- _pos:mul(2)
	-- 	-- self.m_cannonpos:add(_pos);
	-- 	-- self.m_cannonspr3:setPosition(cc.p(self.m_cannonpos.x+11*self._reverse,self.m_cannonpos.y));
	-- 	self.cur_cannon = self.m_cannonspr3
	-- end	

	-- local r = 0
	-- if GamePlayer.isTopUser(self.nViewID) then
	-- 	r = 90 - self.rotate - 180
	-- else	
	-- 	r = 90 - self.rotate
	-- end
	-- self.cur_cannon:setRotation(90-r)
-- 	self:setCannonRotate(self.rotate)
-- end

-- function GameCannon:setmoney(n)
-- 	self.m_nMoney = n;

-- 	self.m_cannonspr:setVisible(false);
-- 	self.m_cannonspr1:setVisible(false);
-- 	self.m_cannonspr2:setVisible(false);

-- 	if self.energy_card == true then
-- 		self.m_cannonspr3:setVisible(false)
-- 		self.energy_card = false
-- 	end	

-- 	if self.m_nMoney >= GameData.CANNON_MONEY_2 * self.base_score then
-- 		--rotate
-- 		self.m_cannonspr2:setVisible(true);
-- 	elseif self.m_nMoney >= GameData.CANNON_MONEY_1 * self.base_score then
-- 		--rotate
-- 		self.m_cannonspr1:setVisible(true);
-- 	else
-- 		--rotate
-- 		self.m_cannonspr:setVisible(true);
-- 	end

-- 	self:resetCannon();
-- end

-- function GameCannon:setcannonpos()
-- 	-- self.m_cannonpos:setpos(self.m_tagPos)
	
-- 	self:setCannonRotate(self.rotate)
-- end

function GameCannon:setCannonRotate(r)
	self.rotate = r

	if GamePlayer.isTopUser(self.nViewID) then
		self.cur_cannon:setRotation(r+180)
	else
		self.cur_cannon:setRotation(r)
	end
end

function GameCannon:getMoney()
	return self.m_nMoney
end

function GameCannon:setMoney(money)
	self.m_nMoney = money
    self.base_label:setString(money)

	self:resetCannon()
end

function GameCannon:resetCannon()
	if self.m_nMoney >= GameData.CANNON_MONEY_2 then
		self.m_cannon = Cannon.CANNON_2
	elseif self.m_nMoney >= GameData.CANNON_MONEY_1 then
		self.m_cannon = Cannon.CANNON_1
	else -- if self.m_nMoney >= GameData.CANNON_MONEY_0 then
		self.m_cannon = Cannon.CANNON_0
	end
	self:setCannon(self.m_cannon)
end

function GameCannon:setCannon(n)
	self.m_cannon = n

	-- self.m_cannonspr:setVisible(false);
	-- self.m_cannonspr1:setVisible(false);
	-- self.m_cannonspr2:setVisible(false);
	-- self.m_cannonspr3:setVisible(false);

	self.cur_cannon:setVisible(false)

	if self.m_cannon == Cannon.CANNON_0 then
		self.cur_cannon = self.m_cannonspr
	elseif self.m_cannon == Cannon.CANNON_1 then
		self.cur_cannon = self.m_cannonspr1
	elseif self.m_cannon == Cannon.CANNON_2 then
		self.cur_cannon = self.m_cannonspr2
	else -- if self.m_cannon == Cannon.CANNON_3 then
		self.cur_cannon = self.m_cannonspr3
	end
	self.cur_cannon:setVisible(true)

	self:setCannonRotate(self.rotate)
	-- self:setcannonpos()
end

--能量炮 分数翻倍
-- function GameCannon:changeEnergy(eneryPos)
	-- self.m_cannonspr:setVisible(false)
	-- self.m_cannonspr1:setVisible(false)
	-- self.m_cannonspr2:setVisible(false)

	-- self.m_cannonspr3:setVisible(true)
	-- self.energy_card = true
	-- self:setcannonpos()

	-- self.energy_times = utils.setTimeout(10,function ()
	-- 	self.card_sp:setVisible(false)
	-- 	self:setmoney(self.m_nMoney)
	-- end)

-- 	if self.card_sp then
-- 		self.card_sp:setVisible(true)
-- 		self.card_sp:stopAllActions()
-- 		self.card_sp:setPosition(eneryPos.x,eneryPos.y)
-- 		local t = math.sqrt( math.pow((eneryPos.x-self.card_x),2) + math.pow((eneryPos.y-self.card_y),2) ) / 800
     
--     	self.card_sp:runAction(cc.Sequence:create(
--     			cc.MoveTo:create(t,cc.p(self.card_x,self.card_y)),
--     			cc.CallFunc:create(function ()
--     				self:repeatAct()
--     			end)
--     		))
-- 	else	
-- 		local card_sp = display.newSprite(create_uipath("Player/card.png")):addTo(self:getParent(),100)
-- 		if card_sp == nil then
-- 			return
-- 		end	

-- 		local targetPos = cc.p(0,0)
-- 		if GamePlayer.isTopUser(self.nViewID) then
-- 			targetPos.x = 150
-- 			targetPos.y = -50

-- 			card_sp:setRotation(180)
-- 		else
-- 			targetPos.x =  -150
-- 			targetPos.y = 50
--     	end
--     	self.card_x = targetPos.x
--     	self.card_y = targetPos.y

--     	card_sp:setPosition(eneryPos.x,eneryPos.y)
--     	local t = math.sqrt( math.pow((eneryPos.x-targetPos.x),2) + math.pow((eneryPos.y-targetPos.y),2) ) / 800
     
--     	card_sp:runAction(cc.Sequence:create(
--     			cc.MoveTo:create(t,cc.p(targetPos.x,targetPos.y)),
--     			cc.CallFunc:create(function ()
--     				self:repeatAct()
--     			end)
--     		))
--     	self.card_sp = card_sp	
--     end	
-- end

-- function GameCannon:repeatAct()
-- 	self.card_sp:stopAllActions()
-- 	local seq = cc.Sequence:create(
--     	cc.MoveBy:create(0.2,cc.p(0,8)),
--     	cc.DelayTime:create(0.1),
--     	cc.MoveBy:create(0.2,cc.p(0,-8)),
--     	cc.DelayTime:create(0.1)
--     )
--     self.card_sp:runAction(cc.RepeatForever:create(seq)) 
-- end

-- function GameCannon:removeEnergy()
-- 	if self.card_sp then
-- 		self.card_sp:setVisible(false)
-- 	end
-- 	self:setMoney(self.m_nMoney)
-- end

-- function GameCannon:getmoney()
-- 	return self.m_nMoney;
-- end

function GameCannon:GetFrontPos(dir, fDrift)
	-- local _dir = POS.new();
	-- _dir:setpos(dir);
	local _dir = POS.new(dir)
	-- GameData.GETDIR(_dir,self.m_fPlayerAngle+self.m_fRol);
	GameData.GETDIR(_dir, math.rad(self.m_fPlayerAngle+self.rotate))

	-- local pos = POS.new();
	-- pos:setpos(self.m_cannonpos);
	local pos = POS.new(self.m_tagPos)
	_dir:mul(fDrift)
	pos:add(_dir);

	return pos;
end

function GameCannon:addbullet(idx)
	local _rotate = self.rotate
	self.cur_cannon:runAction( cc.Sequence:create(
		cc.MoveBy:create(0.04,cc.p(-10*math.sin(math.rad(_rotate)),-10*math.cos(math.rad(_rotate)))),
		cc.MoveBy:create(0.04,cc.p(10*math.sin(math.rad(_rotate)),10*math.cos(math.rad(_rotate)))) )) 

	local _type = self.m_cannon
	-- local offx--Vec2
	-- if self.energy_card then
	-- 	offx = -3
	-- 	_type = 3
	-- 	GAMESOUND.playEffect(Shot_Sound_3)
	-- else
	-- 	if self.m_nMoney >= GameData.CANNON_MONEY_2 * self.base_score then
	-- 		offx = -1
	-- 		_type = 2
	-- 		GAMESOUND.playEffect(Shot_Sound_2)
	-- 	elseif self.m_nMoney >= GameData.CANNON_MONEY_1 * self.base_score then
	-- 		offx = -1
	-- 		_type = 1
	-- 		GAMESOUND.playEffect(Shot_Sound_1)
	-- 	else
	-- 		offx = 0
	-- 		_type = 0
	-- 		GAMESOUND.playEffect(Shot_Sound_0)
	-- 	end
	-- end
	if self.m_cannon == Cannon.CANNON_0 then
		-- offx = 0
		GAMESOUND.playEffect(Shot_Sound_0)
	elseif self.m_cannon == Cannon.CANNON_1 then
		-- offx = -1
		GAMESOUND.playEffect(Shot_Sound_1)
	elseif self.m_cannon == Cannon.CANNON_2 then
		-- offx = -2
		GAMESOUND.playEffect(Shot_Sound_2)
	else
		-- offx = -3
		GAMESOUND.playEffect(Shot_Sound_3)
	end
	
	local name = "BULLET".._type;
	local res = GameData.MYRES[name];
	local cannon_h = self.cur_cannon:getContentSize().height - 40
	local point = self.cur_cannon:getAnchorPoint()
	local y = (1-point.y) * cannon_h + res[GameData.MYRES_HEIGHT]/2

	-- local pos,dir,dir1;

	-- dir = POS.new();
	-- dir:set(0,-1);

	-- local dir = POS.new(1,1)
	-- if GamePlayer.isTopUser(self.nViewID) then
	-- 	dir = POS.new(1,-1)
	-- end

	local pos = cc.p(math.sin(math.rad(_rotate)), math.cos(math.rad(_rotate)))
	pos = cc.pMul(pos, y)

	-- local pos = self:GetFrontPos(dir, y)

	-- dir1 = POS.new();
	-- dir1:setpos(self.m_tagDir1);
	-- dir1:mul(offx)
	-- pos:add(dir1);

	-- dir:mul(4);
	--local m_bullet = GameBullet.new(self.m_nMoney, _type, pos, dir, self.m_fPlayerAngle + self.m_fRol):addTo(self)
	local add_rol = 0
	if GamePlayer.isTopUser(self.nViewID) then
		add_rol = 180
		pos = cc.pAdd(cc.pMul(pos, -1), self.m_tagPos)
	else
		pos = cc.pAdd(pos, self.m_tagPos)
	end

	if idx == nil then
		idx = 0
	end

	local target_layer = self:getParent()
	local m_bullet = GameBullet.new(self.m_nMoney, self.nViewID, _type, pos, nil, _rotate, self.m_fPlayerAngle, idx):addTo(target_layer,-1)
	if self:getLockFishid() ~= nil then
		m_bullet:setMark(true)
	end
	-- if self._other_lock then
		-- m_bullet:setMark(self._other_lock+1)
		-- m_bullet:setOtherLock(self._lock_fish)
	-- end
	table.insert(self.m_bulletvec, m_bullet)

end

function GameCannon:removeBullet(_bullet)
	for i,v in ipairs(self.m_bulletvec) do
		if v == _bullet then
			-- _bullet:clearBullet()
			table.remove(self.m_bulletvec,i)
			break
		end	
	end
end

function GameCannon:addFishNet(_bullet)
	log("add fishNet")
	for i,v in ipairs(self.m_bulletvec) do
		if v.m_bullet == _bullet then
			v:addFishNet()
			table.remove(self.m_bulletvec,i)
			break
		end	
	end
end

function GameCannon:getMarkWithBullet(bullet)
	local m_mark = false
	for i,v in ipairs(self.m_bulletvec) do
		if v.m_bullet == bullet then
			m_mark = bullet:getMark()
			break
		end	
	end
	return m_mark
end

-- function GameCannon:autoFire()
	
-- end

function GameCannon:isFire()
    if self.m_firetime ~= 0 then
        if (getTimeInMilliseconds() - self.m_firetime) < GameData.FIRE_TIME_INTERVAL then
            return false
        end 
    end 
    self.m_firetime = getTimeInMilliseconds()
    return true
end

-- function GameCannon:rotateToPoint(x, y, _isfire, auto_fire, fishid, auto_change)
function GameCannon:rotateToPoint(x, y, _isfire, fishid)
	self:setLockFishid(fishid)
	-- if auto_fire == true and fishid == nil then
	-- 	self:addbullet()
	-- 	return
	-- end
	
	if GamePlayer.isTopUser(self.nViewID) then
		x = winSize.width - x
		y = winSize.height - y
	end
		
	--local r = math.atan2( y-self.m_cannonpos.y,x-self.m_cannonpos.x ) / math.pi *180
	local r = math.deg(math.atan2(y-self.m_tagPos.y, x-self.m_tagPos.x))
	-- log("1=======>", self.nViewID, r)

	if GamePlayer.isTopUser(self.nViewID) then
		if r > 90 then
   			r = 180
   		elseif r > 0 then	
   			r = 0
   		end
	else
		if r < -90 then
   			r = 180
   		elseif r < 0 then	
   			r = 0
   		end	
	end	

	-- self.cur_cannon:setRotation(90-r)
	
	if GamePlayer.isTopUser(self.nViewID) then
		r = 90-r-180
	else	
		r = 90-r
	end
	self:setCannonRotate(r)
	-- self.rotate = r

	-- self.cur_cannon:setRotation(r)

	-- if _auto == 0 and math.abs(r - self.rotate) < 1.5 then
	-- 	--self.rotate = r
	-- 	log("rotate",self.rotate)
	-- 	self:addbullet()
	-- 	return
	-- end	
	-- self.rotate = r
    if _isfire then
    	self:addbullet()
    end	
end

function GameCannon:clearCannon()
	-- if self.energy_times then
 --        utils.cleanTimeout(self.energy_times)
 --        self.energy_times = nil
 --    end
    self.m_fPlayerAngle = nil
	self.m_firetime = nil
	self.m_nMoney = nil
	-- self.base_score = nil
	-- self.m_state = nil

	self.m_tagPos = nil
	self.m_fRol = nil
	self.m_tagDir = nil
	self.m_tagDir1 = nil
	self.m_tagShiftPos = nil

	-- self.m_cannonpos = nil
	
	-- self.m_fireboardpos = nil
	-- self.m_fireseatpos = nil

	-- self.m_tagMarPpos = nil
	-- self.m_mark = nil

	self.m_bulletvec = nil

	self.m_fireboard = nil
    self.m_cannonspr = nil
	self.m_cannonspr1 = nil
	self.m_cannonspr2 = nil
    self.m_cannonspr3 = nil    
    -- self.m_fireseat = nil
    self.cur_cannon = nil   
    self.rotate = nil
    -- self.energy_card = nil

    -- self.base_score = nil
	self.nViewID = nil
	self._reverse = nil

    --utils.cleanAllChildAndEffect(self:getChildren())
    self:removeFromParent()
end

-- *******************************getter setter***********************************************
function GameCannon:setLockFishid(fishid)
	self._lockFishid = fishid
end
function GameCannon:getLockFishid()
	return self._lockFishid
end


return GameCannon
