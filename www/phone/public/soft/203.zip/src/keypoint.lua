
PATH_COUNT_SMALL		= 208;
PATH_COUNT_BIG			= 130;
PATH_COUNT_HUGE			= 62;
--PATH_COUNT_SPECIAL	= 28;

PATH_SMALL_FILENAME		= "path/small_%d.dat";
PATH_BIG_FILENAME		= "path/big_%d.dat";
PATH_HUGE_FILENAME		= "path/huge_%d.dat";

PATH_SMALL				= 0;
PATH_BIG				= 1;
PATH_HUGE				= 2;
--PATH_SPECIAL			= 3;

function KEYFRAMEPOINT()
	local o = {}
	o.x = 0; --short
	o.y = 0; --short
	o.angle = 0; --float
	o.staff = 0; --short
	return o;
end

function KEYPATH()
	local o = {}
	o.id = 0;
	--o.len = 0;
	o.points = {}; --KEYFRAMEPOINT
	return o;
end

local KEYPOINT=class("KEYPOINT", function (...)
	o={}
	o.m_small = {}; --KEYPATH
	o.m_big = {}; --KEYPATH
	o.m_huge = {}; --KEYPATH
	o.load_data = 0;
	return o
end)

--function KEYPOINT:ctor()
--end

function KEYPOINT:initData(_index,callback)
	local path_file 
	local path_num 
	local path_type
	if _index == 0 then
		path_file = PATH_SMALL_FILENAME
		path_num = PATH_COUNT_SMALL
		path_type = PATH_SMALL
	elseif _index == 1 then
		path_file = PATH_BIG_FILENAME
		path_num = PATH_COUNT_BIG
		path_type = PATH_BIG
	elseif _index == 2 then
		path_file = PATH_HUGE_FILENAME
		path_num = PATH_COUNT_HUGE
		path_type = PATH_HUGE
	end	

	for i=1,path_num do
		local coroutineFunc = function ()
			local path = string.format(create_uipath(path_file), i-1);
			local data = cc.FileUtils:getInstance():getStringFromFile(path);
			self:addpoint(path_type, data);
			if i == path_num then
    			--callback()
			end	
		end		
		local co = coroutine.create(coroutineFunc)        --创建协同程序co
		coroutine.resume(co) 
	end

	-- for i,v in ipairs(self.m_small[1].points) do
	-- 	log(v.x,v.y)
	-- end
	-- log(#self.m_small[1].points)
	-- log(#self.m_small[2].points)
	-- log(#self.m_small[3].points)
end

function KEYPOINT:addpoint(_type, data)
	local b = ByteArray:new()
    :writeBuf(data)
    :setPos(1)

	local len = b:readInt();
	local path = KEYPATH();
	for i=1,len do
		local k = KEYFRAMEPOINT();
		k.x = b:readShort();
		k.y = b:readShort();
		k.angle = b:readFloat();
		k.staff = b:readShort();
		path.points[#path.points + 1] = k;
	end

	if _type == PATH_SMALL then
		path.id = #self.m_small + 1;
		self.m_small[path.id] = path;
	elseif _type ==  PATH_BIG then
		path.id = #self.m_big + 1;
		self.m_big[path.id] = path;
	elseif _type == PATH_HUGE then
		path.id = #self.m_huge + 1;
		self.m_huge[path.id] = path;
	end
end

function KEYPOINT:getpath(_type)
	if _type == PATH_SMALL then
		return self.m_small;
	elseif _type ==  PATH_BIG then
		return self.m_big;
	elseif _type == PATH_HUGE then
		return self.m_huge;
	end

	return nil;
end

function KEYPOINT:getkeypath(_type, pathidx)
	
	local p = {};

	if _type == PATH_SMALL then
		p = self.m_small;
	elseif _type ==  PATH_BIG then
		p = self.m_big;
	elseif _type == PATH_HUGE then
		p = self.m_huge;
	else
		return nil;
	end
	if pathidx > #p then
		return nil;
	end
	--不能从0开始
	return p[pathidx+1];

end

function KEYPOINT:getPathFromLua(_type,pathidx)
    local index = pathidx + 1
    local object
    if _type == PATH_SMALL then
        if not self.m_small[index] then
            local file = src_path.."small_"..pathidx
            self.m_small[index] = import(file)
            self:convertToCocosPos(self.m_small[index])
        end
        object = self.m_small[index]
    elseif _type ==  PATH_BIG then 
        if not self.m_big[index] then
            local file = src_path.."big_"..pathidx
            self.m_big[index] = import(file)
            self:convertToCocosPos(self.m_big[index])
        end
        object = self.m_big[index]
    elseif _type == PATH_HUGE then
        if not self.m_huge[index] then
            local file = src_path.."huge_"..pathidx
            self.m_huge[index] = import(file)
            self:convertToCocosPos(self.m_huge[index])
        end
        object = self.m_huge[index]
    end
    
    return object
end

-- 
function KEYPOINT:convertToCocosPos( object )
	-- for k,t in ipairs(object) do
 --        t[2] = display.height-t[2]
 --    end
end

return KEYPOINT